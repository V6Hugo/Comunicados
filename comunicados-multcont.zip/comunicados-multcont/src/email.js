'use strict';
/*
 * Envio de comunicados por e-mail.
 * - Com SMTP configurado no .env, envia de verdade, em ritmo controlado (fila).
 * - Sem SMTP, funciona em MODO TESTE: gera os e-mails em data/emails-teste/ (arquivos .eml que abrem no Outlook)
 *   e marca como enviados, para você testar o fluxo inteiro sem disparar nada.
 */
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const nodemailer = require('nodemailer');
const { db, DB_PATH } = require('./db');
const { esc, dataLonga } = require('./util');
const { EMPRESA } = require('./views');

const SMTP = process.env.SMTP_HOST ? {
  host: process.env.SMTP_HOST,
  port: Number(process.env.SMTP_PORT) || 587,
  secure: process.env.SMTP_SECURE === '1' || Number(process.env.SMTP_PORT) === 465,
  auth: process.env.SMTP_USER ? { user: process.env.SMTP_USER, pass: process.env.SMTP_SENHA || process.env.SMTP_PASS } : undefined,
} : null;
const MODO = SMTP ? 'smtp' : 'teste';
const REMETENTE = process.env.EMAIL_REMETENTE || `Multcont Comunicados <${process.env.SMTP_USER || 'comunicados@multcont.com.br'}>`;
const RESPONDER_PARA = process.env.EMAIL_RESPONDER_PARA || EMPRESA.email;
const POR_MINUTO = Math.max(1, Number(process.env.ENVIO_POR_MINUTO) || 30);
const PASTA_TESTE = path.join(path.dirname(DB_PATH), 'emails-teste');

const transporte = SMTP ? nodemailer.createTransport({ ...SMTP, pool: true, maxConnections: 1 }) : nodemailer.createTransport({ streamTransport: true, buffer: true, newline: 'windows' });

function info() {
  return { modo: MODO, remetente: REMETENTE, porMinuto: POR_MINUTO, host: SMTP ? SMTP.host : null, pastaTeste: PASTA_TESTE };
}

// ---------------------------------------------------------------------
// Modelo do e-mail (HTML em tabelas + estilos em linha: funciona no Outlook, Gmail e celular)
// ---------------------------------------------------------------------
function linkAviso(base, c, email, envioId, token) {
  const q = new URLSearchParams({ e: email, utm_source: 'email', utm_campaign: `envio-${envioId}`, k: token });
  return `${base}/${c.slug}?${q}`;
}
function montarEmail({ c, base, nome, email, envioId, token, mensagem }) {
  const link = linkAviso(base, c, email, envioId, token);
  const cor = c.depto_cor || '#1f92bf';
  const saud = nome ? `Olá, ${esc(nome.split(' ')[0])}.` : 'Olá.';
  const intro = mensagem ? `<p style="margin:0 0 16px;font-size:15px;line-height:1.6;color:#2b2b2b">${esc(mensagem).replace(/\n/g, '<br>')}</p>` : '';
  const html = `<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>${esc(c.titulo)}</title></head>
<body style="margin:0;padding:0;background:#f4f3f6;font-family:Montserrat,Arial,Helvetica,sans-serif">
<div style="display:none;max-height:0;overflow:hidden">${esc(c.resumo)}</div>
<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#f4f3f6;padding:28px 12px"><tr><td align="center">
<table role="presentation" width="600" cellpadding="0" cellspacing="0" style="max-width:600px;width:100%;background:#ffffff;border:1px solid #dedce1;border-radius:12px;overflow:hidden">
  <tr><td style="padding:24px 32px;border-bottom:1px solid #dedce1"><img src="${base}/img/logo-multcont.png" width="128" alt="Multcont" style="display:block;border:0;height:auto"></td></tr>
  <tr><td style="background:#1f4470;padding:28px 32px">
    <p style="margin:0 0 10px;font-size:11px;letter-spacing:2px;text-transform:uppercase;color:#00a6fb;font-weight:bold">Setor ${esc(c.depto_nome)} · Comunicado ${esc(c.numero)}</p>
    <h1 style="margin:0;font-size:24px;line-height:1.25;color:#ffffff;font-weight:bold">${esc(c.titulo)}</h1>
  </td></tr>
  <tr><td style="height:4px;background:#00a6fb;font-size:0;line-height:0">&nbsp;</td></tr>
  <tr><td style="padding:28px 32px 8px">
    <p style="margin:0 0 16px;font-size:15px;color:#2b2b2b">${saud}</p>
    ${intro}
    <p style="margin:0 0 20px;font-size:15px;line-height:1.6;color:#2b2b2b">${esc(c.resumo)}</p>
    <table role="presentation" cellpadding="0" cellspacing="0"><tr><td style="border-radius:10px;background:#1f92bf">
      <a href="${link}" style="display:inline-block;padding:14px 26px;font-size:15px;font-weight:bold;color:#ffffff;text-decoration:none;border-radius:10px">Ler o comunicado completo</a>
    </td></tr></table>
    <p style="margin:18px 0 0;font-size:13px;line-height:1.6;color:#727273">Ao final da página, clique em <b style="color:#1f4470">“Li e estou ciente”</b> para confirmar a leitura. Publicado em ${dataLonga(c.publicado_em)}.</p>
  </td></tr>
  <tr><td style="padding:24px 32px 28px"><table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="border-top:1px solid #dedce1"><tr><td style="padding-top:16px;font-size:12px;line-height:1.7;color:#727273">
    Dúvidas? Fale com o setor ${esc(c.depto_nome)} pelo WhatsApp <a href="https://wa.me/${esc(c.depto_whatsapp)}" style="color:#1f92bf;text-decoration:none">${esc(formatarFone(c.depto_whatsapp))}</a> ou responda este e-mail.<br>
    ${EMPRESA.nome} · ${EMPRESA.endereco}<br>
    <span style="color:#a3a2a6">Você recebe este aviso por ser cliente da Multcont.</span>
  </td></tr></table></td></tr>
</table>
<img src="${base}/api/t/px/${token}.gif" width="1" height="1" alt="" style="display:block;border:0;width:1px;height:1px">
</td></tr></table></body></html>`;
  const texto = `${saud}\n\n${mensagem ? mensagem + '\n\n' : ''}${c.titulo}\nComunicado ${c.numero} · Setor ${c.depto_nome}\n\n${c.resumo}\n\nLeia o comunicado completo: ${link}\n\nAo final da página, clique em "Li e estou ciente" para confirmar a leitura.\n\n${EMPRESA.nome} · ${EMPRESA.telefone} · ${EMPRESA.email}`;
  return { html, texto, link };
}
function formatarFone(n) { const d = String(n || '').replace(/^55/, ''); return d.length === 11 ? `(${d.slice(0, 2)}) ${d.slice(2, 7)}-${d.slice(7)}` : n; }

const qCom = db.prepare(`SELECT c.*, d.nome depto_nome, d.cor depto_cor, d.whatsapp depto_whatsapp
  FROM comunicados c JOIN departamentos d ON d.id = c.departamento_id WHERE c.id = ?`);

function previa({ comunicadoId, base, mensagem, nome = 'Ana Souza', email = 'cliente@empresa.com.br' }) {
  const c = qCom.get(comunicadoId);
  if (!c) return null;
  return montarEmail({ c, base, nome, email, envioId: 0, token: 'previa', mensagem });
}

// ---------------------------------------------------------------------
// Fila
// ---------------------------------------------------------------------
function criarEnvio({ comunicadoId, tipo, publico, assunto, mensagem, base, destinatarios, criadoPor }) {
  const unicos = new Map();
  for (const d of destinatarios) { const e = String(d.email || '').trim().toLowerCase(); if (e && !unicos.has(e)) unicos.set(e, { email: e, nome: d.nome || null }); }
  if (!unicos.size) throw new Error('Nenhum destinatário válido.');
  let id;
  db.transaction(() => {
    id = db.prepare(`INSERT INTO envios (comunicado_id, tipo, publico, assunto, mensagem, base_url, modo, criado_por)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)`).run(comunicadoId, tipo, publico, assunto, mensagem || null, base, MODO, criadoPor).lastInsertRowid;
    const ins = db.prepare('INSERT INTO envio_destinatarios (envio_id, email, nome, token) VALUES (?, ?, ?, ?)');
    for (const d of unicos.values()) ins.run(id, d.email, d.nome, crypto.randomBytes(12).toString('base64url'));
  })();
  agendar();
  return id;
}

async function enviarUm(dest, envio, c) {
  const { html, texto } = montarEmail({ c, base: envio.base_url, nome: dest.nome, email: dest.email, envioId: envio.id, token: dest.token, mensagem: envio.mensagem });
  const msg = { from: REMETENTE, replyTo: RESPONDER_PARA, to: dest.nome ? { name: dest.nome, address: dest.email } : dest.email, subject: envio.assunto, html, text: texto,
    headers: { 'X-Comunicado': c.numero, 'X-Envio': String(envio.id) } };
  const r = await transporte.sendMail(msg);
  if (MODO === 'teste') {
    const pasta = path.join(PASTA_TESTE, `envio-${envio.id}`);
    fs.mkdirSync(pasta, { recursive: true });
    fs.writeFileSync(path.join(pasta, `${dest.email.replace(/[^a-z0-9@._-]/gi, '_')}.eml`), r.message);
  }
}

let rodando = false, timer = null;
function agendar() { if (!timer) timer = setTimeout(processar, 200); }
async function processar() {
  timer = null;
  if (rodando) return;
  rodando = true;
  try {
    const dest = db.prepare(`SELECT d.* FROM envio_destinatarios d JOIN envios e ON e.id = d.envio_id
      WHERE d.status = 'pendente' AND e.status IN ('na_fila','enviando') ORDER BY d.envio_id, d.id LIMIT 1`).get();
    if (!dest) return;
    const envio = db.prepare('SELECT * FROM envios WHERE id = ?').get(dest.envio_id);
    if (envio.status === 'na_fila') db.prepare("UPDATE envios SET status = 'enviando' WHERE id = ?").run(envio.id);
    const c = qCom.get(envio.comunicado_id);
    try {
      await enviarUm(dest, envio, c);
      db.prepare("UPDATE envio_destinatarios SET status = 'enviado', enviado_em = datetime('now'), tentativas = tentativas + 1, erro = NULL WHERE id = ?").run(dest.id);
    } catch (e) {
      const tent = dest.tentativas + 1;
      db.prepare('UPDATE envio_destinatarios SET status = ?, tentativas = ?, erro = ? WHERE id = ?')
        .run(tent >= 3 ? 'erro' : 'pendente', tent, String(e.message || e).slice(0, 300), dest.id);
    }
    const falta = db.prepare("SELECT COUNT(*) n FROM envio_destinatarios WHERE envio_id = ? AND status = 'pendente'").get(envio.id).n;
    if (!falta) db.prepare("UPDATE envios SET status = 'concluido', concluido_em = datetime('now') WHERE id = ? AND status = 'enviando'").run(envio.id);
  } finally {
    rodando = false;
    const ha = db.prepare(`SELECT 1 FROM envio_destinatarios d JOIN envios e ON e.id = d.envio_id WHERE d.status = 'pendente' AND e.status IN ('na_fila','enviando') LIMIT 1`).get();
    if (ha && !timer) timer = setTimeout(processar, Math.round(60000 / POR_MINUTO));
  }
}
function cancelar(envioId) {
  db.transaction(() => {
    db.prepare("UPDATE envios SET status = 'cancelado', concluido_em = datetime('now') WHERE id = ? AND status IN ('na_fila','enviando')").run(envioId);
    db.prepare("UPDATE envio_destinatarios SET status = 'cancelado' WHERE envio_id = ? AND status = 'pendente'").run(envioId);
  })();
}
// envio imediato de um teste para o próprio gestor (fora da fila)
async function enviarTeste({ comunicadoId, base, assunto, mensagem, para, nome }) {
  const c = qCom.get(comunicadoId);
  const { html, texto } = montarEmail({ c, base, nome, email: para, envioId: 0, token: 'teste', mensagem });
  const r = await transporte.sendMail({ from: REMETENTE, replyTo: RESPONDER_PARA, to: para, subject: `[TESTE] ${assunto}`, html, text: texto });
  if (MODO === 'teste') { fs.mkdirSync(PASTA_TESTE, { recursive: true }); fs.writeFileSync(path.join(PASTA_TESTE, `teste-${Date.now()}.eml`), r.message); }
}

// ao iniciar o servidor, retoma envios que ficaram pela metade
setTimeout(agendar, 1500);

// Métricas por destinatário: abriu e-mail, abriu aviso, leu até o fim, confirmou
function destinatariosComMetricas(envioId) {
  return db.prepare(`
    SELECT d.*,
      (SELECT MIN(s.iniciada_em) FROM sessoes_leitura s JOIN visitantes v ON v.id = s.visitante_id
         WHERE s.comunicado_id = e.comunicado_id AND LOWER(COALESCE(s.email, v.email)) = LOWER(d.email)) AS aviso_aberto_em,
      (SELECT MAX(s.chegou_ao_fim) FROM sessoes_leitura s JOIN visitantes v ON v.id = s.visitante_id
         WHERE s.comunicado_id = e.comunicado_id AND LOWER(COALESCE(s.email, v.email)) = LOWER(d.email)) AS leu_ate_fim,
      (SELECT MAX(s.rolagem_max_pct) FROM sessoes_leitura s JOIN visitantes v ON v.id = s.visitante_id
         WHERE s.comunicado_id = e.comunicado_id AND LOWER(COALESCE(s.email, v.email)) = LOWER(d.email)) AS rolagem,
      (SELECT k.confirmado_em FROM confirmacoes_leitura k WHERE k.comunicado_id = e.comunicado_id AND k.email = d.email) AS confirmado_em
    FROM envio_destinatarios d JOIN envios e ON e.id = d.envio_id
    WHERE d.envio_id = ? ORDER BY d.id`).all(envioId);
}
function resumoEnvio(envioId) {
  const ds = destinatariosComMetricas(envioId);
  const n = (f) => ds.filter(f).length;
  return { total: ds.length, enviados: n((d) => d.status === 'enviado'), pendentes: n((d) => d.status === 'pendente'), erros: n((d) => d.status === 'erro'),
    emailAberto: n((d) => d.email_aberto_em), avisoAberto: n((d) => d.aviso_aberto_em || d.link_clicado_em), leuFim: n((d) => d.leu_ate_fim), confirmaram: n((d) => d.confirmado_em), destinatarios: ds };
}

module.exports = { info, previa, criarEnvio, cancelar, enviarTeste, resumoEnvio, linkAviso, MODO };
