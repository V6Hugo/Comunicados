'use strict';
// Comunicados oficiais carregados no primeiro acesso (texto dos documentos da Multcont).
// Datas = data do documento. Edite, fixe ou arquive pelo painel.
module.exports = [
  {
    numero: '001/2026', slug: '001-2026', depto: 'fiscal', prioridade: 'importante', fixado: 0, fixado_ate: null,
    publicado_em: '2026-07-14',
    titulo: 'Reforma Tributária: novas informações obrigatórias na NF-e e NFC-e a partir de agosto/2026',
    resumo: 'A exigência foi prorrogada para agosto/2026. Lucro Real e Presumido: notas sem CBS e IBS destacados serão bloqueadas a partir de 03/08/2026.',
    assinatura: 'Equipe Multcont',
    conteudo_md: `## Em resumo

- A exigência que estava prevista para janeiro foi **prorrogada para agosto de 2026**.
- **Lucro Real e Lucro Presumido:** a partir de **03/08/2026**, notas fiscais sem as novas informações serão **bloqueadas automaticamente**.
- **Simples Nacional e MEI:** o bloqueio só passa a valer a partir de **04/01/2027**.
- Em 2026 não há imposto novo a pagar — **desde que o destaque seja feito corretamente**.

Como já mencionamos em comunicados anteriores, retomamos o assunto da Reforma Tributária para reforçar um ponto importante: a exigência que estava prevista para janeiro foi prorrogada para agosto de 2026.

Se sua empresa já se adequou desde o início do processo, este comunicado é apenas uma confirmação e pode ser desconsiderado. Porém, se ainda não realizou a adequação, é fundamental agir o quanto antes, já que a nova exigência passa a valer efetivamente em agosto/2026 e o prazo está se aproximando.

## O que muda na nota fiscal

Informamos que, no âmbito da Reforma Tributária, as notas fiscais eletrônicas de produtos/mercadorias e notas/cupons emitidos ao consumidor final **(NF-e e NFC-e)** passarão a exigir o preenchimento de novas informações a partir de agosto/2026, em uma fase de adaptação que antecede a cobrança efetiva dos novos tributos. A **Multcont** vem acompanhando de perto esse cronograma para orientar nossos clientes com a devida antecedência.

Na prática, a nota fiscal passará a mostrar, separadamente, os valores dos novos tributos da Reforma, chamados **CBS** e **IBS**, que ao longo dos próximos anos vão substituir gradualmente tributos atuais como **ICMS**, **ISS**, **PIS** e **COFINS**. Cada produto também passará a trazer uma nova classificação, indicando como ele é tributado dentro da Reforma. Em 2026, esses valores aparecem apenas como teste/informativo, sem nada a mais para pagar, e o próprio sistema emissor de notas, depois de atualizado, preenche tudo automaticamente.

## Como conferir o destaque na sua nota (valores de teste de 2026)

| Tributo | Alíquota de teste 2026 |
|---|---|
| CBS | 0,9% |
| IBS | 0,1% |
| **Total destacado** | **1,0%** |

**Cálculo:** o percentual incide sobre o valor do próprio produto na nota (calculado "por fora" — não é somado ao preço nem entra na própria base).

**Exemplo:** em uma venda de R$ 1.000,00 → R$ 9,00 de CBS + R$ 1,00 de IBS = R$ 10,00 no total.

Esse 1,0% é a alíquota de teste válida apenas em 2026; nos próximos anos os percentuais devem subir gradualmente. Reforçamos: em 2026 esse valor destacado é somente informativo — não é cobrado, não altera o valor a pagar da nota e não entra na base do ICMS/ISS.

## Importante: a dispensa do pagamento é condicionada ao destaque

A dispensa do recolhimento de CBS e IBS em 2026 **não é automática**: ela depende do cumprimento da obrigação acessória, ou seja, do correto destaque dos tributos nas notas fiscais.

Nos termos do art. 348, § 1º, fica dispensado o recolhimento do IBS e da CBS relativo aos fatos geradores ocorridos de 1º de janeiro a 31 de dezembro de 2026 **em relação aos sujeitos passivos que cumprirem as obrigações acessórias previstas na legislação**.

> Na prática: **só não paga quem destaca.** A empresa que deixar de fazer o destaque nas notas fiscais perde o benefício da dispensa e deverá recolher o 1% sobre o faturamento do período, como consequência do descumprimento da obrigação acessória.

Essa regra **não se aplica às operações dos contribuintes optantes pelo Simples Nacional** (art. 348, alínea "c").

## Prazos por regime

- **Empresas do Lucro Real e Lucro Presumido:** a partir de 03/08/2026, notas fiscais emitidas sem as novas informações serão bloqueadas automaticamente pelo governo — ou seja, a empresa não conseguirá faturar até a correção.
- **Empresas do Simples Nacional e MEI:** a mesma exigência, com bloqueio, só passa a valer a partir de 04/01/2027.

Em 2026, não há cobrança de imposto novo — desde que o destaque seja feito corretamente. Trata-se de uma exigência de preenchimento nas notas fiscais, em fase de teste, cujo cumprimento é a própria condição para a dispensa do recolhimento.

**E quem só presta serviço?** Se sua empresa emite apenas nota fiscal de serviço (NFS-e), o prazo de 03/08/2026 não se aplica a você: essa nota segue um calendário próprio de adaptação à Reforma, ainda sem data de exigência definida.

## O que você precisa fazer

**Atenção:** empresas do Regime Lucro Real e Lucro Presumido devem, com prioridade, confirmar junto ao fornecedor do seu sistema de emissão de notas fiscais (ERP/programa emissor) se a atualização para a Reforma já foi aplicada, e realizar um teste de emissão antes de 03/08/2026. Empresas do Simples Nacional e MEI não precisam agir neste momento; nossa equipe fará contato com antecedência quando for necessário.

Nossa equipe está à disposição para esclarecer dúvidas e apoiar sua empresa neste processo de adaptação.`,
  },
  {
    numero: '002/2026', slug: '002-2026', depto: 'tributario', prioridade: 'importante', fixado: 0, fixado_ate: null,
    publicado_em: '2026-07-27',
    titulo: 'Reforma Tributária – Simples Nacional: opção pelo recolhimento da CBS e do IBS em 2027',
    resumo: 'Entre 1º e 30 de setembro de 2026, cada empresa do Simples escolhe se recolherá CBS e IBS dentro do DAS ou "por fora". Responda o formulário até 28/08/2026.',
    assinatura: 'Equipe Multcont',
    conteudo_md: `## Em resumo

- Entre **1º e 30 de setembro de 2026**, as empresas do Simples Nacional optam como recolherão a CBS e o IBS a partir de **01/01/2027**: **dentro do DAS** ou **"por fora", pelo regime regular**.
- Optar em setembro é **reversível** (dá para desistir em novembro); não optar é **definitivo para o 1º semestre de 2027**.
- **Responda o formulário até 28/08/2026.**

Prezados clientes,

Entre **1º e 30 de setembro de 2026**, todas as empresas do Simples Nacional devem optar como recolherão a CBS e o IBS (IVA) a partir de **01/01/2027**: **dentro do DAS** (como é hoje) ou **"por fora", pelo regime regular**. Essa escolha não acontece de uma vez só — a lei desenhou um caminho em três tempos.

## Como funciona

| Quando | O que acontece |
|---|---|
| **Setembro** | Faremos a opção pelo regime regular "por fora" — a alíquota oficial dos novos tributos ainda não terá sido publicada. |
| **Outubro** | O Governo divulga a **alíquota oficial** (previsão legal: até 31/10). |
| **Novembro** | Nós refazemos a sua análise com a alíquota oficial. Quem optou pelo "por fora" confirma ou cancela a opção até o fim de novembro. |

**O ponto mais importante:** optar em setembro é **reversível** — dá para desistir em novembro, já conhecendo a alíquota oficial. **Não optar é definitivo para o 1º semestre de 2027** — a próxima janela será só em março/2027, com efeitos a partir de julho. Como em setembro não teremos as alíquotas, optar será a forma de manter as duas portas abertas; nesse caso, a revisão de novembro entra como etapa obrigatória do nosso processo, para nenhum cliente ficar preso a uma opção.

**Quem não se manifestar em setembro permanece no modelo atual** (CBS/IBS dentro do DAS) — é o padrão da lei.

## Não existe resposta única

- **Vende ou presta serviços principalmente para consumidor final (pessoa física)?** Permanecer no DAS tende a ser o melhor caminho — simplicidade e, possivelmente, menor desembolso.
- **Vende ou presta serviços principalmente para empresas (PJ)?** A decisão exige análise. A diferença está no **crédito que o seu cliente consegue aproveitar**: no regime regular, ele aproveita o **crédito integral**; se você permanecer no DAS, o crédito dele fica **limitado ao valor recolhido dentro do Simples** (bem menor). Parte dos compradores passará a preferir fornecedores com crédito integral. Em troca, a apuração fica mais complexa e o desembolso mensal pode aumentar.

## O que precisamos de você — até 28/08/2026

**Responda o formulário** (5 minutos) através do link: [https://forms.gle/nthi1Zw8JvKaH5uX6](https://forms.gle/nthi1Zw8JvKaH5uX6)

**Se você vende ou presta serviços para empresas:** converse com seus principais clientes PJ.

> A pergunta-chave: **que peso o crédito integral de CBS/IBS terá na escolha de fornecedores a partir de 2027? Já existe diretriz do setor de compras/fiscal de vocês sobre isso? Qual?**

## Calendário completo

| Etapa | Prazo | Quem faz |
|---|---|---|
| Formulário respondido | até 28/08/2026 | Você |
| Registro da opção no portal do Simples Nacional | até 25/09/2026 | Multcont |
| Alíquota oficial fixada pelo Governo | até 31/10/2026 | Governo |
| Revisão da sua empresa com a alíquota oficial | até 13/11/2026 | Multcont |
| Confirmação ou cancelamento da opção | até 25/11/2026 | Você + Multcont |

## Importante

- A opção é **conjunta para o IBS e a CBS** — não existe escolha separada por tributo. Em 2027, porém, o IBS ainda estará em alíquota-teste (simbólica): **o efeito prático da escolha no primeiro ano está na CBS**; o IBS ganha peso gradualmente a partir de 2029.
- A opção vale para o **1º semestre de 2027**; em **março/2027** haverá nova janela, para o 2º semestre.

Nossa **equipe está à disposição** para esclarecer dúvidas e apoiar sua empresa neste processo.

*Em caso de dúvidas ou necessidades específicas, solicitamos que entrem em contato pelos **canais habituais de atendimento** ou diretamente com o responsável pelo acompanhamento da sua empresa.*`,
  },
  {
    numero: '003/2026', slug: '003-2026', depto: 'tributario', prioridade: 'urgente', fixado: 1, fixado_ate: '2026-11-30',
    publicado_em: '2026-10-30',
    titulo: 'Reforma Tributária 2027 – Impactos e Diagnósticos Tributários',
    resumo: 'Para Lucro Real e Lucro Presumido: com a alíquota de referência da CBS em cerca de 11,34%, solicite o diagnóstico preliminar até 30/11/2026.',
    assinatura: 'Equipe Multcont',
    conteudo_md: `## Em resumo

- **Para quem:** empresas do **Lucro Real e Lucro Presumido**.
- O TCU aprovou a alíquota de referência da CBS em aproximadamente **11,34% para 2027**; o Senado poderá confirmá-la ou alterá-la até **15/12/2026**.
- **Diagnóstico preliminar:** solicite até **30/11/2026** — entrega em até 30 dias.
- **Análise tributária detalhada:** mediante orçamento.

*Destinado às empresas do Lucro Real e Lucro Presumido.*

Prezados clientes,

A Reforma Tributária está trazendo mudanças importantes para as empresas, e a Multcont está à disposição para auxiliar seus clientes na compreensão dos impactos dessas alterações.

No dia **28/10/2026**, o Tribunal de Contas da União (TCU) aprovou o cálculo da alíquota de referência da CBS em aproximadamente **11,34% para 2027**, tributo que substituirá o PIS e a Cofins.

O Senado Federal poderá confirmar ou alterar essa alíquota até **15/12/2026**.

Diante desse cenário, disponibilizaremos duas modalidades de análise para nossos clientes enquadrados nos regimes de Lucro Real e Lucro Presumido:

## 1. Diagnóstico preliminar

**Prazo para solicitação: 30/11/2026**

Os clientes interessados poderão solicitar ao nosso Departamento Fiscal uma simulação de um mês de apuração, utilizando a alíquota de referência de 11,34%, para obter uma estimativa inicial dos possíveis impactos tributários.

O prazo para entrega do diagnóstico será de **até 30 dias, contados a partir da data da solicitação**.

É importante destacar que, caso o Senado promova alterações na alíquota em 15/12/2026, **não será possível assegurar a revisão ou atualização dos diagnósticos e simulações ainda no exercício de 2026**, considerando a elevada demanda de serviços fiscais, contábeis e trabalhistas característica do período de encerramento do ano.

Por esse motivo, estamos antecipando essa oportunidade para que nossos clientes possam avaliar os possíveis impactos da Reforma Tributária com base na alíquota de referência atualmente divulgada, mesmo que ela ainda esteja sujeita a alterações.

> As solicitações deverão ser realizadas impreterivelmente até **30/11/2026**.

## 2. Análise tributária detalhada

**Serviço mediante orçamento**

Para empresas que desejarem um estudo mais completo, incluindo identificação de créditos tributários, reduções de alíquotas, particularidades de cada atividade e comparativos de tributação, será necessário solicitar uma proposta ao nosso Departamento Comercial.

Essas análises envolvem novas apurações, reprocessamento de informações e dedicação de horas técnicas adicionais.

Por se tratar de um trabalho especializado, que vai além dos serviços previstos em nossos contratos mensais, **os estudos detalhados serão cobrados separadamente**, conforme a complexidade de cada empresa.

## Nosso compromisso

A Multcont está preparada para apoiar seus clientes nessa transição, sempre com transparência, responsabilidade e qualidade técnica.

Nosso objetivo é oferecer o suporte necessário, respeitando os prazos e a complexidade dos serviços, para que possamos continuar atendendo a todos com a qualidade que nossa parceria merece.

Contamos com a compreensão e permanecemos à disposição!`,
  },
  {
    numero: '004/2026', slug: '004-2026', depto: 'tributario', prioridade: 'urgente', fixado: 1, fixado_ate: '2026-11-30',
    publicado_em: '2026-10-30',
    titulo: 'Reforma Tributária 2027 – Simples Nacional Híbrido ou Normal',
    resumo: 'Optou por recolher CBS e IBS fora do DAS? Ainda dá para desistir: peça o diagnóstico e comunique a decisão ao Departamento Fiscal até 30/11/2026.',
    assinatura: 'Equipe Multcont',
    conteudo_md: `## Em resumo

- **Para quem:** empresas do Simples Nacional que optaram pelo recolhimento da CBS e do IBS **fora do DAS** (regime híbrido).
- A alíquota de referência da CBS foi calculada em aproximadamente **11,34% para 2027**.
- Ainda é possível **desistir do regime híbrido**: comunique a decisão ao Departamento Fiscal **até 30/11/2026**.
- **Diagnóstico preliminar:** solicite até **30/11/2026**.

*Destinado às empresas do Simples Nacional que optaram pelo recolhimento da CBS e do IBS fora do DAS e que ainda podem desistir dessa opção e retornar ao Simples Nacional tradicional.*

Prezados clientes,

A Reforma Tributária está trazendo mudanças importantes para as empresas, e a Multcont está à disposição para auxiliar seus clientes na avaliação dos impactos dessas alterações.

As empresas do Simples Nacional que optaram pelo regime híbrido para 2027 continuarão enquadradas no Simples Nacional, porém passarão a apurar e recolher a CBS e o IBS separadamente, fora da guia do DAS, conforme as regras do regime regular.

No dia **28/10/2026**, o Tribunal de Contas da União (TCU) aprovou o cálculo da alíquota de referência da CBS em aproximadamente **11,34% para 2027**, que ainda depende de definição pelo Senado Federal.

É importante destacar que as empresas que optaram pelo regime híbrido **ainda poderão desistir dessa opção, com prazo estendido até o início de dezembro de 2026**.

Por isso, recomendamos avaliar os possíveis impactos tributários antes de confirmar a permanência nesse modelo.

## 1. Diagnóstico preliminar

**Prazo para solicitação: 30/11/2026**

Os clientes interessados poderão solicitar ao nosso Departamento Fiscal uma simulação de um mês de apuração, utilizando a alíquota de referência de 11,34%, para obter uma estimativa inicial da CBS a ser recolhida fora do DAS.

Essa análise permitirá uma primeira avaliação dos possíveis impactos financeiros da opção pelo regime híbrido.

O prazo para entrega do diagnóstico será de **até 30 dias, contados a partir da data da solicitação**.

> **Atenção:** como o prazo legal para desistência do regime híbrido termina no início de dezembro, **os diagnósticos solicitados próximos a essa data poderão ser entregues após o encerramento do prazo de desistência**.

Além disso, caso o Senado altere a alíquota de referência em dezembro, **não será possível assegurar a revisão ou atualização dos diagnósticos e simulações ainda em 2026**, considerando a elevada demanda de serviços fiscais, contábeis e trabalhistas característica do período de encerramento do ano.

Por esse motivo, estamos oferecendo antecipadamente essa oportunidade de análise, para que nossos clientes possam conhecer os possíveis impactos da escolha realizada.

## 2. Análise tributária detalhada

**Serviço mediante orçamento**

Para as empresas que desejarem um estudo mais completo, incluindo comparação entre o Simples Nacional tradicional e o regime híbrido, aproveitamento de créditos tributários, reduções de alíquotas e particularidades de cada atividade, será necessário solicitar uma proposta ao nosso Departamento Comercial.

Essas análises envolvem novas apurações, reprocessamento de informações e dedicação de horas técnicas adicionais.

Por se tratar de um trabalho especializado, que vai além dos serviços previstos em nossos contratos mensais, **os estudos detalhados serão cobrados separadamente**, conforme a complexidade de cada empresa.

## 3. Decisão sobre a permanência no regime híbrido

A opção pelo regime híbrido **não significa necessariamente uma redução de impostos**. Dependendo das características da empresa, dos créditos tributários disponíveis e de suas operações comerciais, o recolhimento da CBS fora do DAS poderá representar um aumento da carga tributária.

Por isso, é importante que cada empresa avalie sua situação e decida se deseja manter ou cancelar a opção realizada.

> Os clientes que desejarem desistir do regime híbrido deverão **comunicar expressamente essa decisão ao nosso Departamento Fiscal até 30/11/2026**, observando o prazo legal para cancelamento.

## Nosso compromisso

A Multcont está preparada para apoiar seus clientes nessa transição, sempre com transparência, responsabilidade e qualidade técnica.

Nosso objetivo é oferecer o suporte necessário, respeitando os prazos e a complexidade dos serviços, para que possamos continuar atendendo a todos com a qualidade que nossa parceria merece.

Contamos com a compreensão e permanecemos à disposição!`,
  },
];
