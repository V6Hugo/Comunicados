'use strict';
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const Database = require('better-sqlite3');

const DB_PATH = process.env.DB_PATH || path.join(__dirname, '..', 'data', 'comunicados.db');
fs.mkdirSync(path.dirname(DB_PATH), { recursive: true });

const db = new Database(DB_PATH);
db.pragma('journal_mode = WAL');      // leituras e escritas simultâneas sem travar
db.pragma('foreign_keys = ON');
db.pragma('busy_timeout = 5000');

// ---------- migrações de bancos criados por versões anteriores ----------
const colunas = (t) => db.prepare(`PRAGMA table_info(${t})`).all().map((c) => c.name);
if (colunas('sessoes_leitura').length && !colunas('sessoes_leitura').includes('email')) {
  db.exec(`ALTER TABLE sessoes_leitura ADD COLUMN email TEXT COLLATE NOCASE;
           ALTER TABLE sessoes_leitura ADD COLUMN email_fonte TEXT CHECK (email_fonte IN ('link','confirmacao','navegador'));`);
  if (colunas('confirmacoes_leitura').length) { // recupera o e-mail das leituras já confirmadas
    db.exec(`UPDATE sessoes_leitura SET email = (SELECT k.email FROM confirmacoes_leitura k WHERE k.sessao_id = sessoes_leitura.id), email_fonte = 'confirmacao'
             WHERE id IN (SELECT sessao_id FROM confirmacoes_leitura WHERE sessao_id IS NOT NULL);`);
  }
}

// vários gestores: perfis, ativação e controle de sessão
if (colunas('admin_usuarios').length && !colunas('admin_usuarios').includes('perfil')) {
  db.exec(`ALTER TABLE admin_usuarios ADD COLUMN perfil TEXT NOT NULL DEFAULT 'gestor' CHECK (perfil IN ('administrador','gestor','leitor'));
           ALTER TABLE admin_usuarios ADD COLUMN ativo INTEGER NOT NULL DEFAULT 1 CHECK (ativo IN (0,1));
           ALTER TABLE admin_usuarios ADD COLUMN trocar_senha INTEGER NOT NULL DEFAULT 0 CHECK (trocar_senha IN (0,1));
           ALTER TABLE admin_usuarios ADD COLUMN versao_sessao INTEGER NOT NULL DEFAULT 0;
           ALTER TABLE admin_usuarios ADD COLUMN ultimo_acesso TEXT;
           ALTER TABLE admin_usuarios ADD COLUMN criado_por TEXT;
           UPDATE admin_usuarios SET perfil = 'administrador';`); // quem já existia vira administrador
}
if (colunas('comunicados').length && !colunas('comunicados').includes('criado_por')) {
  db.exec('ALTER TABLE comunicados ADD COLUMN criado_por TEXT; ALTER TABLE comunicados ADD COLUMN atualizado_por TEXT;');
}

db.exec(fs.readFileSync(path.join(__dirname, 'schema.sql'), 'utf8'));
db.exec('CREATE INDEX IF NOT EXISTS ix_sessoes_email ON sessoes_leitura(email)');

// Setores oficiais: Pessoal, Fiscal, Tributário, Contábil e Geral
const SETORES = [
  { slug: 'pessoal',    nome: 'Pessoal',    descricao: 'Folha, férias, 13º, admissões e eSocial',                  cor: '#1f4470' },
  { slug: 'fiscal',     nome: 'Fiscal',     descricao: 'Notas fiscais, escrituração e obrigações acessórias',      cor: '#1f92bf' },
  { slug: 'tributario', nome: 'Tributário', descricao: 'Impostos, regimes tributários, planejamento e Reforma',     cor: '#00a6fb' },
  { slug: 'contabil',   nome: 'Contábil',   descricao: 'Balanços, conciliações e demonstrativos',                  cor: '#000000' },
  { slug: 'geral',      nome: 'Geral',      descricao: 'Avisos institucionais e atendimento',                      cor: '#727273' },
];
function aplicarSetores() {
  const zap = process.env.WHATSAPP_PADRAO || '5531997627365';
  const existe = db.prepare('SELECT id FROM departamentos WHERE slug = ?');
  const ins = db.prepare(`INSERT INTO departamentos (slug, nome, descricao, cor, whatsapp, mensagem_whatsapp, email, ordem)
    VALUES (@slug, @nome, @descricao, @cor, @whatsapp, @msg, 'contato@multcont.com.br', @ordem)`);
  SETORES.forEach((s, i) => {
    const e = existe.get(s.slug);
    if (e) db.prepare('UPDATE departamentos SET ordem = ?, ativo = 1 WHERE id = ?').run(i, e.id);
    else ins.run({ ...s, whatsapp: zap, ordem: i, msg: `Olá! Tenho uma dúvida sobre um comunicado do setor ${s.nome}.` });
  });
  // setores da versão anterior que não fazem parte da lista: desativa (não apaga histórico)
  db.prepare(`UPDATE departamentos SET ativo = 0 WHERE slug IN ('societario','financeiro')`).run();
}

// ---------- senha do painel (scrypt) ----------
function hashSenha(senha) {
  const salt = crypto.randomBytes(16).toString('hex');
  const hash = crypto.scryptSync(senha, salt, 64).toString('hex');
  return `${salt}:${hash}`;
}
function conferirSenha(senha, armazenado) {
  const [salt, hash] = String(armazenado).split(':');
  if (!salt || !hash) return false;
  const teste = crypto.scryptSync(senha, salt, 64);
  const ref = Buffer.from(hash, 'hex');
  return ref.length === teste.length && crypto.timingSafeEqual(ref, teste);
}

// ---------- dados iniciais ----------
function seed() {
  const versaoSetores = db.pragma('user_version', { simple: true });
  if (versaoSetores < 2) { aplicarSetores(); db.pragma('user_version = 2'); }
  if (db.pragma('user_version', { simple: true }) < 3) { // cores dos setores dentro da paleta oficial
    const up = db.prepare('UPDATE departamentos SET cor = ? WHERE slug = ?');
    SETORES.forEach((s) => up.run(s.cor, s.slug));
    db.pragma('user_version = 3');
  }

  const idSetor = (slug) => db.prepare('SELECT id FROM departamentos WHERE slug = ?').get(slug).id;
  const insCom = db.prepare(`INSERT INTO comunicados
      (numero, slug, titulo, resumo, conteudo_md, departamento_id, assinatura, prioridade, fixado, fixado_ate, status, publicado_em, criado_por)
      VALUES (@numero, @slug, @titulo, @resumo, @conteudo_md, @departamento_id, @assinatura, @prioridade, @fixado, @fixado_ate, 'publicado', @publicado_em, 'carga inicial')`);
  const oficiais = require('./exemplos');
  const temComunicados = db.prepare('SELECT COUNT(*) n FROM comunicados').get().n;
  if (!temComunicados) {
    for (const c of oficiais) insCom.run({ ...c, departamento_id: idSetor(c.depto) });
  } else if (db.pragma('user_version', { simple: true }) < 4) {
    // Bancos criados com os 3 avisos fictícios de demonstração: arquiva-os (mantendo o histórico)
    // e carrega os comunicados oficiais da Reforma Tributária.
    const FICTICIOS = ['Atendimento no fim de ano: recesso de 24/12 a 02/01', '13º salário e folha de dezembro: prazos para envio das informações', 'Fechamento do ano: documentos fiscais que precisamos até 15/01'];
    db.transaction(() => {
      db.prepare(`SELECT id, titulo FROM comunicados WHERE titulo IN (${FICTICIOS.map(() => '?').join(',')})`).all(...FICTICIOS).forEach((c, i) => {
        db.prepare("UPDATE comunicados SET numero = ?, slug = ?, status = 'arquivado', fixado = 0 WHERE id = ?").run(`EX-${c.id}`, `exemplo-${c.id}`, c.id);
      });
      for (const c of oficiais) {
        if (db.prepare('SELECT 1 FROM comunicados WHERE titulo = ?').get(c.titulo)) continue; // já carregado
        let { numero, slug } = c;
        if (db.prepare('SELECT 1 FROM comunicados WHERE slug = ?').get(slug)) { // número já usado: pega o próximo livre do ano
          const ano = numero.slice(-4);
          const max = Math.max(0, ...db.prepare('SELECT numero FROM comunicados WHERE numero LIKE ?').all(`%/${ano}`).map((x) => parseInt(x.numero, 10) || 0));
          numero = `${String(max + 1).padStart(3, '0')}/${ano}`; slug = numero.replace('/', '-');
        }
        insCom.run({ ...c, numero, slug, departamento_id: idSetor(c.depto) });
      }
    })();
  }
  if (db.pragma('user_version', { simple: true }) < 4) db.pragma('user_version = 4');

  const temAdmin = db.prepare('SELECT COUNT(*) n FROM admin_usuarios').get().n;
  if (!temAdmin) {
    const email = process.env.ADMIN_EMAIL || 'admin@multcont.com.br';
    // sem ADMIN_SENHA no .env, gera uma senha aleatória (nunca uma senha padrão conhecida)
    const senha = process.env.ADMIN_SENHA || crypto.randomBytes(9).toString('base64url');
    db.prepare("INSERT INTO admin_usuarios (nome, email, senha_hash, perfil, criado_por) VALUES (?, ?, ?, 'administrador', 'instalação')")
      .run(process.env.ADMIN_NOME || 'Administrador', email, hashSenha(senha));
    if (!process.env.ADMIN_SENHA) {
      console.warn(`\n[!] Acesso do operador criado: ${email}  senha: ${senha}\n    Anote agora — ela não será mostrada de novo. Troque em "Minha conta" e cadastre os demais gestores em "Gestores".\n`);
    }
  }
}
seed();

module.exports = { db, hashSenha, conferirSenha, DB_PATH };
