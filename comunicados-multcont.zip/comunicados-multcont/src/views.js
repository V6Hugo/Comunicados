'use strict';
const { esc, dataCurta, dataLonga, tempoLeitura } = require('./util');

const EMPRESA = {
  nome: 'Multcont',
  razao: 'MC Organização Contábil Ltda',
  cnpj: '05.457.555/0001-80',
  crc: 'CRC-MG 6855',
  telefone: '(31) 3201-4566', telefoneLink: '553132014566',
  whatsapp: '(31) 99762-7365', whatsappLink: '5531997627365',
  email: 'contato@multcont.com.br',
  endereco: 'Av. Augusto de Lima, 655, Conj. 309 — Centro, Belo Horizonte/MG',
  site: 'https://multcont.com.br',
};

// preenchido pelo server.js: endereço do painel e se mostra o link "Área restrita" no rodapé
const CONFIG = { painel: '/admin', linkRodape: true };

// Logotipo oficial (versão cinza para fundo claro, versão branca para fundo azul)
const logo = (claro = false) => `<a class="logo${claro ? ' logo--claro' : ''}" href="/" aria-label="Multcont — Comunicados"><img src="/img/${claro ? 'logo-multcont-branco' : 'logo-multcont'}.png" alt="Multcont" width="107" height="30"></a>`;

// Ícones de linha, discretos (traço 1.8, cor herdada do texto)
const ICONES = {
  pino: '<path d="M12 17v5"/><path d="M9 10.8V5h6v5.8l2.6 2.6c.6.6.2 1.6-.7 1.6H7.1c-.9 0-1.3-1-.7-1.6z"/><path d="M8 5h8"/>',
  seta: '<path d="M5 12h14"/><path d="m13 6 6 6-6 6"/>',
  voltar: '<path d="M19 12H5"/><path d="m11 18-6-6 6-6"/>',
  busca: '<circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/>',
  calendario: '<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M3 10h18M8 3v4M16 3v4"/>',
  relogio: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
  check: '<path d="m5 12.5 4.5 4.5L19 7.5"/>',
  imprimir: '<path d="M7 9V3h10v6"/><rect x="3" y="9" width="18" height="8" rx="2"/><path d="M7 14h10v7H7z"/>',
  fone: '<path d="M5 4h4l2 5-2.5 1.5a11 11 0 0 0 5 5L15 13l5 2v4a2 2 0 0 1-2 2A16 16 0 0 1 3 6a2 2 0 0 1 2-2"/>',
  email: '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3 7 9 6 9-6"/>',
  local: '<path d="M12 21s-7-6.2-7-11.5a7 7 0 0 1 14 0C19 14.8 12 21 12 21z"/><circle cx="12" cy="9.5" r="2.5"/>',
  conversa: '<path d="M21 11.5a8.5 8.5 0 0 1-12.4 7.6L3 21l1.9-5.6A8.5 8.5 0 1 1 21 11.5z"/>',
  casa: '<path d="M4 10.5 12 4l8 6.5V20a1 1 0 0 1-1 1h-5v-6h-4v6H5a1 1 0 0 1-1-1z"/>',
  grafico: '<path d="M4 20h16"/><path d="M7 16v-5M12 16V7M17 16v-8"/>',
  documento: '<path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z"/><path d="M14 3v5h5M9 13h6M9 17h4"/>',
  pessoas: '<circle cx="9" cy="8" r="3.5"/><path d="M3 20a6 6 0 0 1 12 0"/><path d="M16 4.5a3.5 3.5 0 0 1 0 7M21 20a6 6 0 0 0-4-5.6"/>',
  envio: '<path d="M21 3 10 14"/><path d="M21 3l-7 18-4-7-7-4z"/>',
  setores: '<rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/>',
  chave: '<circle cx="8" cy="15" r="4"/><path d="m11 12 9-9M17 6l3 3"/>',
  mais: '<path d="M12 5v14M5 12h14"/>',
  escudo: '<path d="M12 3 5 6v6c0 4.2 3 7.6 7 9 4-1.4 7-4.8 7-9V6z"/><path d="m9 12 2 2 4-4"/>',
  banco: '<ellipse cx="12" cy="6" rx="7" ry="3"/><path d="M5 6v12c0 1.7 3.1 3 7 3s7-1.3 7-3V6"/><path d="M5 12c0 1.7 3.1 3 7 3s7-1.3 7-3"/>',
};
const ic = (nome) => `<svg class="ic" viewBox="0 0 24 24" aria-hidden="true">${ICONES[nome]}</svg>`;

const PRIORIDADE = { importante: 'Importante', urgente: 'Urgente' };
const etiqueta = (c) => `<span class="tag" style="--tag:${esc(c.depto_cor)}">${esc(c.depto_nome)}</span>`;
const selo = (c) => (PRIORIDADE[c.prioridade] ? `<span class="selo selo--${c.prioridade}">${PRIORIDADE[c.prioridade]}</span>` : '');

function rodape() {
  const E = EMPRESA;
  return `
<footer class="rodape">
  <div class="container rodape__grid">
    <div>${logo(true)}
      <p class="rodape__slogan">Simplificando processos, ampliando resultados.</p>
    </div>
    <ul class="rodape__contatos">
      <li>${ic('conversa')}<a href="https://wa.me/${E.whatsappLink}" target="_blank" rel="noopener">WhatsApp ${E.whatsapp}</a></li>
      <li>${ic('fone')}<a href="tel:+${E.telefoneLink}">${E.telefone}</a></li>
      <li>${ic('email')}<a href="mailto:${E.email}">${E.email}</a></li>
      <li>${ic('local')}${E.endereco}</li>
    </ul>
  </div>
  <div class="container rodape__aviso">
    <p>Registramos a abertura, o tempo de leitura e a confirmação deste comunicado para garantir que informações importantes chegaram até você. Não usamos cookies.</p>
    <p>© ${new Date().getFullYear()} ${E.nome} · ${E.razao} · CNPJ ${E.cnpj} · ${E.crc}${CONFIG.linkRodape ? ` · <a class="rodape__restrito" href="${esc(CONFIG.painel)}" rel="nofollow">Área restrita</a>` : ''}</p>
  </div>
</footer>`;
}

// Barra que só aparece para o gestor logado no painel
function barraGestor(gestor, c) {
  if (!gestor) return '';
  const P = esc(CONFIG.painel), edita = gestor.perfil !== 'leitor';
  return `<div class="barra-gestor" role="region" aria-label="Atalhos do gestor"><div class="container barra-gestor__linha">
  <span><b>Área restrita</b> · ${esc(gestor.nome)} <small>(suas visitas não entram nos relatórios)</small></span>
  <nav>
    ${c && edita ? `<a href="${P}/comunicados/${c.id}/editar">Editar este aviso</a>
    <form method="post" action="${P}/comunicados/${c.id}/fixar"><input type="hidden" name="voltar" value="/${esc(c.slug)}"><button>${c.fixado ? 'Desafixar' : 'Fixar no topo'}</button></form>` : ''}
    ${c ? `<a href="${P}/comunicado/${c.id}">Relatório</a>` : `${edita ? `<a href="${P}/comunicados">Fixar / editar</a>` : ''}<a href="${P}/relatorios">Relatórios</a>`}
    ${edita ? `<a href="${P}/comunicados/novo" class="barra-gestor__novo">+ Novo comunicado</a>` : ''}
    <a href="${P}">Painel</a>
  </nav></div></div>`;
}

function layout({ titulo, descricao = '', corpo, pageData = null, scripts = [], gestor = null, comunicado = null }) {
  return `<!doctype html>
<html lang="pt-BR">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex, nofollow">
<title>${esc(titulo)}</title>
<meta name="description" content="${esc(descricao)}">
<meta property="og:title" content="${esc(titulo)}">
<meta property="og:description" content="${esc(descricao)}">
<meta property="og:site_name" content="Multcont">
<meta name="theme-color" content="#1F4470">
<link rel="icon" href="/img/multcont-icone.svg" type="image/svg+xml">
<link rel="preload" href="/fonts/montserrat-latin-400-normal.woff2" as="font" type="font/woff2" crossorigin>
<link rel="stylesheet" href="/css/marca.css">
<link rel="stylesheet" href="/css/site.css">
</head>
<body>
${barraGestor(gestor, comunicado)}
${corpo}
${rodape()}
${pageData ? `<script>window.PAGINA=${JSON.stringify(pageData).replace(/</g, '\\u003c')};</script>` : ''}
${scripts.map((s) => `<script src="${s}" defer></script>`).join('\n')}
</body>
</html>`;
}

function card(c, origem) {
  return `
<article class="card${c.fixado && origem === 'fixado' ? ' card--fixado' : ''}" style="--tag:${esc(c.depto_cor)}" data-depto="${esc(c.depto_slug)}" data-busca="${esc((c.titulo + ' ' + c.resumo + ' ' + c.numero).toLowerCase())}">
  ${c.fixado && origem === 'fixado' ? `<span class="card__fixado">${ic('pino')}Fixado</span>` : ''}
  <div class="card__meta">${etiqueta(c)}${selo(c)}<time datetime="${esc(c.publicado_em)}">${dataCurta(c.publicado_em)}</time></div>
  <h3 class="card__titulo"><a href="/${esc(c.slug)}" data-card="${esc(origem)}" data-comunicado="${c.id}">${esc(c.titulo)}</a></h3>
  <p class="card__resumo">${esc(c.resumo)}</p>
  <span class="card__link" aria-hidden="true">Ler comunicado ${ic('seta')}</span>
</article>`;
}

function paginaLista({ comunicados, departamentos, gestor }) {
  const fixados = comunicados.filter((c) => c.fixado);
  const contagem = Object.fromEntries(departamentos.map((d) => [d.slug, comunicados.filter((c) => c.depto_slug === d.slug).length]));
  const chips = departamentos.filter((d) => contagem[d.slug]).map((d) =>
    `<button type="button" class="chip" data-filtro="${esc(d.slug)}" style="--tag:${esc(d.cor)}">${esc(d.nome)} <span>${contagem[d.slug]}</span></button>`).join('');

  const corpo = `
<header class="topo"><div class="container topo__linha"><div class="topo__esq">${logo()}<span class="topo__rotulo">Comunicados</span></div></div></header>
<section class="hero">
  <div class="container">
    <span class="hero__selo">Central de comunicados</span>
    <h1>Avisos importantes para a sua empresa</h1>
    <p>Prazos, mudanças de legislação e orientações da Multcont, organizados por setor.</p>
    <div class="hero__numeros">
      <div><span class="numero">${String(comunicados.length).padStart(2, '0')}</span><span>comunicados ativos</span></div>
      ${fixados.length ? `<div><span class="numero">${String(fixados.length).padStart(2, '0')}</span><span>em destaque</span></div>` : ''}
      <div><span class="numero">${String(departamentos.filter((d) => contagem[d.slug]).length).padStart(2, '0')}</span><span>setores</span></div>
    </div>
  </div>
</section>
<main class="container principal">
  ${fixados.length ? `
  <section class="bloco bloco--fixados" aria-labelledby="t-fixados">
    <h2 id="t-fixados" class="bloco__titulo">${ic('pino')} Em destaque</h2>
    <div class="grade">${fixados.map((c) => card(c, 'fixado')).join('')}</div>
  </section>` : ''}
  <section class="bloco" aria-labelledby="t-todos">
    <div class="bloco__cabeca">
      <h2 id="t-todos" class="bloco__titulo">Todos os comunicados</h2>
      <label class="busca"><span class="sr">Buscar</span>${ic('busca')}<input type="search" id="busca" placeholder="Buscar comunicado…" autocomplete="off"></label>
    </div>
    <div class="filtros" role="toolbar" aria-label="Filtrar por setor">
      <button type="button" class="chip ativo" data-filtro="todos">Todos <span>${comunicados.length}</span></button>${chips}
    </div>
    <div class="grade" id="lista">${comunicados.map((c) => card(c, 'lista')).join('')}</div>
    <p class="vazio" id="vazio" hidden>Nenhum comunicado encontrado para este filtro.</p>
  </section>
</main>`;
  return layout({
    titulo: 'Comunicados · Multcont',
    descricao: 'Comunicados da Multcont aos clientes, separados por setor.',
    corpo, gestor, pageData: { tipo: 'lista', gestor: !!gestor }, scripts: ['/js/rastreio.js', '/js/lista.js'],
  });
}

function paginaComunicado({ c, html, outros, gestor }) {
  const msg = `${c.depto_msg || 'Olá! Tenho uma dúvida sobre um comunicado.'} (Comunicado ${c.numero} – ${c.titulo})`;
  const zap = `https://wa.me/${encodeURIComponent(c.depto_whatsapp)}?text=${encodeURIComponent(msg)}`;
  const corpo = `
<div class="progresso" aria-hidden="true"><span id="barra"></span></div>
<header class="topo"><div class="container topo__linha"><div class="topo__esq">${logo()}<span class="topo__rotulo">Comunicados</span></div><a class="topo__voltar" href="/">${ic('voltar')} Todos os comunicados</a></div></header>
<main class="container leitura">
  <article class="aviso" id="aviso">
    <div class="aviso__meta">${etiqueta(c)}${selo(c)}<span class="aviso__numero">Comunicado ${esc(c.numero)}</span></div>
    <h1 class="aviso__titulo">${esc(c.titulo)}</h1>
    <p class="aviso__data"><span>${ic('calendario')}<time datetime="${esc(c.publicado_em)}">${dataLonga(c.publicado_em)}</time></span><span>${ic('relogio')}Leitura de ${tempoLeitura(c.conteudo_md)} min</span></p>
    <div class="aviso__corpo" id="corpo">${html}</div>
    <div id="fim-do-texto" aria-hidden="true"></div>
    ${c.assinatura ? `<p class="aviso__assinatura">${esc(c.assinatura)}</p>` : ''}

    ${c.exige_confirmacao ? `
    <section class="confirmar" id="confirmar" aria-labelledby="t-conf">
      <h2 id="t-conf">Confirme a leitura.</h2>
      <p>Assim sabemos que a informação chegou a quem precisa e podemos avisar de novo quem ainda não viu.</p>
      <p class="confirmar__anteriores" id="anteriores" hidden></p>
      <form id="form-confirmar" novalidate>
        <label for="email">E-mail em que você recebeu este comunicado</label>
        <div class="confirmar__linha">
          <input id="email" name="email" type="email" inputmode="email" autocomplete="off" autocapitalize="off" spellcheck="false" placeholder="voce@suaempresa.com.br" required>
          <button type="submit" class="btn btn--primario" id="btn-ciente">Li e estou ciente</button>
        </div>
        <p class="confirmar__erro" id="erro" role="alert" hidden></p>
        <p class="confirmar__nota">Usamos o e-mail só para registrar a sua confirmação.</p>
      </form>
      <div class="confirmar__ok" id="ok" hidden role="status">
        ${ic('check')}
        <span>Leitura confirmada<span id="ok-email"></span>. Obrigado!</span>
        <button type="button" class="confirmar__outro" id="btn-outro">Confirmar com outro e-mail</button>
      </div>
    </section>` : ''}

    <div class="acoes">
      <a class="btn btn--whatsapp" id="btn-whatsapp" href="${esc(zap)}" target="_blank" rel="noopener">
        <svg width="18" height="18" viewBox="0 0 24 24" aria-hidden="true"><path fill="currentColor" d="M12 2a10 10 0 0 0-8.6 15.1L2 22l5-1.3A10 10 0 1 0 12 2zm5.3 14.2c-.2.6-1.3 1.2-1.8 1.2s-1 .3-3.4-.7a11.6 11.6 0 0 1-4.6-4.1c-.4-.6-1-1.8-1-3.1s.7-1.9.9-2.2.5-.3.7-.3h.5c.2 0 .4 0 .6.5l.9 2.1c.1.2.1.4 0 .6l-.4.6-.4.4c-.1.2-.3.3-.1.6a8.2 8.2 0 0 0 1.6 2 7.6 7.6 0 0 0 2.3 1.4c.3.1.5.1.6-.1l.9-1.1c.2-.3.4-.2.6-.1l2 1c.3.1.5.2.5.3a2.5 2.5 0 0 1-.1 1.3z"/></svg>
        Tirar dúvida no WhatsApp <small>Setor ${esc(c.depto_nome)}</small>
      </a>
      <button type="button" class="btn btn--secundario" id="btn-imprimir">${ic('imprimir')} Imprimir ou salvar em PDF</button>
    </div>
  </article>

  ${outros.length ? `
  <aside class="outros" aria-labelledby="t-outros">
    <div class="bloco__cabeca"><h2 id="t-outros" class="bloco__titulo">Outros comunicados</h2><a href="/" class="ver-todos">Ver todos ${ic('seta')}</a></div>
    <div class="grade">${outros.map((o) => card(o, 'outros')).join('')}</div>
  </aside>` : ''}
</main>`;
  return layout({
    titulo: `${c.titulo} · Comunicados Multcont`,
    descricao: c.resumo,
    corpo,
    gestor, comunicado: c,
    pageData: { tipo: 'comunicado', comunicado_id: c.id, numero: c.numero, gestor: !!gestor },
    scripts: ['/js/rastreio.js', '/js/comunicado.js'],
  });
}

function pagina404() {
  return layout({ titulo: 'Comunicado não encontrado · Multcont', corpo: `
<header class="topo"><div class="container topo__linha">${logo()}<a class="topo__voltar" href="/">${ic('voltar')} Todos os comunicados</a></div></header>
<main class="container leitura"><div class="aviso"><h1 class="aviso__titulo">Comunicado não encontrado</h1><p>O endereço pode ter mudado ou o comunicado foi arquivado.</p><p><a class="btn btn--primario" href="/">Ver todos os comunicados</a></p></div></main>` });
}

module.exports = { CONFIG, layout, paginaLista, paginaComunicado, pagina404, logo, ic, EMPRESA };
