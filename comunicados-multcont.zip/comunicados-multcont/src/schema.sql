-- =====================================================================
--  Comunicados Multcont — Banco de dados (SQLite 3.35+)
--  Registra: cliques (3º), tempo por aviso e tempo até a rolagem final (4º),
--  confirmações "Li e estou ciente" com e-mail (5º).
--  Todas as datas em UTC, formato ISO-8601 ('YYYY-MM-DD HH:MM:SS').
-- =====================================================================
PRAGMA foreign_keys = ON;

-- ---------------------------------------------------------------------
-- 1. CADASTROS
-- ---------------------------------------------------------------------

-- Setores da contabilidade. Cada aviso pertence a um setor, e o botão
-- "Tirar dúvida no WhatsApp" usa o número do setor responsável.
CREATE TABLE IF NOT EXISTS departamentos (
  id                INTEGER PRIMARY KEY,
  slug              TEXT    NOT NULL UNIQUE,             -- 'fiscal', 'pessoal'...
  nome              TEXT    NOT NULL,                    -- 'Fiscal'
  descricao         TEXT,
  cor               TEXT    NOT NULL DEFAULT '#1F92BF',  -- cor da etiqueta
  whatsapp          TEXT    NOT NULL,                    -- só dígitos com DDI: 5531997627365
  mensagem_whatsapp TEXT,                                -- texto inicial da conversa
  email             TEXT,
  responsavel       TEXT,
  ordem             INTEGER NOT NULL DEFAULT 0,
  ativo             INTEGER NOT NULL DEFAULT 1 CHECK (ativo IN (0,1)),
  criado_em         TEXT    NOT NULL DEFAULT (datetime('now'))
);

-- Os avisos em si.
CREATE TABLE IF NOT EXISTS comunicados (
  id                 INTEGER PRIMARY KEY,
  numero             TEXT    NOT NULL UNIQUE,            -- '003/2026'
  slug               TEXT    NOT NULL UNIQUE,            -- '003-2026' (vira a URL)
  titulo             TEXT    NOT NULL,
  resumo             TEXT    NOT NULL,
  conteudo_md        TEXT    NOT NULL,                   -- corpo em Markdown
  departamento_id    INTEGER NOT NULL REFERENCES departamentos(id),
  assinatura         TEXT,                               -- 'Equipe Fiscal · Multcont'
  prioridade         TEXT    NOT NULL DEFAULT 'normal'
                       CHECK (prioridade IN ('normal','importante','urgente')),
  fixado             INTEGER NOT NULL DEFAULT 0 CHECK (fixado IN (0,1)),
  fixado_ate         TEXT,                               -- opcional: desafixa sozinho após a data
  exige_confirmacao  INTEGER NOT NULL DEFAULT 1 CHECK (exige_confirmacao IN (0,1)),
  status             TEXT    NOT NULL DEFAULT 'rascunho'
                       CHECK (status IN ('rascunho','publicado','arquivado')),
  publicado_em       TEXT,                               -- data exibida no aviso
  criado_por         TEXT,                               -- e-mail do gestor que criou
  atualizado_por     TEXT,                               -- e-mail do último gestor que alterou
  criado_em          TEXT    NOT NULL DEFAULT (datetime('now')),
  atualizado_em      TEXT    NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS ix_comunicados_lista ON comunicados(status, fixado, publicado_em);
CREATE INDEX IF NOT EXISTS ix_comunicados_depto ON comunicados(departamento_id);

-- ---------------------------------------------------------------------
-- 2. RASTREAMENTO
-- ---------------------------------------------------------------------

-- Navegador anônimo (id aleatório guardado no localStorage — sem cookies).
-- Permite contar visitantes únicos e ligar várias leituras da mesma pessoa.
CREATE TABLE IF NOT EXISTS visitantes (
  id               TEXT PRIMARY KEY,                     -- UUID gerado no navegador
  primeiro_acesso  TEXT NOT NULL DEFAULT (datetime('now')),
  ultimo_acesso    TEXT NOT NULL DEFAULT (datetime('now')),
  dispositivo      TEXT CHECK (dispositivo IN ('desktop','celular','tablet')),
  user_agent       TEXT,
  email            TEXT                                  -- preenchido após a 1ª confirmação
);

-- Uma linha por abertura de um aviso (ponto 4º).
--  tempo_total_ms  : tempo com a aba visível
--  tempo_ativo_ms  : tempo visível E com interação recente (rolagem, mouse, toque, teclado)
--  rolagem_max_pct : até onde o leitor chegou (0–100)
--  tempo_ate_fim_ms: tempo ativo gasto até atingir o final do texto (NULL = não chegou)
CREATE TABLE IF NOT EXISTS sessoes_leitura (
  id                TEXT    PRIMARY KEY,                 -- UUID
  comunicado_id     INTEGER NOT NULL REFERENCES comunicados(id) ON DELETE CASCADE,
  visitante_id      TEXT    NOT NULL REFERENCES visitantes(id),
  iniciada_em       TEXT    NOT NULL DEFAULT (datetime('now')),
  ultima_atividade  TEXT    NOT NULL DEFAULT (datetime('now')),
  tempo_total_ms    INTEGER NOT NULL DEFAULT 0 CHECK (tempo_total_ms >= 0),
  tempo_ativo_ms    INTEGER NOT NULL DEFAULT 0 CHECK (tempo_ativo_ms >= 0),
  rolagem_max_pct   INTEGER NOT NULL DEFAULT 0 CHECK (rolagem_max_pct BETWEEN 0 AND 100),
  chegou_ao_fim     INTEGER NOT NULL DEFAULT 0 CHECK (chegou_ao_fim IN (0,1)),
  tempo_ate_fim_ms  INTEGER,
  origem            TEXT,                                -- utm_source / 'lista' / 'direto' / domínio de referência
  campanha          TEXT,                                -- utm_campaign
  dispositivo       TEXT,
  largura_tela      INTEGER,
  ip_hash           TEXT,                                -- SHA-256 do IP + sal (LGPD: nunca o IP puro)
  email             TEXT COLLATE NOCASE,                 -- quem leu, quando sabemos (ver email_fonte)
  email_fonte       TEXT CHECK (email_fonte IN ('link','confirmacao','navegador'))
                                                         -- link: veio no ?e= do e-mail enviado
                                                         -- confirmacao: digitou no "Li e estou ciente"
                                                         -- navegador: mesmo navegador já confirmou outro aviso
);
CREATE INDEX IF NOT EXISTS ix_sessoes_comunicado ON sessoes_leitura(comunicado_id, iniciada_em);
CREATE INDEX IF NOT EXISTS ix_sessoes_visitante  ON sessoes_leitura(visitante_id);

-- Lista de clientes que DEVEM ler os avisos (opcional). Com ela o relatório mostra
-- também quem NÃO abriu. Pode ser filtrada por setor (vazio = recebe todos).
CREATE TABLE IF NOT EXISTS contatos (
  id         INTEGER PRIMARY KEY,
  email      TEXT NOT NULL UNIQUE COLLATE NOCASE,
  nome       TEXT,
  empresa    TEXT,
  ativo      INTEGER NOT NULL DEFAULT 1 CHECK (ativo IN (0,1)),
  criado_em  TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Log de cliques e marcos (ponto 3º). Uma linha por acontecimento.
CREATE TABLE IF NOT EXISTS eventos (
  id             INTEGER PRIMARY KEY,
  tipo           TEXT    NOT NULL CHECK (tipo IN (
                   'visita_lista',        -- abriu a página inicial
                   'filtro_departamento', -- clicou num filtro de setor (alvo = slug)
                   'clique_card',         -- clicou num aviso na lista (alvo = 'fixado' | 'lista' | 'outros')
                   'abertura',            -- abriu a página do aviso
                   'rolagem_25','rolagem_50','rolagem_75','rolagem_100',
                   'clique_whatsapp',
                   'clique_imprimir',
                   'clique_link',         -- link dentro do texto (alvo = URL)
                   'confirmacao'          -- clicou em "Li e estou ciente"
                 )),
  comunicado_id  INTEGER REFERENCES comunicados(id) ON DELETE CASCADE,
  sessao_id      TEXT    REFERENCES sessoes_leitura(id) ON DELETE CASCADE,
  visitante_id   TEXT    REFERENCES visitantes(id),
  alvo           TEXT,
  valor_ms       INTEGER,                               -- tempo ativo no momento do evento
  criado_em      TEXT    NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS ix_eventos_comunicado ON eventos(comunicado_id, tipo, criado_em);
CREATE INDEX IF NOT EXISTS ix_eventos_tipo       ON eventos(tipo, criado_em);

-- "Li e estou ciente" (ponto 5º). Um registro por e-mail por aviso.
-- Se a pessoa confirmar de novo, a linha é atualizada (fica a leitura mais completa).
CREATE TABLE IF NOT EXISTS confirmacoes_leitura (
  id                INTEGER PRIMARY KEY,
  comunicado_id     INTEGER NOT NULL REFERENCES comunicados(id) ON DELETE CASCADE,
  email             TEXT    NOT NULL COLLATE NOCASE,
  sessao_id         TEXT    REFERENCES sessoes_leitura(id) ON DELETE SET NULL,
  visitante_id      TEXT    REFERENCES visitantes(id),
  leu_ate_o_fim     INTEGER NOT NULL DEFAULT 0 CHECK (leu_ate_o_fim IN (0,1)),
  rolagem_pct       INTEGER NOT NULL DEFAULT 0,
  tempo_ativo_ms    INTEGER NOT NULL DEFAULT 0,
  tempo_ate_fim_ms  INTEGER,
  confirmado_em     TEXT    NOT NULL DEFAULT (datetime('now')),
  ip_hash           TEXT,
  user_agent        TEXT,
  UNIQUE (comunicado_id, email)
);
CREATE INDEX IF NOT EXISTS ix_confirmacoes_email ON confirmacoes_leitura(email);

-- ---------------------------------------------------------------------
-- 3. ACESSO AO PAINEL
-- ---------------------------------------------------------------------
-- Gestores com acesso à área restrita. Cada um tem login próprio.
--  administrador: tudo, inclusive cadastrar gestores e setores
--  gestor       : comunicados, envios, clientes e relatórios
--  leitor       : só vê relatórios e exporta planilhas
CREATE TABLE IF NOT EXISTS admin_usuarios (
  id            INTEGER PRIMARY KEY,
  nome          TEXT NOT NULL,
  email         TEXT NOT NULL UNIQUE COLLATE NOCASE,
  senha_hash    TEXT NOT NULL,                          -- scrypt: 'salt:hash'
  perfil        TEXT NOT NULL DEFAULT 'gestor' CHECK (perfil IN ('administrador','gestor','leitor')),
  ativo         INTEGER NOT NULL DEFAULT 1 CHECK (ativo IN (0,1)),
  trocar_senha  INTEGER NOT NULL DEFAULT 0 CHECK (trocar_senha IN (0,1)),  -- obriga a criar senha própria no 1º acesso
  versao_sessao INTEGER NOT NULL DEFAULT 0,             -- muda ao desativar/redefinir senha: derruba sessões abertas
  ultimo_acesso TEXT,
  criado_por    TEXT,
  criado_em     TEXT NOT NULL DEFAULT (datetime('now'))
);

-- ---------------------------------------------------------------------
-- 4. VIEWS DE RELATÓRIO (consultáveis direto no banco ou pelo painel)
-- ---------------------------------------------------------------------

-- Resumo por aviso: a tabela principal do painel.
DROP VIEW IF EXISTS vw_metricas_comunicado;
CREATE VIEW vw_metricas_comunicado AS
SELECT
  c.id, c.numero, c.slug, c.titulo, c.status, c.fixado, c.publicado_em,
  d.id   AS departamento_id,
  d.nome AS departamento,
  (SELECT COUNT(*) FROM eventos e WHERE e.comunicado_id = c.id AND e.tipo = 'clique_card')      AS cliques_lista,
  COUNT(s.id)                                                                                   AS aberturas,
  COUNT(DISTINCT s.visitante_id)                                                                AS leitores_unicos,
  ROUND(AVG(s.tempo_ativo_ms) / 1000.0, 1)                                                      AS tempo_medio_ativo_s,
  ROUND(AVG(s.tempo_total_ms) / 1000.0, 1)                                                      AS tempo_medio_total_s,
  ROUND(AVG(s.rolagem_max_pct), 1)                                                              AS rolagem_media_pct,
  SUM(s.chegou_ao_fim)                                                                          AS leituras_completas,
  ROUND(100.0 * SUM(s.chegou_ao_fim) / NULLIF(COUNT(s.id), 0), 1)                              AS pct_leitura_completa,
  ROUND(AVG(s.tempo_ate_fim_ms) / 1000.0, 1)                                                    AS tempo_medio_ate_fim_s,
  (SELECT COUNT(*) FROM confirmacoes_leitura k WHERE k.comunicado_id = c.id)                    AS confirmacoes,
  (SELECT COUNT(*) FROM confirmacoes_leitura k WHERE k.comunicado_id = c.id AND k.leu_ate_o_fim = 1) AS confirmacoes_lidas_ate_fim,
  (SELECT COUNT(*) FROM eventos e WHERE e.comunicado_id = c.id AND e.tipo = 'clique_whatsapp')  AS cliques_whatsapp,
  (SELECT COUNT(*) FROM eventos e WHERE e.comunicado_id = c.id AND e.tipo = 'clique_imprimir')  AS cliques_imprimir,
  MAX(s.iniciada_em)                                                                            AS ultima_abertura
FROM comunicados c
JOIN departamentos d ON d.id = c.departamento_id
LEFT JOIN sessoes_leitura s ON s.comunicado_id = c.id
GROUP BY c.id;

-- Resumo por setor.
DROP VIEW IF EXISTS vw_metricas_departamento;
CREATE VIEW vw_metricas_departamento AS
SELECT
  d.id, d.nome, d.slug,
  COUNT(DISTINCT c.id)                                                AS comunicados,
  COUNT(s.id)                                                         AS aberturas,
  COUNT(DISTINCT s.visitante_id)                                      AS leitores_unicos,
  ROUND(AVG(s.tempo_ativo_ms) / 1000.0, 1)                            AS tempo_medio_ativo_s,
  ROUND(100.0 * SUM(s.chegou_ao_fim) / NULLIF(COUNT(s.id), 0), 1)    AS pct_leitura_completa,
  (SELECT COUNT(*) FROM confirmacoes_leitura k JOIN comunicados c2 ON c2.id = k.comunicado_id
     WHERE c2.departamento_id = d.id)                                 AS confirmacoes,
  (SELECT COUNT(*) FROM eventos e JOIN comunicados c3 ON c3.id = e.comunicado_id
     WHERE c3.departamento_id = d.id AND e.tipo = 'clique_whatsapp')  AS cliques_whatsapp
FROM departamentos d
LEFT JOIN comunicados c ON c.departamento_id = d.id AND c.status <> 'rascunho'
LEFT JOIN sessoes_leitura s ON s.comunicado_id = c.id
GROUP BY d.id;

-- Aberturas por dia (horário de Brasília).
DROP VIEW IF EXISTS vw_aberturas_diarias;
CREATE VIEW vw_aberturas_diarias AS
SELECT
  comunicado_id,
  date(iniciada_em, '-3 hours')         AS dia,
  COUNT(*)                              AS aberturas,
  COUNT(DISTINCT visitante_id)          AS leitores_unicos,
  SUM(chegou_ao_fim)                    AS leituras_completas
FROM sessoes_leitura
GROUP BY comunicado_id, dia;

-- Funil de rolagem: quantas aberturas passaram de cada marco.
DROP VIEW IF EXISTS vw_funil_rolagem;
CREATE VIEW vw_funil_rolagem AS
SELECT
  comunicado_id,
  COUNT(*)                                          AS abriram,
  SUM(CASE WHEN rolagem_max_pct >= 25  THEN 1 ELSE 0 END) AS passaram_25,
  SUM(CASE WHEN rolagem_max_pct >= 50  THEN 1 ELSE 0 END) AS passaram_50,
  SUM(CASE WHEN rolagem_max_pct >= 75  THEN 1 ELSE 0 END) AS passaram_75,
  SUM(chegou_ao_fim)                                AS chegaram_ao_fim
FROM sessoes_leitura
GROUP BY comunicado_id;

-- Lista nominal de quem confirmou (para auditoria / exportação).
DROP VIEW IF EXISTS vw_confirmacoes_detalhe;
CREATE VIEW vw_confirmacoes_detalhe AS
SELECT
  k.id, c.numero, c.titulo, d.nome AS departamento,
  k.email,
  datetime(k.confirmado_em, '-3 hours')   AS confirmado_em_brt,
  CASE k.leu_ate_o_fim WHEN 1 THEN 'Sim' ELSE 'Não' END AS leu_ate_o_fim,
  k.rolagem_pct,
  ROUND(k.tempo_ativo_ms / 1000.0, 0)     AS tempo_ativo_s,
  ROUND(k.tempo_ate_fim_ms / 1000.0, 0)   AS tempo_ate_fim_s,
  k.comunicado_id
FROM confirmacoes_leitura k
JOIN comunicados c   ON c.id = k.comunicado_id
JOIN departamentos d ON d.id = c.departamento_id;

-- Leitura por PESSOA em cada aviso (junta todas as aberturas da mesma pessoa).
-- Pessoa = e-mail (do link, da confirmação ou do navegador já identificado);
-- sem e-mail, fica como 'anonimo:<id do navegador>'.
DROP VIEW IF EXISTS vw_leitura_por_pessoa;
CREATE VIEW vw_leitura_por_pessoa AS
WITH s AS (
  SELECT s.*, LOWER(COALESCE(s.email, v.email)) AS pessoa_email
  FROM sessoes_leitura s JOIN visitantes v ON v.id = s.visitante_id
)
SELECT
  comunicado_id,
  COALESCE(pessoa_email, 'anonimo:' || visitante_id)  AS pessoa,
  pessoa_email                                        AS email,
  COUNT(*)                                            AS aberturas,
  MIN(iniciada_em)                                    AS primeiro_acesso,
  MAX(ultima_atividade)                               AS ultimo_acesso,
  MAX(rolagem_max_pct)                                AS rolagem_max,
  MAX(chegou_ao_fim)                                  AS chegou_ao_fim,
  SUM(tempo_ativo_ms)                                 AS tempo_ativo_total_ms,
  MIN(tempo_ate_fim_ms)                               AS tempo_ate_fim_ms,
  GROUP_CONCAT(DISTINCT dispositivo)                  AS dispositivos,
  GROUP_CONCAT(DISTINCT email_fonte)                  AS fontes_email
FROM s
GROUP BY comunicado_id, pessoa;

-- ---------------------------------------------------------------------
-- 5. ENVIO DE COMUNICADOS POR E-MAIL (lote ou individual)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS envios (
  id             INTEGER PRIMARY KEY,
  comunicado_id  INTEGER NOT NULL REFERENCES comunicados(id) ON DELETE CASCADE,
  tipo           TEXT    NOT NULL CHECK (tipo IN ('lote','individual')),
  publico        TEXT,                                   -- descrição: "Todos os clientes", "Quem ainda não abriu"...
  assunto        TEXT    NOT NULL,
  mensagem       TEXT,                                   -- texto de abertura opcional
  base_url       TEXT    NOT NULL,                       -- endereço do site usado nos links
  modo           TEXT    NOT NULL CHECK (modo IN ('smtp','teste')),
  status         TEXT    NOT NULL DEFAULT 'na_fila' CHECK (status IN ('na_fila','enviando','concluido','cancelado')),
  criado_por     TEXT,
  criado_em      TEXT    NOT NULL DEFAULT (datetime('now')),
  concluido_em   TEXT
);
CREATE INDEX IF NOT EXISTS ix_envios_comunicado ON envios(comunicado_id);

CREATE TABLE IF NOT EXISTS envio_destinatarios (
  id           INTEGER PRIMARY KEY,
  envio_id     INTEGER NOT NULL REFERENCES envios(id) ON DELETE CASCADE,
  email        TEXT    NOT NULL COLLATE NOCASE,
  nome         TEXT,
  token        TEXT    NOT NULL UNIQUE,                  -- identifica abertura do e-mail e clique no link
  status       TEXT    NOT NULL DEFAULT 'pendente' CHECK (status IN ('pendente','enviado','erro','cancelado')),
  tentativas   INTEGER NOT NULL DEFAULT 0,
  erro         TEXT,
  enviado_em   TEXT,
  email_aberto_em TEXT,                                  -- imagem de rastreio carregada (aproximado: alguns leitores bloqueiam)
  link_clicado_em TEXT,                                  -- abriu o aviso pelo link deste e-mail
  UNIQUE (envio_id, email)
);
CREATE INDEX IF NOT EXISTS ix_envio_dest_status ON envio_destinatarios(status, envio_id);
CREATE INDEX IF NOT EXISTS ix_envio_dest_email  ON envio_destinatarios(email);
