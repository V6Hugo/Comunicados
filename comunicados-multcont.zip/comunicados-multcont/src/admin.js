'use strict';
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const express = require('express');
const { marked } = require('marked');
const { db, conferirSenha, hashSenha } = require('./db');
const { esc, dataCurta, dataHoraBR, duracao, slugify, csv, EMAIL_RE } = require('./util');
const { logo, ic } = require('./views');

const r = express.Router();

// Endereço do painel: defina PAINEL_CAMINHO no .env com algo que só o operador saiba
// (ex.: /gestao-7f3k9). Os links internos são escritos como /admin e trocados aqui.
const CAMINHO = ('/' + String(process.env.PAINEL_CAMINHO || '/admin').replace(/^\/+|\/+$/g, '')) || '/admin';
r.use((req, res, next) => {
  const enviar = res.send.bind(res), redir = res.redirect.bind(res);
  res.send = (b) => enviar(typeof b === 'string' && CAMINHO !== '/admin' ? b.replace(/(["'(=`])\/admin(?=[\/"'?#`&])/g, `$1${CAMINHO}`) : b);
  res.redirect = (u) => redir(typeof u === 'string' ? u.replace(/^\/admin(?=$|[\/?#])/, CAMINHO) : u);
  next();
});

// ---------------------------------------------------------------------
// Autenticação (cookie assinado com HMAC, só no painel)
// ---------------------------------------------------------------------
const ARQ_SEGREDO = path.join(path.dirname(require('./db').DB_PATH), '.segredo');
const SEGREDO = process.env.SESSAO_SEGREDO || (() => {
  if (!fs.existsSync(ARQ_SEGREDO)) fs.writeFileSync(ARQ_SEGREDO, crypto.randomBytes(32).toString('hex'), { mode: 0o600 });
  return fs.readFileSync(ARQ_SEGREDO, 'utf8').trim();
})();
const COOKIE = 'mc_painel';
const assinar = (v) => crypto.createHmac('sha256', SEGREDO).update(v).digest('hex');
function lerCookie(req) {
  const m = (req.headers.cookie || '').match(new RegExp(`(?:^|; )${COOKIE}=([^;]+)`));
  if (!m) return null;
  const [uid, ver, exp, sig] = decodeURIComponent(m[1]).split('.');
  if (!sig || !crypto.timingSafeEqual(Buffer.from(assinar(`${uid}.${ver}.${exp}`)), Buffer.from(sig.padEnd(64, '0').slice(0, 64))) || Date.now() > Number(exp)) return null;
  const u = db.prepare('SELECT id, nome, email, perfil, ativo, trocar_senha, versao_sessao FROM admin_usuarios WHERE id = ?').get(Number(uid));
  // gestor desativado ou com senha redefinida perde o acesso na hora
  return u && u.ativo === 1 && String(u.versao_sessao) === ver ? u : null;
}
function gravarCookie(res, u) {
  const exp = Date.now() + 12 * 3600 * 1000;
  const v = `${u.id}.${u.versao_sessao}.${exp}`;
  const seguro = process.env.NODE_ENV === 'production' ? '; Secure' : '';
  res.setHeader('Set-Cookie', `${COOKIE}=${encodeURIComponent(`${v}.${assinar(v)}`)}; Path=/; HttpOnly; SameSite=Strict; Max-Age=43200${seguro}`);
}

r.use((req, res, next) => { res.set('Cache-Control', 'no-store'); res.set('X-Robots-Tag', 'noindex'); next(); });

r.get('/login', (req, res) => res.send(telaLogin()));
const tentativas = new Map();
r.post('/login', (req, res) => {
  const chave = req.ip;
  const t = tentativas.get(chave) || { n: 0, ate: 0 };
  if (t.ate > Date.now()) return res.status(429).send(telaLogin('Muitas tentativas. Aguarde alguns minutos.'));
  const u = db.prepare('SELECT * FROM admin_usuarios WHERE email = ?').get(String(req.body.email || '').trim());
  if (!u || !conferirSenha(String(req.body.senha || ''), u.senha_hash) || u.ativo !== 1) {
    t.n += 1; if (t.n >= 5) { t.ate = Date.now() + 10 * 60 * 1000; t.n = 0; }
    tentativas.set(chave, t);
    return res.status(401).send(telaLogin('E-mail ou senha incorretos.'));
  }
  tentativas.delete(chave);
  db.prepare("UPDATE admin_usuarios SET ultimo_acesso = datetime('now') WHERE id = ?").run(u.id);
  gravarCookie(res, u);
  res.redirect(u.trocar_senha ? '/admin/conta?primeiro=1' : '/admin');
});
r.get('/sair', (req, res) => { res.setHeader('Set-Cookie', [`${COOKIE}=; Path=/; Max-Age=0`, `${COOKIE}=; Path=${CAMINHO}; Max-Age=0`]); res.redirect('/admin/login'); });

r.use((req, res, next) => {
  const u = lerCookie(req);
  if (!u) return req.method === 'GET' ? res.redirect('/admin/login') : res.status(401).end();
  if (req.method === 'POST') { // proteção contra envio de outro site
    const origem = req.get('origin');
    if (origem && new URL(origem).host !== req.get('host')) return res.status(403).end();
  }
  req.usuario = u;
  // primeiro acesso / senha redefinida: precisa criar a própria senha antes de usar o painel
  if (u.trocar_senha && !/^\/(conta|sair)/.test(req.path)) return req.method === 'GET' ? res.redirect('/admin/conta?primeiro=1') : res.status(403).end();
  if (!permitido(u.perfil, req.method, req.path)) {
    return req.method === 'GET' ? res.status(403).send(tela(req, 'Sem permissão', `<div class="cabeca"><div><h1>Sem permissão</h1><p class="sub">Seu perfil (${PERFIS[u.perfil].nome}) não dá acesso a esta área. Fale com um administrador.</p></div></div>`)) : res.status(403).end();
  }
  next();
});

// ---------------------------------------------------------------------
// Perfis de acesso
// ---------------------------------------------------------------------
const PERFIS = {
  administrador: { nome: 'Administrador', desc: 'Tudo, inclusive cadastrar gestores e editar setores' },
  gestor:        { nome: 'Gestor',        desc: 'Cria, publica e fixa comunicados, envia e-mails, vê relatórios' },
  leitor:        { nome: 'Leitor',        desc: 'Só acompanha relatórios e exporta planilhas' },
};
// [método, caminho, perfis que podem]  — a primeira regra que bater vale
const REGRAS = [
  [/.*/, /^\/(gestores|departamentos)(\/|$)/, ['administrador']],
  [/.*/, /^\/(envios|contatos|previa)(\/|$)/, ['administrador', 'gestor']],
  [/^POST$/, /^\/comunicados(\/|$)/, ['administrador', 'gestor']],
  [/.*/, /^\/comunicados\/(novo|\d+\/(editar|duplicar))/, ['administrador', 'gestor']],
];
function permitido(perfil, metodo, caminho) {
  for (const [m, c, ps] of REGRAS) if (m.test(metodo) && c.test(caminho)) return ps.includes(perfil);
  return true; // início, relatórios, lista de comunicados, exportações e minha conta: todos
}
const pode = (req, caminho, metodo = 'GET') => permitido(req.usuario.perfil, metodo, caminho);

// ---------------------------------------------------------------------
// Layout do painel
// ---------------------------------------------------------------------
function tela(req, titulo, corpo, ativo = '') {
  const ICN = { inicio: 'casa', dash: 'grafico', com: 'documento', cli: 'pessoas', env: 'envio', dep: 'setores', ges: 'escudo', conta: 'chave' };
  const item = (href, nome, chave) => (pode(req, href.replace(/^\/admin/, '') || '/') ? `<a href="${href}" class="${ativo === chave ? 'ativo' : ''}">${ic(ICN[chave])}${nome}</a>` : '');
  return `<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex, nofollow"><title>${esc(titulo)} · Painel Multcont</title>
<link rel="icon" href="/img/multcont-icone.svg" type="image/svg+xml">
<link rel="stylesheet" href="/css/marca.css"><link rel="stylesheet" href="/css/painel.css"></head><body data-painel="/admin" data-perfil="${req.usuario.perfil}">
<aside class="lateral">
  ${logo(true)}<span class="lateral__rotulo">Painel de comunicados</span>
  <nav>${item('/admin', 'Início', 'inicio')}${item('/admin/relatorios', 'Relatórios', 'dash')}${item('/admin/comunicados', 'Comunicados', 'com')}${item('/admin/envios', 'Envios por e-mail', 'env')}${item('/admin/contatos', 'Clientes (e-mails)', 'cli')}${item('/admin/departamentos', 'Setores e WhatsApp', 'dep')}${item('/admin/gestores', 'Gestores', 'ges')}${item('/admin/conta', 'Minha conta', 'conta')}</nav>
  <div class="lateral__rodape"><a href="/" target="_blank">Ver site ↗</a><span><b>${esc(req.usuario.nome)}</b><br>${esc(req.usuario.email)}<br><small class="perfil-tag">${PERFIS[req.usuario.perfil].nome}</small></span><a href="/admin/sair">Sair</a></div>
</aside>
<main class="painel">${corpo}</main>
<script src="/js/painel.js" defer></script>
</body></html>`;
}
function telaLogin(erro = '') {
  return `<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><meta name="robots" content="noindex">
<title>Entrar · Painel Multcont</title><link rel="stylesheet" href="/css/marca.css"><link rel="stylesheet" href="/css/painel.css"></head>
<body class="login"><form method="post" action="/admin/login" class="login__caixa">${logo()}<span class="login__selo">Área restrita</span><h1>Painel de comunicados</h1><p class="sub">Acesso exclusivo para gestores da Multcont.</p>
${erro ? `<p class="alerta">${esc(erro)}</p>` : ''}
<label>E-mail<input name="email" type="email" required autofocus></label>
<label>Senha<input name="senha" type="password" required></label>
<button class="btn btn--primario">Entrar</button></form></body></html>`;
}

// ---------------------------------------------------------------------
// Filtros de período / setor
// ---------------------------------------------------------------------
const PERIODOS = { 7: 'Últimos 7 dias', 30: 'Últimos 30 dias', 90: 'Últimos 90 dias', todos: 'Desde o início' };
function filtros(req) {
  const periodo = PERIODOS[req.query.periodo] ? req.query.periodo : '30';
  const desde = periodo === 'todos' ? '0000-00-00' : new Date(Date.now() - Number(periodo) * 864e5).toISOString().slice(0, 19).replace('T', ' ');
  const depto = Number(req.query.depto) || null;
  return { periodo, desde, depto };
}
function barraFiltros(f, comDepto = true) {
  const deptos = db.prepare('SELECT id, nome FROM departamentos WHERE ativo = 1 ORDER BY ordem').all();
  return `<form class="filtros-painel" method="get">
    <label>Período <select name="periodo" onchange="this.form.submit()">${Object.entries(PERIODOS).map(([k, v]) => `<option value="${k}" ${k === f.periodo ? 'selected' : ''}>${v}</option>`).join('')}</select></label>
    ${comDepto ? `<label>Setor <select name="depto" onchange="this.form.submit()"><option value="">Todos</option>${deptos.map((d) => `<option value="${d.id}" ${d.id === f.depto ? 'selected' : ''}>${esc(d.nome)}</option>`).join('')}</select></label>` : ''}
  </form>`;
}
const pct = (a, b) => (b ? Math.round((1000 * a) / b) / 10 : 0);
const kpi = (rotulo, valor, detalhe = '') => `<div class="kpi"><span class="kpi__rotulo">${rotulo}</span><strong class="kpi__valor">${valor}</strong>${detalhe ? `<span class="kpi__detalhe">${detalhe}</span>` : ''}</div>`;
const num = (n) => Number(n || 0).toLocaleString('pt-BR');

// Gráfico de barras (uma série) — aberturas por dia
function graficoDiario(linhas, periodo) {
  const hojeBR = new Date(Date.now() - 3 * 3600e3).toISOString().slice(0, 10);
  const total = periodo === 'todos'
    ? (linhas.length ? Math.round((new Date(hojeBR) - new Date(linhas[0].dia)) / 864e5) + 1 : 0)
    : Number(periodo);
  const nDias = Math.min(120, total);
  const mapa = Object.fromEntries(linhas.map((l) => [l.dia, l]));
  const dias = [];
  for (let i = nDias - 1; i >= 0; i--) {
    const k = new Date(new Date(hojeBR).getTime() - i * 864e5).toISOString().slice(0, 10);
    dias.push({ dia: k, n: mapa[k]?.aberturas || 0 });
  }
  if (!dias.length) return '<p class="vazio">Sem aberturas no período.</p>';
  const max = Math.max(1, ...dias.map((d) => d.n));
  const W = 760, H = 180, base = H - 22, larg = W / dias.length, bw = Math.max(2, Math.min(28, larg - 2));
  const passo = Math.ceil(dias.length / 8);
  const barras = dias.map((d, i) => {
    const h = d.n ? Math.max(3, (d.n / max) * (base - 14)) : 0; const x = i * larg + (larg - bw) / 2;
    return `<g class="g-barra"><rect class="g-alvo" x="${i * larg}" y="0" width="${larg}" height="${base}" fill="transparent"/>
      ${h ? `<path d="M${x},${base} v-${h - 4} q0,-4 4,-4 h${bw - 8} q4,0 4,4 v${h - 4} z" fill="#1F92BF"/>` : ''}
      <title>${dataCurta(d.dia)}: ${d.n} abertura${d.n === 1 ? '' : 's'}</title></g>
      ${i % passo === 0 ? `<text x="${i * larg + larg / 2}" y="${H - 6}" text-anchor="middle" class="g-eixo">${d.dia.slice(8, 10)}/${d.dia.slice(5, 7)}</text>` : ''}`;
  }).join('');
  return `<svg class="grafico" viewBox="0 0 ${W} ${H}" role="img" aria-label="Aberturas por dia; máximo de ${max} em um dia">
    <line x1="0" x2="${W}" y1="${base}" y2="${base}" class="g-base"/>
    <text x="0" y="10" class="g-eixo">máx. ${max}/dia</text>${barras}</svg>`;
}
// Funil horizontal (uma série)
function funil(etapas) {
  const topo = Math.max(1, etapas[0].n);
  return `<div class="funil">${etapas.map((e) => `
    <div class="funil__linha"><span class="funil__rotulo">${e.rotulo}</span>
      <span class="funil__trilho"><span class="funil__barra" style="width:${Math.max(e.n ? 1.5 : 0, (100 * e.n) / topo)}%"></span></span>
      <span class="funil__valor">${num(e.n)} <small>${pct(e.n, topo)}%</small></span></div>`).join('')}</div>`;
}


// ---------------------------------------------------------------------
// INÍCIO DO PAINEL (gestor): atalhos + fixar/desafixar rápido
// ---------------------------------------------------------------------
r.get('/', (req, res) => {
  const lista = db.prepare(`SELECT c.*, d.nome depto, d.cor,
      (SELECT COUNT(*) FROM sessoes_leitura s WHERE s.comunicado_id = c.id) aberturas,
      (SELECT ROUND(100.0 * SUM(chegou_ao_fim) / NULLIF(COUNT(*), 0), 1) FROM sessoes_leitura s WHERE s.comunicado_id = c.id) pct_fim,
      (SELECT COUNT(*) FROM confirmacoes_leitura k WHERE k.comunicado_id = c.id) conf
    FROM comunicados c JOIN departamentos d ON d.id = c.departamento_id
    WHERE c.status <> 'arquivado' ORDER BY c.status = 'rascunho' DESC, c.fixado DESC, c.publicado_em DESC, c.id DESC`).all();
  const pub = lista.filter((c) => c.status === 'publicado'), ras = lista.filter((c) => c.status === 'rascunho');
  const linha = (c) => `<tr>
    <td><b>${esc(c.numero)}</b> ${esc(c.titulo)}${c.status === 'rascunho' ? ' <span class="status status--rascunho">rascunho</span>' : ''}</td>
    <td><span class="ponto" style="--c:${esc(c.cor)}"></span>${esc(c.depto)}</td>
    <td class="n">${num(c.aberturas)}</td><td class="n">${c.pct_fim == null ? '—' : `${String(c.pct_fim).replace('.', ',')}%`}</td><td class="n">${num(c.conf)}</td>
    <td>${c.status === 'publicado' ? `<form class="so-editor" method="post" action="/admin/comunicados/${c.id}/fixar"><input type="hidden" name="voltar" value="/admin?ok=fixado"><button class="alternar ${c.fixado ? 'on' : ''}">${c.fixado ? `${ic('pino')} Fixado — desafixar` : 'Fixar no topo'}</button></form>` : '—'}</td>
    <td class="acoes-linha"><a class="so-editor" href="/admin/comunicados/${c.id}/editar">Editar</a>${c.status === 'publicado' ? `<a href="/admin/comunicado/${c.id}">Relatório</a><a href="/${esc(c.slug)}" target="_blank">Ver ↗</a>` : ''}</td></tr>`;
  res.send(tela(req, 'Início', `
<div class="cabeca"><div><h1>Olá, ${esc(req.usuario.nome)}</h1><p class="sub">Painel do gestor de comunicados. Só quem tem login vê esta área.</p></div></div>
${req.query.ok === 'fixado' ? '<p class="sucesso">Pronto — a ordem dos fixados no site foi atualizada.</p>' : ''}
<section class="atalhos">
  <a class="atalho so-editor" href="/admin/comunicados/novo"><span class="atalho__icone">${ic('mais')}</span><b>Criar comunicado</b><span>Escreva, veja a prévia e publique.</span></a>
  <a class="atalho so-editor" href="/admin/comunicados"><span class="atalho__icone">${ic('pino')}</span><b>Fixar e editar</b><span>Fixe no topo, edite, arquive ou duplique.</span></a>
  <a class="atalho so-editor" href="/admin/envios/novo"><span class="atalho__icone">${ic('envio')}</span><b>Enviar por e-mail</b><span>Para todos os clientes ou para alguém específico.</span></a>
  <a class="atalho" href="/admin/relatorios"><span class="atalho__icone">${ic('grafico')}</span><b>Relatórios</b><span>Quem abriu, quem leu até o fim, quem confirmou.</span></a>
</section>
<section class="cartao">
  <div class="cartao__cabeca"><h2>Comunicados no site agora · ${pub.length}${ras.length ? ` <small class="sub">(+ ${ras.length} rascunho${ras.length > 1 ? 's' : ''})</small>` : ''}</h2><a class="btn btn--primario so-editor" href="/admin/comunicados/novo">+ Novo comunicado</a></div>
  <div class="tabela-rolagem"><table class="tabela"><thead><tr><th>Comunicado</th><th>Setor</th><th class="n">Aberturas</th><th class="n">Até o fim</th><th class="n">Ciente</th><th>Topo do site</th><th></th></tr></thead>
  <tbody>${lista.map(linha).join('') || '<tr><td colspan="7" class="vazio">Nenhum comunicado ainda. <a href="/admin/comunicados/novo">Criar o primeiro</a>.</td></tr>'}</tbody></table></div>
</section>`, 'inicio'));
});
// ---------------------------------------------------------------------
// RELATÓRIO GERAL
// ---------------------------------------------------------------------
const SQL_POR_COMUNICADO = `
WITH ss AS (
  SELECT comunicado_id, COUNT(*) aberturas, COUNT(DISTINCT visitante_id) leitores,
         SUM(tempo_ativo_ms) tempo_soma, AVG(tempo_ativo_ms) tempo_medio, AVG(rolagem_max_pct) rolagem_media,
         SUM(chegou_ao_fim) completas, SUM(tempo_ate_fim_ms) ate_fim_soma, COUNT(tempo_ate_fim_ms) ate_fim_n, AVG(tempo_ate_fim_ms) ate_fim_medio
  FROM sessoes_leitura WHERE iniciada_em >= @desde GROUP BY comunicado_id),
ev AS (
  SELECT comunicado_id, SUM(tipo = 'clique_card') cards, SUM(tipo = 'clique_whatsapp') whatsapp, SUM(tipo = 'clique_imprimir') imprimir
  FROM eventos WHERE criado_em >= @desde AND comunicado_id IS NOT NULL GROUP BY comunicado_id),
kk AS (
  SELECT comunicado_id, COUNT(*) confirmacoes, SUM(leu_ate_o_fim) conf_fim
  FROM confirmacoes_leitura WHERE confirmado_em >= @desde GROUP BY comunicado_id)
SELECT c.id, c.numero, c.titulo, c.status, c.fixado, c.publicado_em, d.id depto_id, d.nome depto, d.cor,
       COALESCE(ev.cards,0) cards, COALESCE(ss.aberturas,0) aberturas, COALESCE(ss.leitores,0) leitores,
       COALESCE(ss.tempo_soma,0) tempo_soma, ss.tempo_medio, ss.rolagem_media, COALESCE(ss.completas,0) completas,
       COALESCE(ss.ate_fim_soma,0) ate_fim_soma, COALESCE(ss.ate_fim_n,0) ate_fim_n, ss.ate_fim_medio,
       COALESCE(kk.confirmacoes,0) confirmacoes, COALESCE(kk.conf_fim,0) conf_fim,
       COALESCE(ev.whatsapp,0) whatsapp, COALESCE(ev.imprimir,0) imprimir
FROM comunicados c JOIN departamentos d ON d.id = c.departamento_id
LEFT JOIN ss ON ss.comunicado_id = c.id LEFT JOIN ev ON ev.comunicado_id = c.id LEFT JOIN kk ON kk.comunicado_id = c.id
WHERE c.status <> 'rascunho' AND (@depto IS NULL OR c.departamento_id = @depto)
ORDER BY c.publicado_em DESC, c.id DESC`;

function porComunicado(f) { return db.prepare(SQL_POR_COMUNICADO).all({ desde: f.desde, depto: f.depto }); }

// ---------------------------------------------------------------------
// SITUAÇÃO POR PESSOA: quem leu até o fim, quem parou no meio, quem não abriu
// ---------------------------------------------------------------------
const SITUACOES = {
  fim_confirmou: { rotulo: 'Leu até o fim e confirmou', classe: 'ok', grupo: 'fim' },
  fim:           { rotulo: 'Leu até o fim (não confirmou)', classe: 'ok2', grupo: 'fim' },
  confirmou_sem_fim: { rotulo: 'Confirmou sem chegar ao fim', classe: 'alerta', grupo: 'parcial' },
  parcial:       { rotulo: 'Abriu, não chegou ao fim', classe: 'alerta', grupo: 'parcial' },
  nao_abriu:     { rotulo: 'Não abriu', classe: 'nao', grupo: 'nao_abriu' },
};
const FONTES = { link: 'link do e-mail', confirmacao: '“Li e estou ciente”', navegador: 'mesmo navegador de outra confirmação' };
function situacaoPessoas(comunicadoId) {
  const pessoas = db.prepare('SELECT * FROM vw_leitura_por_pessoa WHERE comunicado_id = ?').all(comunicadoId);
  const confs = Object.fromEntries(db.prepare('SELECT * FROM confirmacoes_leitura WHERE comunicado_id = ?').all(comunicadoId).map((k) => [k.email.toLowerCase(), k]));
  const contatos = db.prepare('SELECT * FROM contatos WHERE ativo = 1').all();
  const porEmail = Object.fromEntries(contatos.map((k) => [k.email.toLowerCase(), k]));
  const linhas = pessoas.map((p) => {
    const k = p.email ? confs[p.email] : null;
    const fim = p.chegou_ao_fim || (k && k.leu_ate_o_fim);
    const sit = k ? (fim ? 'fim_confirmou' : 'confirmou_sem_fim') : (fim ? 'fim' : 'parcial');
    const ct = p.email ? porEmail[p.email] : null;
    return { ...p, situacao: sit, confirmado_em: k ? k.confirmado_em : null, nome: ct?.nome, empresa: ct?.empresa,
      rolagem_max: Math.max(p.rolagem_max, k ? k.rolagem_pct : 0), identificado: !!p.email,
      fontes: (p.fontes_email || '').split(',').filter(Boolean).map((f) => FONTES[f] || f).join(', ') };
  });
  // confirmações sem sessão vinculada (raro) e contatos que nunca abriram
  const vistos = new Set(linhas.filter((l) => l.email).map((l) => l.email));
  for (const [email, k] of Object.entries(confs)) if (!vistos.has(email)) {
    vistos.add(email);
    linhas.push({ email, pessoa: email, identificado: true, aberturas: 1, situacao: k.leu_ate_o_fim ? 'fim_confirmou' : 'confirmou_sem_fim', rolagem_max: k.rolagem_pct,
      tempo_ativo_total_ms: k.tempo_ativo_ms, tempo_ate_fim_ms: k.tempo_ate_fim_ms, confirmado_em: k.confirmado_em, ultimo_acesso: k.confirmado_em, nome: porEmail[email]?.nome, empresa: porEmail[email]?.empresa, fontes: FONTES.confirmacao });
  }
  for (const ct of contatos) if (!vistos.has(ct.email.toLowerCase())) {
    linhas.push({ email: ct.email.toLowerCase(), pessoa: ct.email, identificado: true, aberturas: 0, situacao: 'nao_abriu', rolagem_max: 0, nome: ct.nome, empresa: ct.empresa });
  }
  const ordem = { fim_confirmou: 0, fim: 1, confirmou_sem_fim: 2, parcial: 3, nao_abriu: 4 };
  linhas.sort((a, b) => (b.identificado - a.identificado) || (ordem[a.situacao] - ordem[b.situacao]) || String(a.pessoa).localeCompare(b.pessoa));
  return { linhas, temContatos: contatos.length > 0 };
}
function blocoPessoas(c) {
  const { linhas, temContatos } = situacaoPessoas(c.id);
  const ident = linhas.filter((l) => l.identificado);
  const anon = linhas.filter((l) => !l.identificado);
  const conta = (g) => ident.filter((l) => SITUACOES[l.situacao].grupo === g).length;
  const chip = (g, rot, n) => `<button type="button" class="chip-p${g === 'todos' ? ' ativo' : ''}" data-grupo="${g}">${rot} <b>${n}</b></button>`;
  const linha = (l) => `<tr data-grupo="${l.identificado ? SITUACOES[l.situacao].grupo : 'anon'}">
    <td>${l.identificado ? `<b>${esc(l.email)}</b>${l.nome || l.empresa ? `<br><small>${esc([l.nome, l.empresa].filter(Boolean).join(' · '))}</small>` : ''}` : `<span class="anon">Não identificado ${esc(String(l.pessoa).slice(8, 14))}</span>`}</td>
    <td><span class="sit sit--${SITUACOES[l.situacao].classe}">${SITUACOES[l.situacao].rotulo}</span></td>
    <td class="n">${l.aberturas ? `${l.rolagem_max}%` : '—'}</td>
    <td class="n">${l.aberturas ? duracao(l.tempo_ativo_total_ms) : '—'}</td>
    <td class="n">${duracao(l.tempo_ate_fim_ms)}</td>
    <td class="n">${l.aberturas || 0}</td>
    <td>${l.ultimo_acesso ? dataHoraBR(l.ultimo_acesso) : '—'}</td>
    <td><small>${esc(l.fontes || (l.identificado ? 'lista de clientes' : 'sem e-mail'))}</small></td>
    <td>${l.identificado ? `<a class="link-acao so-editor" href="/admin/envios/novo?comunicado=${c.id}&amp;para=${encodeURIComponent(l.email)}" title="Enviar este aviso só para ${esc(l.email)}">${ic('envio')} Enviar</a>` : ''}</td></tr>`;
  return `
<section class="cartao" id="pessoas">
  <div class="cartao__cabeca"><h2>Situação por pessoa</h2><div class="botoes"><a class="btn btn--sec" href="/admin/exportar/pessoas.csv?comunicado=${c.id}">Exportar CSV</a><a class="btn btn--primario so-editor" href="/admin/envios/novo?comunicado=${c.id}">${ic('envio')} Enviar por e-mail</a></div></div>
  <p class="sub">Cada linha é uma pessoa (juntando todas as vezes que ela abriu o aviso). O e-mail vem do link enviado, do “Li e estou ciente” ou do navegador que já confirmou outro aviso.${temContatos ? '' : ' <a href="/admin/contatos">Cadastre a lista de clientes</a> para ver também quem <b>não abriu</b>.'}</p>
  <div class="chips-p">${chip('todos', 'Todos', linhas.length)}${chip('fim', 'Leram até o fim', conta('fim'))}${chip('parcial', 'Não chegaram ao fim', conta('parcial'))}${temContatos ? chip('nao_abriu', 'Não abriram', conta('nao_abriu')) : ''}${chip('anon', 'Não identificados', anon.length)}</div>
  <div class="tabela-rolagem tabela-rolagem--alta"><table class="tabela" id="tabela-pessoas"><thead><tr><th>Pessoa</th><th>Situação</th><th class="n">Rolagem máx.</th><th class="n">Tempo de leitura</th><th class="n">Tempo até o fim</th><th class="n">Aberturas</th><th>Último acesso</th><th>Como identificamos</th><th></th></tr></thead>
  <tbody>${linhas.map(linha).join('') || '<tr><td colspan="9" class="vazio">Ninguém abriu este aviso ainda.</td></tr>'}</tbody></table></div>
</section>`;
}
function blocoLinks(req, c) {
  const base = `${req.protocol}://${req.get('host')}/${c.slug}`;
  const temContatos = db.prepare('SELECT COUNT(*) n FROM contatos WHERE ativo = 1').get().n;
  return `
<section class="cartao">
  <h2>Links para enviar este aviso</h2>
  <div class="links-envio">
    <label>Por e-mail (identifica quem abriu)<input readonly value="${esc(base)}?e=EMAIL_DO_CLIENTE&amp;utm_source=email" onclick="this.select()"></label>
    <label>Por WhatsApp<input readonly value="${esc(base)}?utm_source=whatsapp" onclick="this.select()"></label>
  </div>
  <p class="nota">No link por e-mail, troque <b>EMAIL_DO_CLIENTE</b> pelo e-mail de cada destinatário — ou use a variável do seu sistema de envio (ex.: <code>{{email}}</code>, <code>*|EMAIL|*</code>). ${temContatos ? `<a href="/admin/exportar/links.csv?comunicado=${c.id}">Baixar planilha com o link pronto de cada cliente</a>.` : ''}</p>
</section>`;
}

r.get('/relatorios', (req, res) => {
  const f = filtros(req);
  const linhas = porComunicado(f);
  const tot = linhas.reduce((a, l) => {
    for (const k of ['cards', 'aberturas', 'tempo_soma', 'completas', 'ate_fim_soma', 'ate_fim_n', 'confirmacoes', 'conf_fim', 'whatsapp']) a[k] = (a[k] || 0) + l[k];
    return a;
  }, {});
  const uni = db.prepare(`SELECT COUNT(DISTINCT s.visitante_id) n FROM sessoes_leitura s JOIN comunicados c ON c.id = s.comunicado_id
    WHERE s.iniciada_em >= @desde AND (@depto IS NULL OR c.departamento_id = @depto)`).get(f).n;
  const visitasLista = db.prepare(`SELECT COUNT(*) n, COUNT(DISTINCT visitante_id) u FROM eventos WHERE tipo = 'visita_lista' AND criado_em >= ?`).get(f.desde);
  const diario = db.prepare(`SELECT date(s.iniciada_em, '-3 hours') dia, COUNT(*) aberturas FROM sessoes_leitura s JOIN comunicados c ON c.id = s.comunicado_id
    WHERE s.iniciada_em >= @desde AND (@depto IS NULL OR c.departamento_id = @depto) GROUP BY dia ORDER BY dia`).all(f);

  // por setor (médias ponderadas a partir das linhas por comunicado)
  const setores = {};
  for (const l of linhas) {
    const s = setores[l.depto] ||= { nome: l.depto, cor: l.cor, n: 0, aberturas: 0, tempo_soma: 0, completas: 0, confirmacoes: 0, whatsapp: 0 };
    s.n++; for (const k of ['aberturas', 'tempo_soma', 'completas', 'confirmacoes', 'whatsapp']) s[k] += l[k];
  }

  const corpo = `
<div class="cabeca"><div><h1>Relatórios de leitura</h1><p class="sub">Cliques, tempo de leitura, rolagem até o fim e confirmações. Clique num comunicado para ver <b>quem</b> leu até o fim.</p></div>
  <div class="cabeca__acoes">${barraFiltros(f)}<a class="btn btn--primario so-editor" href="/admin/comunicados/novo">+ Novo comunicado</a></div></div>
<section class="kpis">
  ${kpi('Visitas à página inicial', num(visitasLista.n), `${num(visitasLista.u)} navegadores únicos`)}
  ${kpi('Cliques nos avisos', num(tot.cards || 0), 'na lista de comunicados')}
  ${kpi('Aberturas de avisos', num(tot.aberturas || 0), `${num(uni)} leitores únicos`)}
  ${kpi('Tempo médio de leitura', duracao(tot.aberturas ? tot.tempo_soma / tot.aberturas : null), 'tempo ativo por abertura')}
  ${kpi('Leram até o fim', `${pct(tot.completas || 0, tot.aberturas || 0)}%`, `${num(tot.completas || 0)} aberturas · ${duracao(tot.ate_fim_n ? tot.ate_fim_soma / tot.ate_fim_n : null)} até o fim`)}
  ${kpi('“Li e estou ciente”', num(tot.confirmacoes || 0), `${num(tot.conf_fim || 0)} leram até o fim antes de confirmar`)}
  ${kpi('Cliques no WhatsApp', num(tot.whatsapp || 0), 'dúvidas direcionadas aos setores')}
</section>
<section class="cartao"><h2>Aberturas por dia</h2>${graficoDiario(diario, f.periodo)}</section>
<section class="cartao">
  <div class="cartao__cabeca"><h2>Por comunicado</h2><a class="btn btn--sec" href="/admin/exportar/resumo.csv?periodo=${f.periodo}${f.depto ? `&depto=${f.depto}` : ''}">Exportar CSV</a></div>
  <div class="tabela-rolagem"><table class="tabela">
    <thead><tr><th>Comunicado</th><th>Setor</th><th class="n">Cliques</th><th class="n">Aberturas</th><th class="n">Leitores</th><th class="n">Tempo médio</th><th class="n">Até o fim</th><th class="n">Tempo até o fim</th><th class="n">Ciente</th><th class="n">WhatsApp</th></tr></thead>
    <tbody>${linhas.map((l) => `<tr>
      <td><a href="/admin/comunicado/${l.id}?periodo=${f.periodo}"><b>${esc(l.numero)}</b> ${esc(l.titulo)}</a>${l.fixado ? ' <span class="mini">fixado</span>' : ''}${l.status === 'arquivado' ? ' <span class="mini mini--cinza">arquivado</span>' : ''}</td>
      <td><span class="ponto" style="--c:${esc(l.cor)}"></span>${esc(l.depto)}</td>
      <td class="n">${num(l.cards)}</td><td class="n">${num(l.aberturas)}</td><td class="n">${num(l.leitores)}</td>
      <td class="n">${duracao(l.tempo_medio)}</td><td class="n">${pct(l.completas, l.aberturas)}%</td><td class="n">${duracao(l.ate_fim_medio)}</td>
      <td class="n">${num(l.confirmacoes)}</td><td class="n">${num(l.whatsapp)}</td></tr>`).join('') || '<tr><td colspan="10" class="vazio">Nenhum comunicado publicado.</td></tr>'}</tbody>
  </table></div>
</section>
<section class="cartao"><h2>Por setor</h2>
  <div class="tabela-rolagem"><table class="tabela"><thead><tr><th>Setor</th><th class="n">Comunicados</th><th class="n">Aberturas</th><th class="n">Tempo médio</th><th class="n">Até o fim</th><th class="n">Ciente</th><th class="n">WhatsApp</th></tr></thead>
  <tbody>${Object.values(setores).map((s) => `<tr><td><span class="ponto" style="--c:${esc(s.cor)}"></span>${esc(s.nome)}</td><td class="n">${s.n}</td><td class="n">${num(s.aberturas)}</td><td class="n">${duracao(s.aberturas ? s.tempo_soma / s.aberturas : null)}</td><td class="n">${pct(s.completas, s.aberturas)}%</td><td class="n">${num(s.confirmacoes)}</td><td class="n">${num(s.whatsapp)}</td></tr>`).join('')}</tbody></table></div>
</section>
<p class="nota">“Tempo de leitura” conta só os momentos com a aba visível e alguma interação nos últimos 30 segundos. “Até o fim” = o leitor rolou até o final do texto do aviso.</p>`;
  res.send(tela(req, 'Relatórios', corpo, 'dash'));
});

// ---------------------------------------------------------------------
// RELATÓRIO DE UM COMUNICADO
// ---------------------------------------------------------------------
r.get('/comunicado/:id', (req, res) => {
  const f = filtros(req);
  const c = db.prepare('SELECT c.*, d.nome depto FROM comunicados c JOIN departamentos d ON d.id = c.departamento_id WHERE c.id = ?').get(Number(req.params.id));
  if (!c) return res.status(404).send(tela(req, 'Não encontrado', '<h1>Comunicado não encontrado</h1>'));
  const p = { id: c.id, desde: f.desde };
  const l = db.prepare(SQL_POR_COMUNICADO.replace("WHERE c.status <> 'rascunho' AND", 'WHERE c.id = @id AND')).get({ ...p, depto: null });
  const fu = db.prepare(`SELECT COUNT(*) abriram, SUM(rolagem_max_pct >= 25) p25, SUM(rolagem_max_pct >= 50) p50, SUM(rolagem_max_pct >= 75) p75, SUM(chegou_ao_fim) fim
    FROM sessoes_leitura WHERE comunicado_id = @id AND iniciada_em >= @desde`).get(p);
  const diario = db.prepare(`SELECT date(iniciada_em, '-3 hours') dia, COUNT(*) aberturas FROM sessoes_leitura WHERE comunicado_id = @id AND iniciada_em >= @desde GROUP BY dia ORDER BY dia`).all(p);
  const origens = db.prepare(`SELECT COALESCE(origem,'direto') origem, COUNT(*) n, SUM(chegou_ao_fim) fim FROM sessoes_leitura WHERE comunicado_id = @id AND iniciada_em >= @desde GROUP BY 1 ORDER BY n DESC`).all(p);
  const disp = db.prepare(`SELECT COALESCE(dispositivo,'?') dispositivo, COUNT(*) n, AVG(tempo_ativo_ms) t FROM sessoes_leitura WHERE comunicado_id = @id AND iniciada_em >= @desde GROUP BY 1 ORDER BY n DESC`).all(p);
  const conf = db.prepare(`SELECT * FROM confirmacoes_leitura WHERE comunicado_id = @id AND confirmado_em >= @desde ORDER BY confirmado_em DESC`).all(p);
  const sess = db.prepare(`SELECT s.*, COALESCE(s.email, v.email) email FROM sessoes_leitura s JOIN visitantes v ON v.id = s.visitante_id
    WHERE s.comunicado_id = @id AND s.iniciada_em >= @desde ORDER BY s.iniciada_em DESC LIMIT 300`).all(p);
  const q = `?periodo=${f.periodo}&comunicado=${c.id}`;

  const corpo = `
<div class="cabeca"><div><a class="voltar" href="/admin/relatorios?periodo=${f.periodo}">← Relatórios</a>
  <h1><span class="sub-num">${esc(c.numero)}</span> ${esc(c.titulo)}</h1>
  <p class="sub">${esc(c.depto)} · publicado em ${dataCurta(c.publicado_em)} · <a href="/${esc(c.slug)}" target="_blank">abrir aviso ↗</a> <span class="so-editor"> · <a href="/admin/comunicados/${c.id}/editar">editar</a></span></p></div>
  ${barraFiltros(f, false)}</div>
<section class="kpis">
  ${kpi('Cliques na lista', num(l.cards))}
  ${kpi('Aberturas', num(l.aberturas), `${num(l.leitores)} leitores únicos`)}
  ${kpi('Tempo médio de leitura', duracao(l.tempo_medio), `rolagem média ${Math.round(l.rolagem_media || 0)}%`)}
  ${kpi('Leram até o fim', `${pct(l.completas, l.aberturas)}%`, `${num(l.completas)} aberturas`)}
  ${kpi('Tempo médio até o fim', duracao(l.ate_fim_medio), 'de quem chegou ao final')}
  ${kpi('“Li e estou ciente”', num(l.confirmacoes), `${pct(l.confirmacoes, l.leitores)}% dos leitores únicos`)}
  ${kpi('WhatsApp / Imprimir', `${num(l.whatsapp)} / ${num(l.imprimir)}`, 'cliques')}
</section>
${blocoPessoas(c)}
<div class="duas">
  <section class="cartao"><h2>Até onde leram</h2>${funil([
    { rotulo: 'Abriram', n: fu.abriram || 0 }, { rotulo: 'Passaram de 25%', n: fu.p25 || 0 }, { rotulo: 'Passaram de 50%', n: fu.p50 || 0 },
    { rotulo: 'Passaram de 75%', n: fu.p75 || 0 }, { rotulo: 'Chegaram ao fim', n: fu.fim || 0 }, { rotulo: 'Confirmaram leitura', n: l.confirmacoes }])}</section>
  <section class="cartao"><h2>Aberturas por dia</h2>${graficoDiario(diario, f.periodo)}
    <div class="duas duas--justas">
      <table class="tabela tabela--compacta"><thead><tr><th>Origem</th><th class="n">Aberturas</th><th class="n">Até o fim</th></tr></thead><tbody>${origens.map((o) => `<tr><td>${esc(o.origem)}</td><td class="n">${o.n}</td><td class="n">${pct(o.fim, o.n)}%</td></tr>`).join('') || '<tr><td colspan="3">—</td></tr>'}</tbody></table>
      <table class="tabela tabela--compacta"><thead><tr><th>Dispositivo</th><th class="n">Aberturas</th><th class="n">Tempo médio</th></tr></thead><tbody>${disp.map((o) => `<tr><td>${esc(o.dispositivo)}</td><td class="n">${o.n}</td><td class="n">${duracao(o.t)}</td></tr>`).join('') || '<tr><td colspan="3">—</td></tr>'}</tbody></table>
    </div></section>
</div>
<section class="cartao">
  <div class="cartao__cabeca"><h2>Quem confirmou (“Li e estou ciente”) · ${num(conf.length)}</h2><a class="btn btn--sec" href="/admin/exportar/confirmacoes.csv${q}">Exportar CSV</a></div>
  <div class="tabela-rolagem tabela-rolagem--alta"><table class="tabela"><thead><tr><th>E-mail</th><th>Confirmado em</th><th>Leu até o fim?</th><th class="n">Rolagem</th><th class="n">Tempo de leitura</th><th class="n">Tempo até o fim</th></tr></thead>
  <tbody>${conf.map((k) => `<tr><td>${esc(k.email)}</td><td>${dataHoraBR(k.confirmado_em)}</td><td>${k.leu_ate_o_fim ? '<span class="ok">Sim</span>' : '<span class="nao">Não</span>'}</td><td class="n">${k.rolagem_pct}%</td><td class="n">${duracao(k.tempo_ativo_ms)}</td><td class="n">${duracao(k.tempo_ate_fim_ms)}</td></tr>`).join('') || '<tr><td colspan="6" class="vazio">Ninguém confirmou ainda.</td></tr>'}</tbody></table></div>
</section>
<section class="cartao">
  <div class="cartao__cabeca"><h2>Leituras (cada abertura)${sess.length >= 300 ? ' · últimas 300' : ''}</h2><a class="btn btn--sec" href="/admin/exportar/leituras.csv${q}">Exportar CSV</a></div>
  <div class="tabela-rolagem tabela-rolagem--alta"><table class="tabela"><thead><tr><th>Início</th><th>Leitor</th><th>Dispositivo</th><th>Origem</th><th class="n">Tempo ativo</th><th class="n">Tempo na página</th><th class="n">Rolagem</th><th class="n">Tempo até o fim</th></tr></thead>
  <tbody>${sess.map((s) => `<tr><td>${dataHoraBR(s.iniciada_em)}</td><td>${s.email ? esc(s.email) : `<span class="anon">Anônimo ${esc(s.visitante_id.slice(0, 6))}</span>`}</td><td>${esc(s.dispositivo || '')}</td><td>${esc(s.origem || 'direto')}</td><td class="n">${duracao(s.tempo_ativo_ms)}</td><td class="n">${duracao(s.tempo_total_ms)}</td><td class="n">${s.rolagem_max_pct}%${s.chegou_ao_fim ? ' ✓' : ''}</td><td class="n">${duracao(s.tempo_ate_fim_ms)}</td></tr>`).join('') || '<tr><td colspan="8" class="vazio">Sem leituras no período.</td></tr>'}</tbody></table></div>
</section>
${blocoLinks(req, c)}`;
  res.send(tela(req, c.numero, corpo, 'dash'));
});

// ---------------------------------------------------------------------
// EXPORTAÇÕES CSV
// ---------------------------------------------------------------------
r.get('/exportar/:arquivo', (req, res) => {
  const f = filtros(req);
  const cid = Number(req.query.comunicado) || null;
  let nome, conteudo;
  if (req.params.arquivo === 'resumo.csv') {
    nome = 'resumo-comunicados.csv';
    conteudo = csv(porComunicado(f), [
      { titulo: 'Número', campo: 'numero' }, { titulo: 'Título', campo: 'titulo' }, { titulo: 'Setor', campo: 'depto' },
      { titulo: 'Publicado em', valor: (l) => dataCurta(l.publicado_em) }, { titulo: 'Cliques na lista', campo: 'cards' },
      { titulo: 'Aberturas', campo: 'aberturas' }, { titulo: 'Leitores únicos', campo: 'leitores' },
      { titulo: 'Tempo médio de leitura (s)', valor: (l) => (l.tempo_medio == null ? '' : Math.round(l.tempo_medio / 1000)) },
      { titulo: 'Leram até o fim', campo: 'completas' }, { titulo: '% até o fim', valor: (l) => String(pct(l.completas, l.aberturas)).replace('.', ',') },
      { titulo: 'Tempo médio até o fim (s)', valor: (l) => (l.ate_fim_medio == null ? '' : Math.round(l.ate_fim_medio / 1000)) },
      { titulo: 'Confirmações', campo: 'confirmacoes' }, { titulo: 'Cliques WhatsApp', campo: 'whatsapp' }, { titulo: 'Cliques imprimir', campo: 'imprimir' },
    ]);
  } else if (req.params.arquivo === 'confirmacoes.csv') {
    nome = `confirmacoes${cid ? `-${cid}` : ''}.csv`;
    const linhas = db.prepare(`SELECT k.*, c.numero, c.titulo, d.nome depto FROM confirmacoes_leitura k JOIN comunicados c ON c.id = k.comunicado_id JOIN departamentos d ON d.id = c.departamento_id
      WHERE k.confirmado_em >= @desde AND (@cid IS NULL OR k.comunicado_id = @cid) ORDER BY k.confirmado_em DESC`).all({ desde: f.desde, cid });
    conteudo = csv(linhas, [
      { titulo: 'Número', campo: 'numero' }, { titulo: 'Título', campo: 'titulo' }, { titulo: 'Setor', campo: 'depto' }, { titulo: 'E-mail', campo: 'email' },
      { titulo: 'Confirmado em', valor: (k) => dataHoraBR(k.confirmado_em) }, { titulo: 'Leu até o fim', valor: (k) => (k.leu_ate_o_fim ? 'Sim' : 'Não') },
      { titulo: 'Rolagem (%)', campo: 'rolagem_pct' }, { titulo: 'Tempo de leitura (s)', valor: (k) => Math.round(k.tempo_ativo_ms / 1000) },
      { titulo: 'Tempo até o fim (s)', valor: (k) => (k.tempo_ate_fim_ms == null ? '' : Math.round(k.tempo_ate_fim_ms / 1000)) },
    ]);
  } else if (req.params.arquivo === 'leituras.csv') {
    nome = `leituras${cid ? `-${cid}` : ''}.csv`;
    const linhas = db.prepare(`SELECT s.*, v.email, c.numero, c.titulo FROM sessoes_leitura s JOIN visitantes v ON v.id = s.visitante_id JOIN comunicados c ON c.id = s.comunicado_id
      WHERE s.iniciada_em >= @desde AND (@cid IS NULL OR s.comunicado_id = @cid) ORDER BY s.iniciada_em DESC`).all({ desde: f.desde, cid });
    conteudo = csv(linhas, [
      { titulo: 'Número', campo: 'numero' }, { titulo: 'Título', campo: 'titulo' }, { titulo: 'Início', valor: (s) => dataHoraBR(s.iniciada_em) },
      { titulo: 'Leitor (id anônimo)', campo: 'visitante_id' }, { titulo: 'E-mail conhecido', campo: 'email' }, { titulo: 'Dispositivo', campo: 'dispositivo' },
      { titulo: 'Origem', campo: 'origem' }, { titulo: 'Campanha', campo: 'campanha' },
      { titulo: 'Tempo ativo (s)', valor: (s) => Math.round(s.tempo_ativo_ms / 1000) }, { titulo: 'Tempo na página (s)', valor: (s) => Math.round(s.tempo_total_ms / 1000) },
      { titulo: 'Rolagem máx. (%)', campo: 'rolagem_max_pct' }, { titulo: 'Chegou ao fim', valor: (s) => (s.chegou_ao_fim ? 'Sim' : 'Não') },
      { titulo: 'Tempo até o fim (s)', valor: (s) => (s.tempo_ate_fim_ms == null ? '' : Math.round(s.tempo_ate_fim_ms / 1000)) },
    ]);
  } else if (req.params.arquivo === 'pessoas.csv' && cid) {
    const c = db.prepare('SELECT numero FROM comunicados WHERE id = ?').get(cid);
    nome = `situacao-por-pessoa-${slugify(c ? c.numero : String(cid))}.csv`;
    conteudo = csv(situacaoPessoas(cid).linhas, [
      { titulo: 'E-mail', valor: (l) => (l.identificado ? l.email : 'Não identificado') }, { titulo: 'Nome', campo: 'nome' }, { titulo: 'Empresa', campo: 'empresa' },
      { titulo: 'Situação', valor: (l) => SITUACOES[l.situacao].rotulo }, { titulo: 'Leu até o fim', valor: (l) => (SITUACOES[l.situacao].grupo === 'fim' ? 'Sim' : 'Não') },
      { titulo: 'Confirmou leitura', valor: (l) => (l.confirmado_em ? 'Sim' : 'Não') }, { titulo: 'Confirmado em', valor: (l) => (l.confirmado_em ? dataHoraBR(l.confirmado_em) : '') },
      { titulo: 'Rolagem máx. (%)', valor: (l) => (l.aberturas ? l.rolagem_max : '') }, { titulo: 'Tempo de leitura (s)', valor: (l) => (l.tempo_ativo_total_ms == null ? '' : Math.round(l.tempo_ativo_total_ms / 1000)) },
      { titulo: 'Tempo até o fim (s)', valor: (l) => (l.tempo_ate_fim_ms == null ? '' : Math.round(l.tempo_ate_fim_ms / 1000)) }, { titulo: 'Aberturas', valor: (l) => l.aberturas || 0 },
      { titulo: 'Último acesso', valor: (l) => (l.ultimo_acesso ? dataHoraBR(l.ultimo_acesso) : '') }, { titulo: 'Como identificamos', campo: 'fontes' },
    ]);
  } else if (req.params.arquivo === 'links.csv' && cid) {
    const c = db.prepare('SELECT numero, slug FROM comunicados WHERE id = ?').get(cid);
    nome = `links-${slugify(c.numero)}.csv`;
    const base = `${req.protocol}://${req.get('host')}/${c.slug}`;
    conteudo = csv(db.prepare('SELECT * FROM contatos WHERE ativo = 1 ORDER BY empresa, email').all(), [
      { titulo: 'E-mail', campo: 'email' }, { titulo: 'Nome', campo: 'nome' }, { titulo: 'Empresa', campo: 'empresa' },
      { titulo: 'Link personalizado', valor: (k) => `${base}?e=${encodeURIComponent(k.email)}&utm_source=email` },
    ]);
  } else if (req.params.arquivo === 'envio.csv' && Number(req.query.envio)) {
    nome = `envio-${Number(req.query.envio)}.csv`;
    conteudo = csv(require('./email').resumoEnvio(Number(req.query.envio)).destinatarios, [
      { titulo: 'E-mail', campo: 'email' }, { titulo: 'Nome', campo: 'nome' }, { titulo: 'Status do envio', campo: 'status' }, { titulo: 'Erro', campo: 'erro' },
      { titulo: 'Enviado em', valor: (d) => (d.enviado_em ? dataHoraBR(d.enviado_em) : '') }, { titulo: 'Abriu e-mail', valor: (d) => (d.email_aberto_em ? dataHoraBR(d.email_aberto_em) : '') },
      { titulo: 'Abriu aviso', valor: (d) => (d.aviso_aberto_em || d.link_clicado_em ? dataHoraBR(d.aviso_aberto_em || d.link_clicado_em) : '') },
      { titulo: 'Rolagem (%)', campo: 'rolagem' }, { titulo: 'Leu até o fim', valor: (d) => (d.leu_ate_fim ? 'Sim' : 'Não') }, { titulo: 'Confirmou em', valor: (d) => (d.confirmado_em ? dataHoraBR(d.confirmado_em) : '') },
    ]);
  } else if (req.params.arquivo === 'eventos.csv') {
    nome = 'eventos.csv';
    const linhas = db.prepare(`SELECT e.*, c.numero FROM eventos e LEFT JOIN comunicados c ON c.id = e.comunicado_id WHERE e.criado_em >= ? ORDER BY e.id DESC LIMIT 100000`).all(f.desde);
    conteudo = csv(linhas, [{ titulo: 'Data', valor: (e) => dataHoraBR(e.criado_em) }, { titulo: 'Evento', campo: 'tipo' }, { titulo: 'Comunicado', campo: 'numero' },
      { titulo: 'Detalhe', campo: 'alvo' }, { titulo: 'Leitor (id anônimo)', campo: 'visitante_id' }, { titulo: 'Tempo ativo no momento (s)', valor: (e) => (e.valor_ms == null ? '' : Math.round(e.valor_ms / 1000)) }]);
  } else return res.status(404).end();
  res.set('Content-Type', 'text/csv; charset=utf-8').set('Content-Disposition', `attachment; filename="${nome}"`).send(conteudo);
});

// ---------------------------------------------------------------------
// GESTÃO DE COMUNICADOS
// ---------------------------------------------------------------------
r.get('/comunicados', (req, res) => {
  const lista = db.prepare(`SELECT c.*, d.nome depto, d.cor, (SELECT nome FROM admin_usuarios a WHERE a.email = c.atualizado_por) autor, (SELECT COUNT(*) FROM sessoes_leitura s WHERE s.comunicado_id = c.id) aberturas,
    (SELECT COUNT(*) FROM confirmacoes_leitura k WHERE k.comunicado_id = c.id) conf
    FROM comunicados c JOIN departamentos d ON d.id = c.departamento_id ORDER BY c.status = 'arquivado', c.publicado_em DESC, c.id DESC`).all();
  const st = { rascunho: 'Rascunho', publicado: 'Publicado', arquivado: 'Arquivado' };
  const corpo = `
<div class="cabeca"><div><h1>Comunicados</h1><p class="sub">Crie, fixe no topo e organize os avisos por setor.</p></div><a class="btn btn--primario so-editor" href="/admin/comunicados/novo">+ Novo comunicado</a></div>
${req.query.ok ? '<p class="sucesso">Alterações salvas.</p>' : ''}
${(() => { const c = req.query.id && db.prepare('SELECT slug, numero FROM comunicados WHERE id = ?').get(Number(req.query.id)); if (!c) return '';
  return { publicado: `<p class="sucesso">Comunicado ${esc(c.numero)} publicado e já visível no site. <a href="/${esc(c.slug)}" target="_blank">Ver como o cliente vê ↗</a> · <a href="/admin/envios/novo?comunicado=${req.query.id}">Enviar por e-mail agora</a></p>`,
    rascunho: `<p class="sucesso">Rascunho ${esc(c.numero)} salvo. Ele não aparece no site até ser publicado.</p>`,
    arquivado: `<p class="sucesso">Comunicado ${esc(c.numero)} arquivado: saiu da lista do site (o histórico de leitura continua no relatório).</p>` }[req.query.salvo] || ''; })()}
<section class="cartao"><div class="tabela-rolagem"><table class="tabela">
<thead><tr><th>Nº</th><th>Título</th><th>Setor</th><th>Status</th><th>Publicação</th><th>Última alteração</th><th class="n">Aberturas</th><th class="n">Ciente</th><th>Fixado</th><th></th></tr></thead>
<tbody>${lista.map((c) => `<tr>
  <td><b>${esc(c.numero)}</b></td><td>${esc(c.titulo)}</td><td><span class="ponto" style="--c:${esc(c.cor)}"></span>${esc(c.depto)}</td>
  <td><span class="status status--${c.status}">${st[c.status]}</span></td><td>${dataCurta(c.publicado_em)}</td>
  <td><small>${c.autor ? esc(c.autor) : '—'}${c.atualizado_em ? `<br>${dataHoraBR(c.atualizado_em)}` : ''}</small></td>
  <td class="n">${num(c.aberturas)}</td><td class="n">${num(c.conf)}</td>
  <td><form class="so-editor" method="post" action="/admin/comunicados/${c.id}/fixar"><button class="alternar ${c.fixado ? 'on' : ''}" title="${c.fixado ? 'Desafixar' : 'Fixar no topo'}">${c.fixado ? `${ic('pino')} Sim` : 'Não'}</button></form></td>
  <td class="acoes-linha"><a class="so-editor" href="/admin/comunicados/${c.id}/editar">Editar</a><a class="so-editor" href="/admin/comunicados/${c.id}/duplicar">Duplicar</a><a href="/admin/comunicado/${c.id}">Relatório</a><a href="/${esc(c.slug)}" target="_blank">Ver ↗</a></td></tr>`).join('')}</tbody>
</table></div></section>`;
  res.send(tela(req, 'Comunicados', corpo, 'com'));
});

r.post('/comunicados/:id/fixar', (req, res) => {
  db.prepare("UPDATE comunicados SET fixado = 1 - fixado, atualizado_por = ?, atualizado_em = datetime('now') WHERE id = ?").run(req.usuario.email, Number(req.params.id));
  const voltar = String(req.body.voltar || '');
  if (/^\/[a-z0-9\-\/?=&]*$/i.test(voltar) && !voltar.startsWith('//')) return res.redirect(voltar);
  res.redirect('/admin/comunicados?ok=1');
});

const MODELOS = {
  prazo: `## Em resumo

- **O que muda:** 
- **Prazo:** até **dd/mm**
- **Quem precisa agir:** 

## O que você precisa fazer

1. 
2. 

## Datas importantes

1. **dd/mm** — `,
  informativo: `## Em resumo

- 

## O que isso significa para a sua empresa

Texto explicando a mudança.

## Próximos passos

1. `,
  documentos: `## Em resumo

- Envie os documentos abaixo até **dd/mm**.

## Documentos que precisamos

1. 
2. 
3. 

## Como enviar

Responda ao e-mail ou envie pelo WhatsApp do setor.`,
};
function proximoNumero() {
  const ano = new Date().getFullYear();
  const n = db.prepare('SELECT numero FROM comunicados WHERE numero LIKE ?').all(`%/${ano}`)
    .map((c) => parseInt(c.numero, 10)).filter((x) => !isNaN(x));
  return `${String((n.length ? Math.max(...n) : 0) + 1).padStart(3, '0')}/${ano}`;
}
function formComunicado(req, c, erro = '') {
  const deptos = db.prepare('SELECT id, nome FROM departamentos WHERE ativo = 1 ORDER BY ordem').all();
  if (!c.numero) c.numero = proximoNumero();
  if (c.conteudo_md == null) c.conteudo_md = MODELOS.prazo;
  const sel = (a, b) => (String(a) === String(b) ? 'selected' : '');
  const publicado = c.status === 'publicado';
  return tela(req, c.id ? 'Editar comunicado' : 'Novo comunicado', `
<div class="cabeca"><div><a class="voltar" href="/admin/comunicados">← Comunicados</a><h1>${c.id ? `Editar ${esc(c.numero)}` : 'Novo comunicado'}</h1>
<p class="sub">Só quem entra no painel vê esta tela. O aviso só aparece no site depois de <b>Publicar</b>.</p></div></div>
${erro ? `<p class="alerta">${esc(erro)}</p>` : ''}
<form method="post" action="/admin/comunicados/salvar" class="formulario cartao" id="form-com">
  <input type="hidden" name="id" value="${c.id || ''}">
  <div class="campos campos--3">
    <label>Setor responsável<select name="departamento_id" required>${deptos.map((d) => `<option value="${d.id}" ${sel(d.id, c.departamento_id)}>${esc(d.nome)}</option>`).join('')}</select></label>
    <label>Número<input name="numero" value="${esc(c.numero)}" required pattern="[0-9]{1,4}/[0-9]{4}" title="Ex.: 004/2026"></label>
    <label>Data de publicação<input type="date" name="publicado_em" value="${esc((c.publicado_em || new Date(Date.now() - 3 * 3600e3).toISOString()).slice(0, 10))}" required></label>
  </div>
  <label>Título<input name="titulo" value="${esc(c.titulo || '')}" required maxlength="160" placeholder="Ex.: Novo prazo para envio da folha de dezembro"></label>
  <label>Resumo — 1 ou 2 frases que aparecem no card da lista<textarea name="resumo" rows="2" required maxlength="400">${esc(c.resumo || '')}</textarea></label>
  <div class="editor">
    <div class="editor__barra" role="toolbar" aria-label="Formatação">
      <button type="button" data-fmt="h2" title="Título de seção">Título</button>
      <button type="button" data-fmt="b" title="Negrito"><b>N</b></button>
      <button type="button" data-fmt="ul" title="Lista com marcadores">• Lista</button>
      <button type="button" data-fmt="ol" title="Lista numerada">1. Lista</button>
      <button type="button" data-fmt="link" title="Link">Link</button>
      <button type="button" data-fmt="quote" title="Destaque">Destaque</button>
      <span class="editor__sep"></span>
      <label class="editor__modelo">Usar modelo <select id="modelo"><option value="">—</option><option value="prazo">Prazo / ação do cliente</option><option value="informativo">Informativo</option><option value="documentos">Pedido de documentos</option></select></label>
    </div>
    <div class="editor__duas">
      <label class="sr" for="md">Texto do comunicado</label>
      <textarea name="conteudo_md" rows="20" required class="mono" id="md">${esc(c.conteudo_md)}</textarea>
      <div class="editor__previa"><span class="editor__rotulo">Como vai aparecer</span><div id="previa" class="aviso__corpo"></div></div>
    </div>
    ${Object.entries(MODELOS).map(([k, v]) => `<template data-modelo="${k}">${esc(v)}</template>`).join('')}
  </div>
  <label>Assinatura<input name="assinatura" value="${esc(c.assinatura || '')}" placeholder="Equipe Fiscal · Multcont"></label>
  <div class="campos campos--4">
    <label>Prioridade<select name="prioridade">${[['normal', 'Normal'], ['importante', 'Importante'], ['urgente', 'Urgente']].map(([p, t]) => `<option value="${p}" ${sel(p, c.prioridade || 'normal')}>${t}</option>`).join('')}</select></label>
    <label class="check"><input type="checkbox" name="fixado" value="1" ${c.fixado ? 'checked' : ''}> Fixar no topo do site</label>
    <label>Fixado até (opcional)<input type="date" name="fixado_ate" value="${esc(c.fixado_ate || '')}"></label>
    <label class="check"><input type="checkbox" name="exige_confirmacao" value="1" ${c.exige_confirmacao === 0 ? '' : 'checked'}> Pedir “Li e estou ciente”</label>
  </div>
  <div class="botoes">
    ${c.id && c.status !== 'arquivado' ? '<button class="btn btn--sec" name="acao" value="arquivar" formnovalidate>Arquivar (tirar do site)</button>' : ''}
    <a class="btn btn--sec" href="/admin/comunicados">Cancelar</a>
    <button class="btn btn--sec" name="acao" value="rascunho">${publicado ? 'Voltar para rascunho' : 'Salvar rascunho'}</button>
    <button class="btn btn--primario" name="acao" value="publicar">${publicado ? 'Salvar alterações' : 'Publicar agora'}</button>
  </div>
</form>`, 'com');
}
r.get('/comunicados/novo', (req, res) => res.send(formComunicado(req, { status: 'rascunho' })));
r.get('/comunicados/:id/editar', (req, res) => {
  const c = db.prepare('SELECT * FROM comunicados WHERE id = ?').get(Number(req.params.id));
  if (!c) return res.redirect('/admin/comunicados');
  res.send(formComunicado(req, c));
});
r.get('/comunicados/:id/duplicar', (req, res) => {
  const c = db.prepare('SELECT * FROM comunicados WHERE id = ?').get(Number(req.params.id));
  if (!c) return res.redirect('/admin/comunicados');
  res.send(formComunicado(req, { ...c, id: null, numero: null, status: 'rascunho', publicado_em: null, fixado: 0, titulo: `${c.titulo} (cópia)` }));
});
r.post('/comunicados/salvar', (req, res) => {
  const b = req.body;
  const atual = b.id ? db.prepare('SELECT status FROM comunicados WHERE id = ?').get(Number(b.id)) : null;
  const status = b.acao === 'publicar' ? 'publicado' : b.acao === 'arquivar' ? 'arquivado' : b.acao === 'rascunho' ? 'rascunho' : (atual ? atual.status : 'rascunho');
  const dados = {
    numero: String(b.numero || '').trim(), titulo: String(b.titulo || '').trim(), resumo: String(b.resumo || '').trim(),
    conteudo_md: String(b.conteudo_md || ''), departamento_id: Number(b.departamento_id), assinatura: String(b.assinatura || '').trim() || null,
    prioridade: ['normal', 'importante', 'urgente'].includes(b.prioridade) ? b.prioridade : 'normal', status,
    fixado: b.fixado ? 1 : 0, fixado_ate: b.fixado_ate || null, exige_confirmacao: b.exige_confirmacao ? 1 : 0,
    publicado_em: b.publicado_em || null,
  };
  dados.slug = slugify(dados.numero);
  if (status !== 'arquivado' && (!dados.titulo || !dados.resumo || !dados.conteudo_md.trim() || !/^\d{1,4}\/\d{4}$/.test(dados.numero))) {
    return res.status(400).send(formComunicado(req, { ...dados, id: b.id }, 'Preencha número (ex.: 004/2026), título, resumo e texto.'));
  }
  let id = Number(b.id) || null;
  try {
    if (id) {
      if (status === 'arquivado' && b.acao === 'arquivar') db.prepare("UPDATE comunicados SET status = 'arquivado', atualizado_por = ?, atualizado_em = datetime('now') WHERE id = ?").run(req.usuario.email, id);
      else db.prepare(`UPDATE comunicados SET numero=@numero, slug=@slug, titulo=@titulo, resumo=@resumo, conteudo_md=@conteudo_md, departamento_id=@departamento_id,
        assinatura=@assinatura, prioridade=@prioridade, status=@status, fixado=@fixado, fixado_ate=@fixado_ate, exige_confirmacao=@exige_confirmacao,
        publicado_em=@publicado_em, atualizado_por=@por, atualizado_em=datetime('now') WHERE id=@id`).run({ ...dados, id, por: req.usuario.email });
    } else {
      id = db.prepare(`INSERT INTO comunicados (numero, slug, titulo, resumo, conteudo_md, departamento_id, assinatura, prioridade, status, fixado, fixado_ate, exige_confirmacao, publicado_em, criado_por, atualizado_por)
        VALUES (@numero, @slug, @titulo, @resumo, @conteudo_md, @departamento_id, @assinatura, @prioridade, @status, @fixado, @fixado_ate, @exige_confirmacao, @publicado_em, @por, @por)`).run({ ...dados, por: req.usuario.email }).lastInsertRowid;
    }
  } catch (e) {
    const msg = /UNIQUE/.test(e.message) ? 'Já existe um comunicado com esse número.' : `Não foi possível salvar: ${e.message}`;
    return res.status(400).send(formComunicado(req, { ...dados, id: b.id }, msg));
  }
  const msg = status === 'publicado' ? 'publicado' : status === 'arquivado' ? 'arquivado' : 'rascunho';
  res.redirect(`/admin/comunicados?salvo=${msg}&id=${id}`);
});
r.post('/previa', express.json(), (req, res) => res.send(marked.parse(String(req.body.md || ''))));

// ---------------------------------------------------------------------
// SETORES (WhatsApp por setor)
// ---------------------------------------------------------------------
r.get('/departamentos', (req, res) => {
  const ds = db.prepare('SELECT * FROM departamentos ORDER BY ordem, nome').all();
  const linha = (d = {}) => `
  <form method="post" action="/admin/departamentos/salvar" class="setor cartao">
    <input type="hidden" name="id" value="${d.id || ''}">
    <div class="campos campos--4">
      <label>Nome<input name="nome" value="${esc(d.nome || '')}" required></label>
      <label>WhatsApp do setor <small>DDI+DDD+número</small><input name="whatsapp" value="${esc(d.whatsapp || '')}" required pattern="[0-9]{12,13}" placeholder="5531997627365"></label>
      <label>Cor da etiqueta<input type="color" name="cor" value="${esc(d.cor || '#1F92BF')}"></label>
      <label>Ordem<input type="number" name="ordem" value="${d.ordem ?? ds.length}"></label>
    </div>
    <label>Mensagem inicial no WhatsApp<input name="mensagem_whatsapp" value="${esc(d.mensagem_whatsapp || '')}" placeholder="Olá! Tenho uma dúvida sobre um comunicado."></label>
    <div class="campos campos--3">
      <label>Descrição<input name="descricao" value="${esc(d.descricao || '')}"></label>
      <label>E-mail do setor<input type="email" name="email" value="${esc(d.email || '')}"></label>
      <label>Responsável<input name="responsavel" value="${esc(d.responsavel || '')}"></label>
    </div>
    <div class="botoes"><label class="check"><input type="checkbox" name="ativo" value="1" ${d.ativo === 0 ? '' : 'checked'}> Ativo</label><button class="btn btn--primario">${d.id ? 'Salvar setor' : 'Adicionar setor'}</button></div>
  </form>`;
  res.send(tela(req, 'Setores', `
<div class="cabeca"><div><h1>Setores e WhatsApp</h1><p class="sub">O botão “Tirar dúvida no WhatsApp” de cada aviso abre a conversa com o número do setor responsável.</p></div></div>
${req.query.ok ? '<p class="sucesso">Setor salvo.</p>' : ''}${req.query.erro ? `<p class="alerta">${esc(req.query.erro)}</p>` : ''}
${ds.map((d) => linha(d)).join('')}
<h2 class="titulo-sec">Novo setor</h2>${linha()}`, 'dep'));
});
r.post('/departamentos/salvar', (req, res) => {
  const b = req.body;
  const d = {
    nome: String(b.nome || '').trim(), slug: slugify(b.nome || ''), whatsapp: String(b.whatsapp || '').replace(/\D/g, ''),
    cor: /^#[0-9a-f]{6}$/i.test(b.cor) ? b.cor : '#1F92BF', ordem: Number(b.ordem) || 0, mensagem_whatsapp: b.mensagem_whatsapp || null,
    descricao: b.descricao || null, email: b.email || null, responsavel: b.responsavel || null, ativo: b.ativo ? 1 : 0,
  };
  if (!d.nome || d.whatsapp.length < 12) return res.redirect('/admin/departamentos?erro=' + encodeURIComponent('Preencha o nome e o WhatsApp com DDI e DDD (ex.: 5531997627365).'));
  try {
    if (b.id) db.prepare(`UPDATE departamentos SET nome=@nome, slug=@slug, whatsapp=@whatsapp, cor=@cor, ordem=@ordem, mensagem_whatsapp=@mensagem_whatsapp,
      descricao=@descricao, email=@email, responsavel=@responsavel, ativo=@ativo WHERE id=@id`).run({ ...d, id: Number(b.id) });
    else db.prepare(`INSERT INTO departamentos (nome, slug, whatsapp, cor, ordem, mensagem_whatsapp, descricao, email, responsavel, ativo)
      VALUES (@nome, @slug, @whatsapp, @cor, @ordem, @mensagem_whatsapp, @descricao, @email, @responsavel, @ativo)`).run(d);
  } catch (e) {
    return res.redirect('/admin/departamentos?erro=' + encodeURIComponent(/UNIQUE/.test(e.message) ? 'Já existe um setor com esse nome.' : e.message));
  }
  res.redirect('/admin/departamentos?ok=1');
});

// ---------------------------------------------------------------------
// ENVIO POR E-MAIL (lote ou individual)
// ---------------------------------------------------------------------
const email = require('./email');
const baseUrl = (req) => (process.env.SITE_URL || `${req.protocol}://${req.get('host')}`).replace(/\/+$/, '');
const STATUS_ENVIO = { na_fila: 'Na fila', enviando: 'Enviando', concluido: 'Concluído', cancelado: 'Cancelado' };
function avisoModo() {
  const i = email.info();
  return i.modo === 'teste'
    ? `<p class="alerta">${ic('envio')} <b>Modo teste:</b> nenhum e-mail sai de verdade. Os e-mails são gerados como arquivos em <code>data/emails-teste</code> (abrem no Outlook). Para enviar de verdade, preencha os dados de SMTP no <code>.env</code>.</p>`
    : `<p class="sucesso">${ic('envio')} Envio ativo por <b>${esc(i.host)}</b> · remetente ${esc(i.remetente)} · ritmo de ${i.porMinuto} e-mails por minuto.</p>`;
}
function publicoLote(cid, publico) {
  const contatos = db.prepare('SELECT email, nome FROM contatos WHERE ativo = 1 ORDER BY empresa, email').all();
  if (publico === 'todos') return contatos;
  const pessoas = situacaoPessoas(cid).linhas.filter((l) => l.identificado);
  const por = Object.fromEntries(pessoas.map((p) => [p.email, p]));
  if (publico === 'nao_abriu') return contatos.filter((k) => !por[k.email.toLowerCase()] || por[k.email.toLowerCase()].situacao === 'nao_abriu');
  if (publico === 'nao_fim') return contatos.filter((k) => { const p = por[k.email.toLowerCase()]; return !p || SITUACOES[p.situacao].grupo !== 'fim'; });
  if (publico === 'nao_confirmou') return contatos.filter((k) => { const p = por[k.email.toLowerCase()]; return !p || !p.confirmado_em; });
  return [];
}
const PUBLICOS = { todos: 'Todos os clientes cadastrados', nao_abriu: 'Quem ainda não abriu este aviso', nao_fim: 'Quem ainda não leu até o fim', nao_confirmou: 'Quem ainda não confirmou a leitura', manual: 'Clientes selecionados' };

r.get('/envios', (req, res) => {
  const lista = db.prepare(`SELECT e.*, c.numero, c.titulo,
      (SELECT COUNT(*) FROM envio_destinatarios d WHERE d.envio_id = e.id) total,
      (SELECT COUNT(*) FROM envio_destinatarios d WHERE d.envio_id = e.id AND d.status = 'enviado') enviados,
      (SELECT COUNT(*) FROM envio_destinatarios d WHERE d.envio_id = e.id AND d.status = 'erro') erros,
      (SELECT COUNT(*) FROM envio_destinatarios d WHERE d.envio_id = e.id AND d.link_clicado_em IS NOT NULL) clicaram
    FROM envios e JOIN comunicados c ON c.id = e.comunicado_id ORDER BY e.id DESC LIMIT 200`).all();
  res.send(tela(req, 'Envios por e-mail', `
<div class="cabeca"><div><h1>Envios por e-mail</h1><p class="sub">Envie um comunicado para todos os clientes de uma vez ou para pessoas específicas.</p></div><a class="btn btn--primario" href="/admin/envios/novo">${ic('envio')} Novo envio</a></div>
${avisoModo()}
<section class="cartao"><div class="tabela-rolagem"><table class="tabela"><thead><tr><th>Data</th><th>Comunicado</th><th>Tipo</th><th>Para</th><th class="n">Enviados</th><th class="n">Abriram o aviso</th><th>Status</th><th></th></tr></thead>
<tbody>${lista.map((e) => `<tr><td>${dataHoraBR(e.criado_em)}</td><td><b>${esc(e.numero)}</b> ${esc(e.titulo)}</td><td>${e.tipo === 'lote' ? 'Em lote' : 'Individual'}${e.modo === 'teste' ? ' <span class="mini mini--cinza">teste</span>' : ''}</td>
  <td>${esc(e.publico || '')}</td><td class="n">${num(e.enviados)} / ${num(e.total)}${e.erros ? ` <span class="mini">${e.erros} erro${e.erros > 1 ? 's' : ''}</span>` : ''}</td><td class="n">${num(e.clicaram)}</td>
  <td><span class="status status--${e.status === 'concluido' ? 'publicado' : e.status === 'cancelado' ? 'arquivado' : 'rascunho'}">${STATUS_ENVIO[e.status]}</span></td><td class="acoes-linha"><a href="/admin/envios/${e.id}">Acompanhar</a></td></tr>`).join('') || '<tr><td colspan="8" class="vazio">Nenhum envio ainda.</td></tr>'}</tbody></table></div></section>`, 'env'));
});

r.get('/envios/novo', (req, res) => {
  const coms = db.prepare(`SELECT c.id, c.numero, c.titulo, d.nome depto FROM comunicados c JOIN departamentos d ON d.id = c.departamento_id WHERE c.status = 'publicado' ORDER BY c.publicado_em DESC, c.id DESC`).all();
  if (!coms.length) return res.send(tela(req, 'Novo envio', '<h1>Novo envio</h1><p class="alerta">Publique um comunicado antes de enviar.</p>', 'env'));
  const cid = Number(req.query.comunicado) || coms[0].id;
  const c = coms.find((x) => x.id === cid) || coms[0];
  const contatos = db.prepare('SELECT email, nome, empresa FROM contatos WHERE ativo = 1 ORDER BY empresa, email').all();
  const para = String(req.query.para || '');
  const tipo = para ? 'individual' : 'lote';
  const contagem = Object.fromEntries(Object.keys(PUBLICOS).filter((k) => k !== 'manual').map((k) => [k, publicoLote(c.id, k).length]));
  const assunto = `Comunicado ${c.numero} · ${c.titulo}`;
  res.send(tela(req, 'Novo envio', `
<div class="cabeca"><div><a class="voltar" href="/admin/envios">${ic('voltar')} Envios</a><h1>Enviar comunicado por e-mail</h1><p class="sub">Cada pessoa recebe um link próprio — assim o relatório mostra exatamente quem abriu e quem leu até o fim.</p></div></div>
${avisoModo()}
${req.query.erro ? `<p class="alerta">${esc(req.query.erro)}</p>` : ''}${req.query.ok ? `<p class="sucesso">${esc(req.query.ok)}</p>` : ''}
<form method="post" action="/admin/envios" class="formulario" id="form-envio">
 <div class="envio">
  <div class="envio__coluna">
   <section class="cartao formulario">
    <h2><span class="passo">1</span> Qual comunicado</h2>
    <label>Comunicado<select name="comunicado_id" id="envio-com" onchange="location.href='/admin/envios/novo?comunicado='+this.value${para ? `+'&para=${encodeURIComponent(para)}'` : ''}">${coms.map((x) => `<option value="${x.id}" ${x.id === c.id ? 'selected' : ''}>${esc(x.numero)} · ${esc(x.titulo)} (${esc(x.depto)})</option>`).join('')}</select></label>
   </section>
   <section class="cartao formulario">
    <h2><span class="passo">2</span> Para quem</h2>
    <div class="abas" role="tablist">
      <label class="aba"><input type="radio" name="tipo" value="lote" ${tipo === 'lote' ? 'checked' : ''}> ${ic('pessoas')} Em lote</label>
      <label class="aba"><input type="radio" name="tipo" value="individual" ${tipo === 'individual' ? 'checked' : ''}> ${ic('email')} Individual</label>
    </div>
    <div data-painel-tipo="lote">
      ${contatos.length ? `<div class="opcoes">${Object.entries(PUBLICOS).map(([k, v]) => `<label class="opcao"><input type="radio" name="publico" value="${k}" ${k === 'todos' ? 'checked' : ''}><span><b>${v}</b><small>${k === 'manual' ? 'escolha na lista abaixo' : `<span class="numero">${contagem[k]}</span> pessoa${contagem[k] === 1 ? '' : 's'}`}</small></span></label>`).join('')}</div>
      <div class="selecao" data-manual hidden>
        <div class="selecao__topo"><input type="search" placeholder="Filtrar por e-mail, nome ou empresa" data-filtro-sel><label class="check"><input type="checkbox" data-todos> Marcar todos</label><span class="sub" data-conta-sel>0 selecionados</span></div>
        <div class="selecao__lista">${contatos.map((k) => `<label class="check" data-busca="${esc((k.email + ' ' + (k.nome || '') + ' ' + (k.empresa || '')).toLowerCase())}"><input type="checkbox" name="selecionados" value="${esc(k.email)}"> <span><b>${esc(k.email)}</b> <small>${esc([k.nome, k.empresa].filter(Boolean).join(' · '))}</small></span></label>`).join('')}</div>
      </div>` : `<p class="alerta">Nenhum cliente cadastrado. <a href="/admin/contatos">Cadastre a lista de clientes</a> para enviar em lote.</p>`}
    </div>
    <div data-painel-tipo="individual" hidden>
      <label>E-mail(s) — um por linha ou separados por vírgula<textarea name="emails" rows="4" class="mono" placeholder="cliente@empresa.com.br">${esc(para)}</textarea></label>
      ${contatos.length ? `<label>Ou escolha um cliente<select data-add-cliente><option value="">— escolher —</option>${contatos.map((k) => `<option value="${esc(k.email)}">${esc(k.email)}${k.empresa ? ` · ${esc(k.empresa)}` : ''}</option>`).join('')}</select></label>` : ''}
    </div>
   </section>
   <section class="cartao formulario">
    <h2><span class="passo">3</span> Mensagem</h2>
    <label>Assunto<input name="assunto" value="${esc(assunto)}" required maxlength="160" data-previa></label>
    <label>Texto de abertura (opcional)<textarea name="mensagem" rows="3" placeholder="Ex.: Segue o comunicado sobre os prazos de dezembro. Qualquer dúvida, estamos à disposição." data-previa></textarea></label>
   </section>
   <div class="botoes envio__botoes">
     <button type="submit" class="btn btn--sec" formaction="/admin/envios/teste" formnovalidate>${ic('email')} Enviar teste para ${esc(req.usuario.email)}</button>
     <button type="submit" class="btn btn--primario" data-enviar>${ic('envio')} Enviar</button>
   </div>
  </div>
  <aside class="envio__previa cartao"><span class="editor__rotulo">Como o cliente vai receber</span><iframe id="previa-email" title="Prévia do e-mail" src="/admin/envios/previa?comunicado=${c.id}"></iframe></aside>
 </div>
</form>`, 'env'));
});

r.get('/envios/previa', (req, res) => {
  const p = email.previa({ comunicadoId: Number(req.query.comunicado), base: baseUrl(req), mensagem: String(req.query.mensagem || '') });
  if (!p) return res.status(404).end();
  res.set('Content-Security-Policy', "default-src 'none'; img-src * data:; style-src 'unsafe-inline'").send(p.html);
});

function lerDestinatarios(req) {
  const b = req.body, cid = Number(b.comunicado_id);
  if (b.tipo === 'individual') {
    const nomes = Object.fromEntries(db.prepare('SELECT email, nome FROM contatos').all().map((k) => [k.email.toLowerCase(), k.nome]));
    const lista = String(b.emails || '').split(/[\s,;]+/).map((x) => x.trim().toLowerCase()).filter(Boolean);
    const ruins = lista.filter((e) => !EMAIL_RE.test(e));
    if (ruins.length) throw new Error(`E-mail inválido: ${ruins.slice(0, 3).join(', ')}`);
    return { tipo: 'individual', publico: lista.length === 1 ? lista[0] : `${lista.length} e-mails informados`, lista: lista.map((e) => ({ email: e, nome: nomes[e] })) };
  }
  const publico = PUBLICOS[b.publico] ? b.publico : 'todos';
  let lista;
  if (publico === 'manual') {
    const sel = new Set([].concat(b.selecionados || []).map((x) => String(x).toLowerCase()));
    lista = db.prepare('SELECT email, nome FROM contatos WHERE ativo = 1').all().filter((k) => sel.has(k.email.toLowerCase()));
  } else lista = publicoLote(cid, publico);
  return { tipo: 'lote', publico: PUBLICOS[publico], lista };
}

r.post('/envios', (req, res) => {
  const b = req.body, cid = Number(b.comunicado_id);
  const volta = (m) => res.redirect(`/admin/envios/novo?comunicado=${cid}&erro=${encodeURIComponent(m)}`);
  if (!db.prepare("SELECT 1 FROM comunicados WHERE id = ? AND status = 'publicado'").get(cid)) return volta('Escolha um comunicado publicado.');
  let d;
  try { d = lerDestinatarios(req); } catch (e) { return volta(e.message); }
  if (!d.lista.length) return volta('Nenhum destinatário para esse envio.');
  const id = email.criarEnvio({ comunicadoId: cid, tipo: d.tipo, publico: d.publico, assunto: String(b.assunto || '').trim() || 'Comunicado Multcont',
    mensagem: String(b.mensagem || '').trim(), base: baseUrl(req), destinatarios: d.lista, criadoPor: req.usuario.email });
  res.redirect(`/admin/envios/${id}`);
});

r.post('/envios/teste', async (req, res) => {
  const cid = Number(req.body.comunicado_id);
  try {
    await email.enviarTeste({ comunicadoId: cid, base: baseUrl(req), assunto: String(req.body.assunto || 'Comunicado'), mensagem: String(req.body.mensagem || ''), para: req.usuario.email, nome: req.usuario.nome });
    const m = email.MODO === 'teste' ? 'E-mail de teste gerado em data/emails-teste (modo teste: nada saiu de verdade).' : `E-mail de teste enviado para ${req.usuario.email}.`;
    res.redirect(`/admin/envios/novo?comunicado=${cid}&ok=${encodeURIComponent(m)}`);
  } catch (e) { res.redirect(`/admin/envios/novo?comunicado=${cid}&erro=${encodeURIComponent('Falha no envio de teste: ' + e.message)}`); }
});

r.get('/envios/:id', (req, res) => {
  const e = db.prepare('SELECT e.*, c.numero, c.titulo, c.slug FROM envios e JOIN comunicados c ON c.id = e.comunicado_id WHERE e.id = ?').get(Number(req.params.id));
  if (!e) return res.redirect('/admin/envios');
  const s = email.resumoEnvio(e.id);
  const ativo = e.status === 'na_fila' || e.status === 'enviando';
  const p = (n) => (s.total ? Math.round((100 * n) / s.total) : 0);
  const linha = (d) => `<tr><td><b>${esc(d.email)}</b>${d.nome ? `<br><small>${esc(d.nome)}</small>` : ''}</td>
    <td>${{ pendente: '<span class="sit sit--nao">Na fila</span>', enviado: '<span class="sit sit--ok2">Enviado</span>', erro: `<span class="sit sit--alerta" title="${esc(d.erro || '')}">Erro</span>`, cancelado: '<span class="sit sit--nao">Cancelado</span>' }[d.status]}</td>
    <td>${d.enviado_em ? dataHoraBR(d.enviado_em) : '—'}</td><td>${d.email_aberto_em ? dataHoraBR(d.email_aberto_em) : '—'}</td>
    <td>${d.aviso_aberto_em || d.link_clicado_em ? dataHoraBR(d.aviso_aberto_em || d.link_clicado_em) : '—'}</td>
    <td class="n">${d.rolagem != null ? `${d.rolagem}%` : '—'}</td><td>${d.leu_ate_fim ? '<span class="ok">Sim</span>' : '<span class="nao">Não</span>'}</td><td>${d.confirmado_em ? dataHoraBR(d.confirmado_em) : '—'}</td></tr>`;
  const naoAbriram = s.destinatarios.filter((d) => d.status === 'enviado' && !d.aviso_aberto_em && !d.link_clicado_em).length;
  res.send(tela(req, `Envio ${e.id}`, `
${ativo ? '<meta http-equiv="refresh" content="5">' : ''}
<div class="cabeca"><div><a class="voltar" href="/admin/envios">${ic('voltar')} Envios</a><h1>Envio de <span class="sub-num">${esc(e.numero)}</span> ${esc(e.titulo)}</h1>
<p class="sub">${e.tipo === 'lote' ? 'Em lote' : 'Individual'} · ${esc(e.publico || '')} · assunto “${esc(e.assunto)}” · criado em ${dataHoraBR(e.criado_em)} por ${esc(e.criado_por || '')}${e.modo === 'teste' ? ' · <b>modo teste</b>' : ''}</p></div>
<div class="cabeca__acoes">${ativo ? `<form method="post" action="/admin/envios/${e.id}/cancelar"><button class="btn btn--sec">Cancelar envio</button></form>` : ''}
${!ativo && naoAbriram ? `<form method="post" action="/admin/envios/${e.id}/reenviar"><button class="btn btn--primario">${ic('envio')} Reenviar para quem não abriu (${naoAbriram})</button></form>` : ''}</div></div>
<section class="cartao"><div class="progresso-envio"><div style="width:${p(s.enviados + s.erros)}%"></div></div>
<p class="sub">${STATUS_ENVIO[e.status]} · ${num(s.enviados)} de ${num(s.total)} enviados${s.erros ? ` · ${s.erros} com erro` : ''}${ativo ? ` · a página atualiza sozinha (ritmo de ${email.info().porMinuto} por minuto)` : ''}</p></section>
<section class="kpis">
  ${kpi('Enviados', num(s.enviados), `de ${num(s.total)} destinatários`)}
  ${kpi('Abriram o e-mail', `${p(s.emailAberto)}%`, `${num(s.emailAberto)} · aproximado`)}
  ${kpi('Abriram o aviso', `${p(s.avisoAberto)}%`, `${num(s.avisoAberto)} pessoas`)}
  ${kpi('Leram até o fim', `${p(s.leuFim)}%`, `${num(s.leuFim)} pessoas`)}
  ${kpi('Confirmaram', `${p(s.confirmaram)}%`, `${num(s.confirmaram)} “Li e estou ciente”`)}
</section>
<section class="cartao"><div class="cartao__cabeca"><h2>Destinatários</h2><a class="btn btn--sec" href="/admin/exportar/envio.csv?envio=${e.id}">Exportar CSV</a></div>
<div class="tabela-rolagem tabela-rolagem--alta"><table class="tabela"><thead><tr><th>E-mail</th><th>Envio</th><th>Enviado em</th><th>Abriu e-mail</th><th>Abriu aviso</th><th class="n">Rolagem</th><th>Leu até o fim</th><th>Confirmou</th></tr></thead>
<tbody>${s.destinatarios.map(linha).join('')}</tbody></table></div>
<p class="nota">“Abriu o e-mail” depende do programa de e-mail carregar imagens, então é aproximado. “Abriu o aviso” e “Leu até o fim” são medidos no site e são exatos.</p></section>`, 'env'));
});
r.post('/envios/:id/cancelar', (req, res) => { email.cancelar(Number(req.params.id)); res.redirect(`/admin/envios/${req.params.id}`); });
r.post('/envios/:id/reenviar', (req, res) => {
  const e = db.prepare('SELECT * FROM envios WHERE id = ?').get(Number(req.params.id));
  if (!e) return res.redirect('/admin/envios');
  const lista = email.resumoEnvio(e.id).destinatarios.filter((d) => d.status === 'enviado' && !d.aviso_aberto_em && !d.link_clicado_em).map((d) => ({ email: d.email, nome: d.nome }));
  if (!lista.length) return res.redirect(`/admin/envios/${e.id}`);
  const id = email.criarEnvio({ comunicadoId: e.comunicado_id, tipo: 'lote', publico: `Reenvio: não abriram o envio nº ${e.id}`, assunto: `Lembrete: ${e.assunto}`, mensagem: e.mensagem, base: e.base_url, destinatarios: lista, criadoPor: req.usuario.email });
  res.redirect(`/admin/envios/${id}`);
});

// ---------------------------------------------------------------------
// CLIENTES (lista de e-mails que devem ler os avisos)
// ---------------------------------------------------------------------
r.get('/contatos', (req, res) => {
  const lista = db.prepare(`SELECT k.*, (SELECT COUNT(DISTINCT s.comunicado_id) FROM sessoes_leitura s JOIN visitantes v ON v.id = s.visitante_id
      WHERE LOWER(COALESCE(s.email, v.email)) = LOWER(k.email)) lidos
    FROM contatos k WHERE ativo = 1 ORDER BY empresa, email`).all();
  const total = db.prepare("SELECT COUNT(*) n FROM comunicados WHERE status = 'publicado'").get().n;
  res.send(tela(req, 'Clientes', `
<div class="cabeca"><div><h1>Clientes (e-mails)</h1><p class="sub">Quem deve receber e ler os avisos. Com esta lista, o relatório de cada aviso mostra também quem <b>não abriu</b> e você baixa os links personalizados para enviar.</p></div></div>
${req.query.ok ? `<p class="sucesso">${esc(req.query.ok)}</p>` : ''}
<form method="post" action="/admin/contatos/importar" class="formulario cartao">
  <h2>Adicionar ou atualizar clientes</h2>
  <label>Cole um por linha: <code>e-mail; nome; empresa</code> (nome e empresa são opcionais — dá para colar direto do Excel)
    <textarea name="lista" rows="7" class="mono" placeholder="financeiro@padariasol.com.br; Ana Souza; Padaria Sol&#10;rh@construtoraalfa.com.br; Carlos; Construtora Alfa"></textarea></label>
  <div class="botoes"><button class="btn btn--primario">Salvar lista</button></div>
</form>
<section class="cartao"><div class="cartao__cabeca"><h2>${num(lista.length)} clientes cadastrados</h2></div>
<div class="tabela-rolagem tabela-rolagem--alta"><table class="tabela"><thead><tr><th>E-mail</th><th>Nome</th><th>Empresa</th><th class="n">Avisos abertos</th><th></th></tr></thead>
<tbody>${lista.map((k) => `<tr><td>${esc(k.email)}</td><td>${esc(k.nome || '')}</td><td>${esc(k.empresa || '')}</td><td class="n">${k.lidos} de ${total}</td>
<td><form method="post" action="/admin/contatos/${k.id}/remover"><button class="alternar">Remover</button></form></td></tr>`).join('') || '<tr><td colspan="5" class="vazio">Nenhum cliente cadastrado.</td></tr>'}</tbody></table></div></section>`, 'cli'));
});
r.post('/contatos/importar', (req, res) => {
  const up = db.prepare(`INSERT INTO contatos (email, nome, empresa) VALUES (@email, @nome, @empresa)
    ON CONFLICT(email) DO UPDATE SET nome = COALESCE(excluded.nome, nome), empresa = COALESCE(excluded.empresa, empresa), ativo = 1`);
  let ok = 0, ruins = 0;
  db.transaction(() => {
    for (const linha of String(req.body.lista || '').split(/\r?\n/)) {
      if (!linha.trim()) continue;
      const [email, nome, empresa] = linha.split(/[;\t,]/).map((x) => x.trim());
      if (!EMAIL_RE.test((email || '').toLowerCase())) { ruins++; continue; }
      up.run({ email: email.toLowerCase(), nome: nome || null, empresa: empresa || null }); ok++;
    }
  })();
  res.redirect('/admin/contatos?ok=' + encodeURIComponent(`${ok} cliente(s) salvos${ruins ? ` · ${ruins} linha(s) ignoradas por e-mail inválido` : ''}.`));
});
r.post('/contatos/:id/remover', (req, res) => {
  db.prepare('UPDATE contatos SET ativo = 0 WHERE id = ?').run(Number(req.params.id));
  res.redirect('/admin/contatos?ok=' + encodeURIComponent('Cliente removido da lista.'));
});

// ---------------------------------------------------------------------
// MINHA CONTA (cada gestor troca a própria senha)
// ---------------------------------------------------------------------
r.get('/conta', (req, res) => {
  const u = req.usuario, primeiro = u.trocar_senha === 1;
  res.send(tela(req, 'Minha conta', `
<div class="cabeca"><div><h1>${primeiro ? 'Crie a sua senha' : 'Minha conta'}</h1><p class="sub">${esc(u.nome)} · ${esc(u.email)} · perfil <b>${PERFIS[u.perfil].nome}</b> — ${PERFIS[u.perfil].desc}.</p></div></div>
${primeiro ? '<p class="alerta">Este é o seu primeiro acesso (ou sua senha foi redefinida). Defina uma senha pessoal para continuar.</p>' : ''}
${req.query.ok ? '<p class="sucesso">Senha alterada.</p>' : ''}${req.query.erro ? `<p class="alerta">${esc(req.query.erro)}</p>` : ''}
<form method="post" action="/admin/conta/senha" class="formulario cartao" style="max-width:520px"><h2>${primeiro ? 'Nova senha' : 'Trocar minha senha'}</h2>
  <label>Senha atual${primeiro ? ' (a senha temporária que você recebeu)' : ''}<input type="password" name="atual" required autocomplete="current-password"></label>
  <label>Nova senha (mín. 10 caracteres)<input type="password" name="nova" minlength="10" required autocomplete="new-password"></label>
  <label>Repita a nova senha<input type="password" name="nova2" minlength="10" required autocomplete="new-password"></label>
  <div class="botoes"><button class="btn btn--primario">Salvar senha</button></div></form>`, 'conta'));
});
r.post('/conta/senha', (req, res) => {
  const u = db.prepare('SELECT * FROM admin_usuarios WHERE id = ?').get(req.usuario.id);
  const nova = String(req.body.nova || '');
  const erro = (m) => res.redirect('/admin/conta?' + (u.trocar_senha ? 'primeiro=1&' : '') + 'erro=' + encodeURIComponent(m));
  if (!conferirSenha(String(req.body.atual || ''), u.senha_hash)) return erro('Senha atual incorreta.');
  if (nova.length < 10) return erro('A nova senha precisa de pelo menos 10 caracteres.');
  if (nova !== String(req.body.nova2 || '')) return erro('As duas senhas novas não conferem.');
  if (conferirSenha(nova, u.senha_hash)) return erro('Escolha uma senha diferente da atual.');
  db.prepare('UPDATE admin_usuarios SET senha_hash = ?, trocar_senha = 0 WHERE id = ?').run(hashSenha(nova), u.id);
  res.redirect(u.trocar_senha ? '/admin' : '/admin/conta?ok=1');
});

// ---------------------------------------------------------------------
// GESTORES (só administradores): vários acessos, cada um com login próprio
// ---------------------------------------------------------------------
const senhaTemporaria = () => crypto.randomBytes(9).toString('base64url').replace(/[-_]/g, 'x');
const admsAtivos = () => db.prepare("SELECT COUNT(*) n FROM admin_usuarios WHERE perfil = 'administrador' AND ativo = 1").get().n;
r.get('/gestores', (req, res) => {
  const lista = db.prepare('SELECT * FROM admin_usuarios ORDER BY ativo DESC, perfil, nome').all();
  const temp = req.query.temp ? db.prepare('SELECT nome, email FROM admin_usuarios WHERE id = ?').get(Number(req.query.uid)) : null;
  const linha = (u) => {
    const eu = u.id === req.usuario.id;
    return `<tr class="${u.ativo ? '' : 'inativo'}">
    <td><b>${esc(u.nome)}</b>${eu ? ' <span class="mini">você</span>' : ''}<br><small>${esc(u.email)}</small></td>
    <td>${eu ? `<b>${PERFIS[u.perfil].nome}</b>` : `<form method="post" action="/admin/gestores/${u.id}/perfil" class="inline"><select name="perfil" onchange="this.form.submit()">${Object.entries(PERFIS).map(([k, v]) => `<option value="${k}" ${k === u.perfil ? 'selected' : ''}>${v.nome}</option>`).join('')}</select></form>`}</td>
    <td>${u.ativo ? (u.trocar_senha ? '<span class="sit sit--alerta">Aguardando 1º acesso</span>' : '<span class="sit sit--ok2">Ativo</span>') : '<span class="sit sit--nao">Desativado</span>'}</td>
    <td>${u.ultimo_acesso ? dataHoraBR(u.ultimo_acesso) : '—'}</td>
    <td><small>${esc(u.criado_por || '')}</small></td>
    <td class="acoes-linha">${eu ? '<a href="/admin/conta">Minha senha</a>' : `
      <form method="post" action="/admin/gestores/${u.id}/redefinir" class="inline" onsubmit="return confirm('Gerar uma senha temporária para ${esc(u.nome)}? A senha atual deixa de funcionar.')"><button class="link-botao">Redefinir senha</button></form>
      <form method="post" action="/admin/gestores/${u.id}/${u.ativo ? 'desativar' : 'reativar'}" class="inline"><button class="link-botao">${u.ativo ? 'Desativar' : 'Reativar'}</button></form>`}</td></tr>`;
  };
  res.send(tela(req, 'Gestores', `
<div class="cabeca"><div><h1>Gestores</h1><p class="sub">Quem pode entrar na área restrita. Cada pessoa tem login e senha próprios — ninguém compartilha senha.</p></div></div>
${req.query.ok ? `<p class="sucesso">${esc(req.query.ok)}</p>` : ''}${req.query.erro ? `<p class="alerta">${esc(req.query.erro)}</p>` : ''}
${temp ? `<div class="senha-temp cartao"><h2>${ic('chave')} Acesso de ${esc(temp.nome)}</h2>
  <p>Envie estes dados para a pessoa por um canal seguro. A senha temporária aparece <b>só agora</b>; no primeiro acesso ela vai criar a própria senha.</p>
  <dl><dt>Endereço</dt><dd><code>${esc(`${req.protocol}://${req.get('host')}${CAMINHO}`)}</code></dd><dt>E-mail</dt><dd><code>${esc(temp.email)}</code></dd><dt>Senha temporária</dt><dd><code class="senha">${esc(req.query.temp)}</code></dd></dl></div>` : ''}
<section class="cartao"><div class="cartao__cabeca"><h2>${lista.filter((u) => u.ativo).length} gestores ativos</h2></div>
<div class="tabela-rolagem"><table class="tabela"><thead><tr><th>Gestor</th><th>Perfil</th><th>Situação</th><th>Último acesso</th><th>Cadastrado por</th><th></th></tr></thead>
<tbody>${lista.map(linha).join('')}</tbody></table></div></section>
<div class="duas">
<form method="post" action="/admin/gestores" class="formulario cartao"><h2>${ic('mais')} Adicionar gestor</h2>
  <label>Nome<input name="nome" required maxlength="80"></label>
  <label>E-mail (será o login)<input type="email" name="email" required></label>
  <label>Perfil<select name="perfil">${Object.entries(PERFIS).map(([k, v]) => `<option value="${k}" ${k === 'gestor' ? 'selected' : ''}>${v.nome} — ${v.desc}</option>`).join('')}</select></label>
  <p class="nota">O sistema gera uma senha temporária e a pessoa cria a própria no primeiro acesso.</p>
  <div class="botoes"><button class="btn btn--primario">Adicionar</button></div></form>
<section class="cartao"><h2>O que cada perfil pode fazer</h2>
  <table class="tabela tabela--compacta"><thead><tr><th></th><th>Admin.</th><th>Gestor</th><th>Leitor</th></tr></thead><tbody>
  ${[['Ver relatórios e exportar planilhas', 1, 1, 1], ['Criar, publicar, fixar e arquivar comunicados', 1, 1, 0], ['Enviar comunicados por e-mail', 1, 1, 0], ['Cadastrar clientes (e-mails)', 1, 1, 0], ['Editar setores e WhatsApp', 1, 0, 0], ['Cadastrar e desativar gestores', 1, 0, 0]]
    .map(([t, a, g, l]) => `<tr><td>${t}</td>${[a, g, l].map((x) => `<td>${x ? ic('check') : '<span class="nao">—</span>'}</td>`).join('')}</tr>`).join('')}
  </tbody></table></section>
</div>`, 'ges'));
});
r.post('/gestores', (req, res) => {
  const nome = String(req.body.nome || '').trim(), email = String(req.body.email || '').trim().toLowerCase();
  const perfil = PERFIS[req.body.perfil] ? req.body.perfil : 'gestor';
  if (!nome || !EMAIL_RE.test(email)) return res.redirect('/admin/gestores?erro=' + encodeURIComponent('Informe nome e um e-mail válido.'));
  const temp = senhaTemporaria();
  let id;
  try {
    id = db.prepare('INSERT INTO admin_usuarios (nome, email, senha_hash, perfil, trocar_senha, criado_por) VALUES (?, ?, ?, ?, 1, ?)')
      .run(nome, email, hashSenha(temp), perfil, req.usuario.email).lastInsertRowid;
  } catch { return res.redirect('/admin/gestores?erro=' + encodeURIComponent('Esse e-mail já tem acesso.')); }
  res.redirect(`/admin/gestores?uid=${id}&temp=${encodeURIComponent(temp)}`);
});
function alvo(req, res) {
  const u = db.prepare('SELECT * FROM admin_usuarios WHERE id = ?').get(Number(req.params.id));
  if (!u) { res.redirect('/admin/gestores'); return null; }
  if (u.id === req.usuario.id) { res.redirect('/admin/gestores?erro=' + encodeURIComponent('Você não pode alterar o seu próprio acesso por aqui.')); return null; }
  return u;
}
r.post('/gestores/:id/perfil', (req, res) => {
  const u = alvo(req, res); if (!u) return;
  const perfil = PERFIS[req.body.perfil] ? req.body.perfil : u.perfil;
  if (u.perfil === 'administrador' && perfil !== 'administrador' && u.ativo && admsAtivos() <= 1) return res.redirect('/admin/gestores?erro=' + encodeURIComponent('É preciso manter pelo menos um administrador ativo.'));
  db.prepare('UPDATE admin_usuarios SET perfil = ? WHERE id = ?').run(perfil, u.id);
  res.redirect('/admin/gestores?ok=' + encodeURIComponent(`${u.nome} agora é ${PERFIS[perfil].nome}.`));
});
r.post('/gestores/:id/desativar', (req, res) => {
  const u = alvo(req, res); if (!u) return;
  if (u.perfil === 'administrador' && admsAtivos() <= 1) return res.redirect('/admin/gestores?erro=' + encodeURIComponent('É preciso manter pelo menos um administrador ativo.'));
  db.prepare('UPDATE admin_usuarios SET ativo = 0, versao_sessao = versao_sessao + 1 WHERE id = ?').run(u.id);
  res.redirect('/admin/gestores?ok=' + encodeURIComponent(`${u.nome} foi desativado e perdeu o acesso imediatamente. O histórico do que ele fez continua registrado.`));
});
r.post('/gestores/:id/reativar', (req, res) => {
  const u = alvo(req, res); if (!u) return;
  db.prepare('UPDATE admin_usuarios SET ativo = 1 WHERE id = ?').run(u.id);
  res.redirect('/admin/gestores?ok=' + encodeURIComponent(`${u.nome} foi reativado.`));
});
r.post('/gestores/:id/redefinir', (req, res) => {
  const u = alvo(req, res); if (!u) return;
  const temp = senhaTemporaria();
  db.prepare('UPDATE admin_usuarios SET senha_hash = ?, trocar_senha = 1, versao_sessao = versao_sessao + 1 WHERE id = ?').run(hashSenha(temp), u.id);
  res.redirect(`/admin/gestores?uid=${u.id}&temp=${encodeURIComponent(temp)}`);
});

module.exports = r;

module.exports.CAMINHO = CAMINHO;
module.exports.gestorLogado = lerCookie;
