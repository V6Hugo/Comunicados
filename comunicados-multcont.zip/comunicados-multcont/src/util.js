'use strict';
const crypto = require('crypto');

const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

const MESES = ['janeiro', 'fevereiro', 'março', 'abril', 'maio', 'junho', 'julho', 'agosto', 'setembro', 'outubro', 'novembro', 'dezembro'];
function dataCurta(iso) { if (!iso) return ''; const [a, m, d] = iso.slice(0, 10).split('-'); return `${d}/${m}/${a}`; }
function dataLonga(iso) { if (!iso) return ''; const [a, m, d] = iso.slice(0, 10).split('-'); return `${+d} de ${MESES[+m - 1]} de ${a}`; }
// UTC 'YYYY-MM-DD HH:MM:SS' -> horário de Brasília 'DD/MM/AAAA HH:MM'
function dataHoraBR(utc) {
  if (!utc) return '—';
  const d = new Date(utc.replace(' ', 'T') + 'Z');
  return d.toLocaleString('pt-BR', { timeZone: 'America/Sao_Paulo', day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' });
}
function duracao(ms) {
  if (ms == null || isNaN(ms)) return '—';
  const s = Math.round(ms / 1000);
  if (s < 60) return `${s}s`;
  const m = Math.floor(s / 60), r = s % 60;
  if (m < 60) return `${m}min ${String(r).padStart(2, '0')}s`;
  return `${Math.floor(m / 60)}h ${String(m % 60).padStart(2, '0')}min`;
}
function tempoLeitura(md) { return Math.max(1, Math.round(String(md).split(/\s+/).length / 200)); }

const BOT_RE = /bot|crawl|spider|slurp|preview|facebookexternalhit|whatsapp|telegram|headless|lighthouse|curl|wget|python-requests/i;
function ehBot(ua) { return !ua || BOT_RE.test(ua); }
function dispositivo(ua = '') {
  if (/ipad|tablet/i.test(ua)) return 'tablet';
  if (/mobi|android|iphone/i.test(ua)) return 'celular';
  return 'desktop';
}
const SAL_IP = process.env.SAL_IP || 'multcont-comunicados';
function ipHash(req) {
  const ip = (req.headers['x-forwarded-for'] || '').split(',')[0].trim() || req.socket.remoteAddress || '';
  return crypto.createHash('sha256').update(SAL_IP + ip).digest('hex').slice(0, 32);
}
const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const EMAIL_RE = /^[^\s@]{1,64}@[^\s@]{1,190}\.[^\s@]{2,}$/;
const slugify = (s) => String(s).normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '');

function csv(linhas, colunas) {
  const cel = (v) => { const s = v == null ? '' : String(v); return /[";\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s; };
  const cab = colunas.map((c) => cel(c.titulo)).join(';');
  const corpo = linhas.map((l) => colunas.map((c) => cel(typeof c.valor === 'function' ? c.valor(l) : l[c.campo])).join(';'));
  return '﻿' + [cab, ...corpo].join('\r\n'); // BOM + ';' abre certo no Excel em português
}

module.exports = { esc, dataCurta, dataLonga, dataHoraBR, duracao, tempoLeitura, ehBot, dispositivo, ipHash, UUID_RE, EMAIL_RE, slugify, csv };
