'use strict';
try { process.loadEnvFile?.('.env'); } catch { /* .env opcional */ }

const path = require('path');
const express = require('express');
const { marked } = require('marked');
const { db } = require('./src/db');
const { ehBot, dispositivo, ipHash, UUID_RE, EMAIL_RE } = require('./src/util');
const views = require('./src/views');

const app = express();
app.set('trust proxy', true);
app.disable('x-powered-by');
app.use(express.json({ limit: '20kb', type: ['application/json', 'text/plain'] })); // sendBeacon envia text/plain
app.use(express.urlencoded({ extended: false, limit: '200kb' }));
app.use(express.static(path.join(__dirname, 'public'), { maxAge: '1h' }));

// ---------------------------------------------------------------------
// Consultas públicas
// ---------------------------------------------------------------------
const SELECT_COM = `
  SELECT c.*, d.slug depto_slug, d.nome depto_nome, d.cor depto_cor,
         d.whatsapp depto_whatsapp, d.mensagem_whatsapp depto_msg,
         CASE WHEN c.fixado = 1 AND (c.fixado_ate IS NULL OR c.fixado_ate >= date('now','-3 hours')) THEN 1 ELSE 0 END AS fixado
  FROM comunicados c JOIN departamentos d ON d.id = c.departamento_id`;
const qLista = db.prepare(`${SELECT_COM} WHERE c.status = 'publicado' ORDER BY c.publicado_em DESC, c.id DESC`);
const qPorSlug = db.prepare(`${SELECT_COM} WHERE c.slug = ? AND c.status IN ('publicado','arquivado')`);
const qDeptos = db.prepare('SELECT * FROM departamentos WHERE ativo = 1 ORDER BY ordem, nome');

const admin = require('./src/admin');
views.CONFIG.painel = admin.CAMINHO;
// A área restrita é separada do site: por padrão, NENHUMA página pública tem link para ela.
views.CONFIG.linkRodape = process.env.LINK_AREA_RESTRITA === '1';
const PAINEL = admin.CAMINHO;
// Opcional: área restrita num endereço próprio (ex.: PAINEL_HOST=gestao.multcont.com.br).
// Nesse endereço só existe o painel; no endereço do site o painel não existe.
const PAINEL_HOST = String(process.env.PAINEL_HOST || '').trim().toLowerCase();
if (PAINEL_HOST) {
  app.use((req, res, next) => {
    const noPainelHost = (req.hostname || '').toLowerCase() === PAINEL_HOST;
    const rotaPainel = req.path === PAINEL || req.path.startsWith(PAINEL + '/');
    const estatico = /^\/(css|js|img|fonts)\//.test(req.path) || req.path === '/robots.txt';
    if (noPainelHost && !rotaPainel && !estatico) return res.redirect(PAINEL);
    if (!noPainelHost && rotaPainel) return res.status(404).send(views.pagina404());
    next();
  });
}

app.get('/', (req, res) => {
  res.set('Cache-Control', 'no-store');
  res.send(views.paginaLista({ comunicados: qLista.all(), departamentos: qDeptos.all(), gestor: admin.gestorLogado(req) }));
});

// ---------------------------------------------------------------------
// API de rastreamento  (pontos 3º, 4º e 5º)
// ---------------------------------------------------------------------
// Imagem 1x1 do e-mail: registra que o e-mail foi aberto (aproximado — alguns programas bloqueiam imagens)
const GIF = Buffer.from('R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7', 'base64');
const marcaEmailAberto = db.prepare("UPDATE envio_destinatarios SET email_aberto_em = COALESCE(email_aberto_em, datetime('now')) WHERE token = ?");
app.get('/api/t/px/:token.gif', (req, res) => {
  if (/^[A-Za-z0-9_-]{8,40}$/.test(req.params.token)) marcaEmailAberto.run(req.params.token);
  res.set({ 'Content-Type': 'image/gif', 'Cache-Control': 'no-store, max-age=0' }).send(GIF);
});

const api = express.Router();

// descarta robôs e requisições malformadas
api.use((req, res, next) => {
  if (ehBot(req.get('user-agent'))) return res.status(204).end();
  const b = req.body || {};
  if (!UUID_RE.test(b.visitante_id || '')) return res.status(400).json({ erro: 'visitante inválido' });
  next();
});

const upVisitante = db.prepare(`
  INSERT INTO visitantes (id, dispositivo, user_agent) VALUES (@id, @disp, @ua)
  ON CONFLICT(id) DO UPDATE SET ultimo_acesso = datetime('now')`);
function tocarVisitante(req) {
  const ua = String(req.get('user-agent') || '').slice(0, 300);
  upVisitante.run({ id: req.body.visitante_id, disp: dispositivo(ua), ua });
}

const TIPOS_LIVRES = new Set(['visita_lista', 'filtro_departamento', 'clique_card', 'clique_whatsapp', 'clique_imprimir', 'clique_link']);
const insEvento = db.prepare(`INSERT INTO eventos (tipo, comunicado_id, sessao_id, visitante_id, alvo, valor_ms)
  VALUES (@tipo, @comunicado_id, @sessao_id, @visitante_id, @alvo, @valor_ms)`);
const existeCom = db.prepare('SELECT id FROM comunicados WHERE id = ?');
const sessaoDe = db.prepare('SELECT * FROM sessoes_leitura WHERE id = ? AND visitante_id = ?');

// Cliques e eventos avulsos
api.post('/evento', (req, res) => {
  const b = req.body;
  if (!TIPOS_LIVRES.has(b.tipo)) return res.status(400).json({ erro: 'tipo inválido' });
  tocarVisitante(req);
  const comunicado_id = Number.isInteger(b.comunicado_id) && existeCom.get(b.comunicado_id) ? b.comunicado_id : null;
  const sessao = b.sessao_id && sessaoDe.get(b.sessao_id, b.visitante_id);
  insEvento.run({
    tipo: b.tipo, comunicado_id: sessao ? sessao.comunicado_id : comunicado_id,
    sessao_id: sessao ? sessao.id : null, visitante_id: b.visitante_id,
    alvo: b.alvo ? String(b.alvo).slice(0, 300) : null,
    valor_ms: sessao ? sessao.tempo_ativo_ms : null,
  });
  res.status(204).end();
});

// Abertura de um aviso -> cria a sessão de leitura
const insSessao = db.prepare(`INSERT INTO sessoes_leitura
  (id, comunicado_id, visitante_id, origem, campanha, dispositivo, largura_tela, ip_hash, email, email_fonte)
  VALUES (@id, @comunicado_id, @visitante_id, @origem, @campanha, @dispositivo, @largura, @ip, @email, @fonte)`);
const emailDoVisitante = db.prepare('SELECT email FROM visitantes WHERE id = ?');
api.post('/inicio', (req, res) => {
  const b = req.body;
  if (!UUID_RE.test(b.sessao_id || '') || !existeCom.get(b.comunicado_id)) return res.status(400).json({ erro: 'dados inválidos' });
  tocarVisitante(req);
  const ua = req.get('user-agent') || '';
  // Identificação: e-mail vindo no link (?e=) ou o que este navegador já informou antes
  const doLink = String(b.email || '').trim().toLowerCase();
  let email = null, fonte = null;
  if (EMAIL_RE.test(doLink)) {
    email = doLink; fonte = 'link';
    db.prepare('UPDATE visitantes SET email = ? WHERE id = ?').run(email, b.visitante_id);
  } else {
    const v = emailDoVisitante.get(b.visitante_id);
    if (v && v.email) { email = v.email; fonte = 'navegador'; }
  }
  // clique no link de um e-mail enviado pelo painel (?k=token)
  if (/^[A-Za-z0-9_-]{8,40}$/.test(String(b.token_envio || ''))) {
    const d = db.prepare('SELECT email FROM envio_destinatarios WHERE token = ?').get(b.token_envio);
    if (d) {
      db.prepare("UPDATE envio_destinatarios SET link_clicado_em = COALESCE(link_clicado_em, datetime('now')), email_aberto_em = COALESCE(email_aberto_em, datetime('now')) WHERE token = ?").run(b.token_envio);
      if (!email) { email = d.email.toLowerCase(); fonte = 'link'; db.prepare('UPDATE visitantes SET email = ? WHERE id = ?').run(email, b.visitante_id); }
    }
  }
  db.transaction(() => {
    insSessao.run({ email, fonte,
      id: b.sessao_id, comunicado_id: b.comunicado_id, visitante_id: b.visitante_id,
      origem: b.origem ? String(b.origem).slice(0, 120) : 'direto',
      campanha: b.campanha ? String(b.campanha).slice(0, 120) : null,
      dispositivo: dispositivo(ua), largura: Number(b.largura) || null, ip: ipHash(req),
    });
    insEvento.run({ tipo: 'abertura', comunicado_id: b.comunicado_id, sessao_id: b.sessao_id, visitante_id: b.visitante_id, alvo: b.origem || null, valor_ms: 0 });
  })();
  res.status(204).end();
});

// Batimento periódico: tempo e rolagem (valores acumulados -> sempre guarda o maior)
const MAX_MS = 6 * 60 * 60 * 1000;
const upSessao = db.prepare(`UPDATE sessoes_leitura SET
    tempo_total_ms   = MAX(tempo_total_ms, @total),
    tempo_ativo_ms   = MAX(tempo_ativo_ms, @ativo),
    rolagem_max_pct  = MAX(rolagem_max_pct, @rolagem),
    chegou_ao_fim    = MAX(chegou_ao_fim, @fim),
    tempo_ate_fim_ms = COALESCE(tempo_ate_fim_ms, @ate_fim),
    ultima_atividade = datetime('now')
  WHERE id = @id`);
function aplicarPing(sessao, b) {
  const lim = (v, max) => Math.max(0, Math.min(max, Math.round(Number(v) || 0)));
  const rolagem = lim(b.rolagem_max_pct, 100);
  const fim = b.chegou_ao_fim || rolagem >= 100 ? 1 : 0;
  const ativo = lim(b.tempo_ativo_ms, MAX_MS);
  upSessao.run({
    id: sessao.id, total: Math.max(lim(b.tempo_total_ms, MAX_MS), ativo), ativo, rolagem, fim,
    ate_fim: fim ? lim(b.tempo_ate_fim_ms ?? ativo, MAX_MS) : null,
  });
  // marcos de rolagem cruzados desde o último batimento
  const antes = sessao.rolagem_max_pct;
  for (const m of [25, 50, 75, 100]) {
    const agora = m === 100 ? fim : rolagem >= m;
    const ja = m === 100 ? sessao.chegou_ao_fim : antes >= m;
    if (agora && !ja) insEvento.run({ tipo: `rolagem_${m}`, comunicado_id: sessao.comunicado_id, sessao_id: sessao.id, visitante_id: sessao.visitante_id, alvo: null, valor_ms: ativo });
  }
}
api.post('/ping', (req, res) => {
  const sessao = sessaoDe.get(req.body.sessao_id || '', req.body.visitante_id);
  if (!sessao) return res.status(404).json({ erro: 'sessão não encontrada' });
  db.transaction(() => aplicarPing(sessao, req.body))();
  res.status(204).end();
});

// "Li e estou ciente"
const upConfirmacao = db.prepare(`
  INSERT INTO confirmacoes_leitura
    (comunicado_id, email, sessao_id, visitante_id, leu_ate_o_fim, rolagem_pct, tempo_ativo_ms, tempo_ate_fim_ms, ip_hash, user_agent)
  VALUES (@comunicado_id, @email, @sessao_id, @visitante_id, @fim, @rolagem, @ativo, @ate_fim, @ip, @ua)
  ON CONFLICT(comunicado_id, email) DO UPDATE SET
    leu_ate_o_fim    = MAX(leu_ate_o_fim, excluded.leu_ate_o_fim),
    rolagem_pct      = MAX(rolagem_pct, excluded.rolagem_pct),
    tempo_ativo_ms   = MAX(tempo_ativo_ms, excluded.tempo_ativo_ms),
    tempo_ate_fim_ms = COALESCE(tempo_ate_fim_ms, excluded.tempo_ate_fim_ms),
    sessao_id        = excluded.sessao_id
  RETURNING confirmado_em`);
api.post('/confirmar', (req, res) => {
  const b = req.body;
  const email = String(b.email || '').trim().toLowerCase();
  if (!EMAIL_RE.test(email)) return res.status(400).json({ erro: 'Informe um e-mail válido.' });
  const sessao = sessaoDe.get(b.sessao_id || '', b.visitante_id);
  if (!sessao) return res.status(404).json({ erro: 'Recarregue a página e tente de novo.' });
  let confirmado_em;
  db.transaction(() => {
    aplicarPing(sessao, b); // grava os números finais antes de confirmar
    const s = db.prepare('SELECT * FROM sessoes_leitura WHERE id = ?').get(sessao.id);
    confirmado_em = upConfirmacao.get({
      comunicado_id: s.comunicado_id, email, sessao_id: s.id, visitante_id: s.visitante_id,
      fim: s.chegou_ao_fim, rolagem: s.rolagem_max_pct, ativo: s.tempo_ativo_ms, ate_fim: s.tempo_ate_fim_ms,
      ip: ipHash(req), ua: String(req.get('user-agent') || '').slice(0, 300),
    }).confirmado_em;
    db.prepare('UPDATE visitantes SET email = ? WHERE id = ?').run(email, s.visitante_id);
    db.prepare("UPDATE sessoes_leitura SET email = ?, email_fonte = 'confirmacao' WHERE id = ?").run(email, s.id);
    insEvento.run({ tipo: 'confirmacao', comunicado_id: s.comunicado_id, sessao_id: s.id, visitante_id: s.visitante_id, alvo: email, valor_ms: s.tempo_ativo_ms });
  })();
  res.json({ ok: true, confirmado_em });
});

app.use('/api/t', api);

// ---------------------------------------------------------------------
// Painel administrativo e relatórios
// ---------------------------------------------------------------------
// Fica num endereço que só o operador conhece (PAINEL_CAMINHO no .env) e exige login.
// Nenhuma página pública tem link para ele; /admin responde "não encontrado".
app.use(PAINEL, admin);
if (PAINEL !== '/admin') app.use('/admin', (req, res) => res.status(404).send(views.pagina404()));

// ---------------------------------------------------------------------
// Página do aviso  (/003-2026)
// ---------------------------------------------------------------------
marked.setOptions({ gfm: true, breaks: false });
app.get('/:slug', (req, res, next) => {
  const c = qPorSlug.get(req.params.slug);
  if (!c) return res.status(404).send(views.pagina404());
  const outros = qLista.all().filter((o) => o.id !== c.id).slice(0, 3);
  res.set('Cache-Control', 'no-store');
  res.send(views.paginaComunicado({ c, html: marked.parse(c.conteudo_md), outros, gestor: admin.gestorLogado(req) }));
});

const PORTA = Number(process.env.PORT) || 3000;
if (require.main === module) {
  app.listen(PORTA, () => console.log(`Comunicados Multcont no ar: http://localhost:${PORTA}  (painel do operador: ${PAINEL})`));
}
module.exports = app;
