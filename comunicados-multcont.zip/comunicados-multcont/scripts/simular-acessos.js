'use strict';
/*
 * Gera acessos FICTÍCIOS para testar o painel de relatórios.
 * Use só num banco de teste:   DB_PATH=data/demo.db node scripts/simular-acessos.js 400
 */
if (!process.env.DB_PATH) { console.error('Defina DB_PATH apontando para um banco de TESTE (ex.: DB_PATH=data/demo.db).'); process.exit(1); }
const crypto = require('crypto');
const { db } = require('../src/db');

const N = Number(process.argv[2]) || 300;
const coms = db.prepare("SELECT id, publicado_em FROM comunicados WHERE status = 'publicado'").all();
const empresas = ['padaria-sol', 'construtora-alfa', 'clinica-viva', 'mercado-bom', 'auto-pecas-bh', 'studio-arte', 'tech-mg', 'transportes-rio', 'odonto-centro', 'restaurante-sabor'];
const r = (a, b) => a + Math.random() * (b - a);
const pick = (arr) => arr[Math.floor(Math.random() * arr.length)];
const quando = (diasAtras, pub) => {
  const base = Math.max(new Date(pub + 'T12:00:00Z').getTime(), Date.now() - diasAtras * 864e5);
  const t = base + Math.random() * Math.max(0, Date.now() - base) * Math.pow(Math.random(), 1.5);
  return new Date(t).toISOString().slice(0, 19).replace('T', ' ');
};

const insV = db.prepare("INSERT OR IGNORE INTO visitantes (id, dispositivo, user_agent, email) VALUES (?, ?, 'simulado', ?)");
const insS = db.prepare(`INSERT INTO sessoes_leitura (id, comunicado_id, visitante_id, iniciada_em, ultima_atividade, tempo_total_ms, tempo_ativo_ms, rolagem_max_pct, chegou_ao_fim, tempo_ate_fim_ms, origem, dispositivo, email, email_fonte)
  VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)`);
const insK = db.prepare('INSERT OR IGNORE INTO contatos (email, nome, empresa) VALUES (?, ?, ?)');
const insE = db.prepare('INSERT INTO eventos (tipo, comunicado_id, sessao_id, visitante_id, alvo, valor_ms, criado_em) VALUES (?,?,?,?,?,?,?)');
const insC = db.prepare(`INSERT OR IGNORE INTO confirmacoes_leitura (comunicado_id, email, sessao_id, visitante_id, leu_ate_o_fim, rolagem_pct, tempo_ativo_ms, tempo_ate_fim_ms, confirmado_em)
  VALUES (?,?,?,?,?,?,?,?,?)`);

const leitores = Array.from({ length: Math.ceil(N / 2.2) }, (_, i) => ({
  id: crypto.randomUUID(), disp: Math.random() < 0.62 ? 'celular' : 'desktop',
  email: `${pick(['financeiro', 'rh', 'contato', 'adm', 'socio', 'gerencia'])}${i}@${pick(empresas)}.com.br`,
}));

db.transaction(() => {
  for (const l of leitores) insV.run(l.id, l.disp, null);
  for (let i = 0; i < N; i++) {
    const l = pick(leitores); const c = pick(coms);
    const ini = quando(30, c.publicado_em);
    const origem = pick(['email', 'email', 'email', 'whatsapp', 'whatsapp', 'lista', 'direto']);
    const engajado = Math.random();
    const rolagem = engajado > 0.35 ? 100 : Math.round(r(20, 95));
    const fim = rolagem >= 100 ? 1 : 0;
    const ativo = Math.round((fim ? r(40, 240) : r(5, 60)) * 1000);
    const ateFim = fim ? Math.round(ativo * r(0.6, 0.95)) : null;
    const sid = crypto.randomUUID();
    const doLink = origem === 'email' && Math.random() < 0.8;
    insS.run(sid, c.id, l.id, ini, ini, Math.round(ativo * r(1, 1.8)), ativo, rolagem, fim, ateFim, origem, l.disp, doLink ? l.email : null, doLink ? 'link' : null);
    if (origem === 'lista') insE.run('clique_card', c.id, null, l.id, 'lista', null, ini);
    insE.run('abertura', c.id, sid, l.id, origem, 0, ini);
    for (const m of [25, 50, 75]) if (rolagem >= m) insE.run(`rolagem_${m}`, c.id, sid, l.id, null, null, ini);
    if (fim) insE.run('rolagem_100', c.id, sid, l.id, null, ateFim, ini);
    if (Math.random() < 0.07) insE.run('clique_whatsapp', c.id, sid, l.id, null, ativo, ini);
    if (Math.random() < 0.03) insE.run('clique_imprimir', c.id, sid, l.id, null, ativo, ini);
    if ((fim && Math.random() < 0.62) || (!fim && Math.random() < 0.08)) {
      insC.run(c.id, l.email, sid, l.id, fim, rolagem, ativo, ateFim, ini);
      db.prepare('UPDATE visitantes SET email = ? WHERE id = ?').run(l.email, l.id);
      db.prepare("UPDATE sessoes_leitura SET email = ?, email_fonte = 'confirmacao' WHERE id = ?").run(l.email, sid);
    }
  }
  // lista de clientes: todos os leitores + alguns que nunca abriram nada
  leitores.forEach((l) => insK.run(l.email, null, l.email.split('@')[1].replace('.com.br', '').replace(/-/g, ' ')));
  for (let i = 0; i < 25; i++) insK.run(`contato${900 + i}@${pick(empresas)}.com.br`, null, null);
  for (let i = 0; i < N * 0.8; i++) insE.run('visita_lista', null, null, pick(leitores).id, 'direto', null, quando(30, '2026-10-01'));
})();
console.log(`Gerados ${N} acessos fictícios em ${process.env.DB_PATH}.`);
