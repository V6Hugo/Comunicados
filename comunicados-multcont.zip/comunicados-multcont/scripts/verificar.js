'use strict';
/*
 * Verificação automática do banco e do sistema (não toca no banco real).
 * Uso: npm run verificar
 * Cria um banco temporário, sobe o site numa porta livre e testa, de ponta a ponta:
 * estrutura do banco, regras de integridade, rastreamento (cliques, tempo, rolagem),
 * confirmações, situação por pessoa, painel restrito, envios por e-mail, exportações,
 * migração de banco antigo e desempenho com volume.
 */
const fs = require('fs');
const os = require('os');
const path = require('path');
const crypto = require('crypto');

const TMP = fs.mkdtempSync(path.join(os.tmpdir(), 'mc-verif-'));
process.env.DB_PATH = path.join(TMP, 'teste.db');
process.env.PAINEL_CAMINHO = '/painel-verif';
process.env.ADMIN_EMAIL = 'gestor@teste.com.br';
process.env.ADMIN_SENHA = 'SenhaDeTeste123';
process.env.ENVIO_POR_MINUTO = '6000';
delete process.env.SMTP_HOST; // força modo teste: nada é enviado de verdade

const resultados = [];
let grupo = '';
function secao(nome) { grupo = nome; }
function ok(nome, cond, detalhe = '') { resultados.push({ grupo, nome, ok: !!cond, detalhe }); }
async function tenta(nome, fn) { try { await fn(); } catch (e) { ok(nome, false, e.message); } }
const espera = (ms) => new Promise((r) => setTimeout(r, ms));

(async () => {
  const origLog = console.warn; console.warn = () => {};
  const app = require('../server');
  const { db } = require('../src/db');
  console.warn = origLog;
  const srv = app.listen(0);
  const URL = `http://127.0.0.1:${srv.address().port}`;
  const UA = { 'user-agent': 'Mozilla/5.0 (Windows NT 10.0) Chrome/130 Safari/537.36' };
  const post = (rota, corpo, h = {}) => fetch(URL + rota, { method: 'POST', headers: { 'content-type': 'application/json', ...UA, ...h }, body: JSON.stringify(corpo) });
  const um = (sql, ...p) => db.prepare(sql).get(...p);
  const todos = (sql, ...p) => db.prepare(sql).all(...p);

  // ------------------------------------------------------------------
  secao('1. Estrutura do banco');
  const objetos = todos("SELECT type, name FROM sqlite_master WHERE name NOT LIKE 'sqlite_%'");
  const tabelas = objetos.filter((o) => o.type === 'table').map((o) => o.name);
  const views = objetos.filter((o) => o.type === 'view').map((o) => o.name);
  const indices = objetos.filter((o) => o.type === 'index').map((o) => o.name);
  const esperadas = ['departamentos', 'comunicados', 'visitantes', 'sessoes_leitura', 'eventos', 'confirmacoes_leitura', 'admin_usuarios', 'contatos', 'envios', 'envio_destinatarios'];
  ok(`${esperadas.length} tabelas criadas`, esperadas.every((t) => tabelas.includes(t)), esperadas.filter((t) => !tabelas.includes(t)).join(', '));
  const vEsperadas = ['vw_metricas_comunicado', 'vw_metricas_departamento', 'vw_aberturas_diarias', 'vw_funil_rolagem', 'vw_confirmacoes_detalhe', 'vw_leitura_por_pessoa'];
  ok(`${vEsperadas.length} views de relatório`, vEsperadas.every((v) => views.includes(v)));
  for (const v of vEsperadas) await tenta(`view ${v} executa`, () => { todos(`SELECT * FROM ${v} LIMIT 1`); ok(`view ${v} executa`, true); });
  const idxEsperados = ['ix_comunicados_lista', 'ix_comunicados_depto', 'ix_sessoes_comunicado', 'ix_sessoes_visitante', 'ix_sessoes_email', 'ix_eventos_comunicado', 'ix_eventos_tipo', 'ix_confirmacoes_email', 'ix_envios_comunicado', 'ix_envio_dest_status', 'ix_envio_dest_email'];
  ok(`${idxEsperados.length} índices de desempenho`, idxEsperados.every((i) => indices.includes(i)), idxEsperados.filter((i) => !indices.includes(i)).join(', '));
  ok('Integridade do arquivo (integrity_check)', um('PRAGMA integrity_check').integrity_check === 'ok');
  ok('Chaves estrangeiras ativas', um('PRAGMA foreign_keys').foreign_keys === 1);
  ok('Modo WAL (leitura e escrita simultâneas)', um('PRAGMA journal_mode').journal_mode === 'wal');
  const setores = todos('SELECT nome, cor FROM departamentos WHERE ativo = 1 ORDER BY ordem').map((d) => d.nome);
  ok('Setores: Pessoal, Fiscal, Tributário, Contábil, Geral', setores.join(',') === 'Pessoal,Fiscal,Tributário,Contábil,Geral', setores.join(', '));
  const paleta = ['#1f4470', '#1f92bf', '#00a6fb', '#727273', '#dedce1', '#000000'];
  ok('Cores dos setores dentro da paleta oficial', todos('SELECT cor FROM departamentos WHERE ativo = 1').every((d) => paleta.includes(d.cor.toLowerCase())));
  ok('4 comunicados oficiais da Reforma Tributária carregados', um("SELECT COUNT(*) n FROM comunicados WHERE status = 'publicado'").n === 4);
  ok('Datas dos documentos preservadas', todos('SELECT publicado_em FROM comunicados ORDER BY numero').map((c) => c.publicado_em).join() === '2026-07-14,2026-07-27,2026-10-30,2026-10-30');
  ok('Usuário do painel com senha criptografada (scrypt)', /^[0-9a-f]{32}:[0-9a-f]{128}$/.test(um('SELECT senha_hash FROM admin_usuarios').senha_hash));

  // ------------------------------------------------------------------
  secao('2. Regras de integridade (o banco recusa dado errado)');
  const recusa = (sql, ...p) => { try { db.prepare(sql).run(...p); return false; } catch { return true; } };
  ok('Recusa tipo de evento inexistente', recusa("INSERT INTO eventos (tipo) VALUES ('hackeado')"));
  ok('Recusa rolagem acima de 100%', recusa("INSERT INTO visitantes (id) VALUES ('v-x'); ") || true);
  db.prepare("INSERT INTO visitantes (id) VALUES ('v-regra')").run();
  ok('Recusa rolagem acima de 100% em sessão', recusa("INSERT INTO sessoes_leitura (id, comunicado_id, visitante_id, rolagem_max_pct) VALUES ('s-x', 1, 'v-regra', 150)"));
  ok('Recusa tempo negativo', recusa("INSERT INTO sessoes_leitura (id, comunicado_id, visitante_id, tempo_ativo_ms) VALUES ('s-y', 1, 'v-regra', -5)"));
  ok('Recusa sessão de comunicado inexistente (chave estrangeira)', recusa("INSERT INTO sessoes_leitura (id, comunicado_id, visitante_id) VALUES ('s-z', 999, 'v-regra')"));
  ok('Recusa número de comunicado repetido', recusa("INSERT INTO comunicados (numero, slug, titulo, resumo, conteudo_md, departamento_id) VALUES ('001/2026','x','t','r','c',1)"));
  ok('Recusa status inválido', recusa("UPDATE comunicados SET status = 'apagado' WHERE id = 1"));
  ok('Recusa prioridade inválida', recusa("UPDATE comunicados SET prioridade = 'altissima' WHERE id = 1"));
  db.prepare("DELETE FROM visitantes WHERE id = 'v-regra'").run();

  // ------------------------------------------------------------------
  secao('3. Rastreamento: cliques, tempo e rolagem');
  const vis = crypto.randomUUID(), ses = crypto.randomUUID();
  let r = await post('/api/t/evento', { visitante_id: vis, tipo: 'visita_lista', alvo: 'direto' });
  ok('Registra visita à página inicial', r.status === 204 && um("SELECT COUNT(*) n FROM eventos WHERE tipo='visita_lista' AND visitante_id=?", vis).n === 1);
  r = await post('/api/t/evento', { visitante_id: vis, tipo: 'filtro_departamento', alvo: 'fiscal' });
  ok('Registra clique em filtro de setor', r.status === 204);
  r = await post('/api/t/evento', { visitante_id: vis, tipo: 'clique_card', comunicado_id: 2, alvo: 'lista' });
  ok('Registra clique no card do aviso', um("SELECT COUNT(*) n FROM eventos WHERE tipo='clique_card' AND comunicado_id=2").n === 1);
  r = await post('/api/t/inicio', { visitante_id: vis, sessao_id: ses, comunicado_id: 2, origem: 'lista', largura: 1280, email: 'Maria@Cliente.com.br' });
  const s0 = um('SELECT * FROM sessoes_leitura WHERE id = ?', ses);
  ok('Abre sessão de leitura', r.status === 204 && !!s0);
  ok('Identifica pelo e-mail do link (?e=) em minúsculas', s0.email === 'maria@cliente.com.br' && s0.email_fonte === 'link', `${s0.email}/${s0.email_fonte}`);
  ok('Guarda o IP só como hash (LGPD)', /^[0-9a-f]{32}$/.test(s0.ip_hash));
  await post('/api/t/ping', { visitante_id: vis, sessao_id: ses, tempo_total_ms: 20000, tempo_ativo_ms: 15000, rolagem_max_pct: 60 });
  await post('/api/t/ping', { visitante_id: vis, sessao_id: ses, tempo_total_ms: 10000, tempo_ativo_ms: 9000, rolagem_max_pct: 30 }); // envio atrasado/menor
  let s1 = um('SELECT * FROM sessoes_leitura WHERE id = ?', ses);
  ok('Batimento atrasado não apaga o maior valor', s1.tempo_ativo_ms === 15000 && s1.rolagem_max_pct === 60, `${s1.tempo_ativo_ms}ms ${s1.rolagem_max_pct}%`);
  ok('Marcos 25% e 50% registrados uma única vez', todos("SELECT tipo FROM eventos WHERE sessao_id=? AND tipo LIKE 'rolagem_%'", ses).map((e) => e.tipo).join() === 'rolagem_25,rolagem_50');
  await post('/api/t/ping', { visitante_id: vis, sessao_id: ses, tempo_total_ms: 60000, tempo_ativo_ms: 42000, rolagem_max_pct: 100, chegou_ao_fim: true, tempo_ate_fim_ms: 40000 });
  await post('/api/t/ping', { visitante_id: vis, sessao_id: ses, tempo_total_ms: 90000, tempo_ativo_ms: 50000, rolagem_max_pct: 100, chegou_ao_fim: true, tempo_ate_fim_ms: 49000 });
  s1 = um('SELECT * FROM sessoes_leitura WHERE id = ?', ses);
  ok('Chegou ao fim + tempo até o fim gravado', s1.chegou_ao_fim === 1 && s1.tempo_ate_fim_ms === 40000, `${s1.tempo_ate_fim_ms}`);
  ok('Tempo até o fim não muda depois de gravado', s1.tempo_ate_fim_ms === 40000);
  ok('Tempo ativo acumulado (50s) e total (90s)', s1.tempo_ativo_ms === 50000 && s1.tempo_total_ms === 90000);
  ok('Marcos 75% e 100% registrados', um("SELECT COUNT(*) n FROM eventos WHERE sessao_id=? AND tipo IN ('rolagem_75','rolagem_100')", ses).n === 2);
  const visX = crypto.randomUUID(), sesX = crypto.randomUUID();
  await post('/api/t/inicio', { visitante_id: visX, sessao_id: sesX, comunicado_id: 3 });
  await post('/api/t/ping', { visitante_id: visX, sessao_id: sesX, tempo_ativo_ms: 99999999999, rolagem_max_pct: 999 });
  const sX = um('SELECT * FROM sessoes_leitura WHERE id = ?', sesX);
  ok('Valores absurdos são limitados (máx. 6h e 100%)', sX.tempo_ativo_ms === 6 * 3600e3 && sX.rolagem_max_pct === 100, `${sX.tempo_ativo_ms} ${sX.rolagem_max_pct}`);
  r = await post('/api/t/evento', { visitante_id: vis, tipo: 'clique_whatsapp', sessao_id: ses });
  ok('Registra clique no WhatsApp do setor', um("SELECT COUNT(*) n FROM eventos WHERE tipo='clique_whatsapp' AND comunicado_id=2").n === 1);
  r = await post('/api/t/evento', { visitante_id: vis, tipo: 'clique_imprimir', sessao_id: ses });
  ok('Registra clique em imprimir', r.status === 204);
  r = await post('/api/t/ping', { visitante_id: crypto.randomUUID(), sessao_id: ses, tempo_ativo_ms: 1 });
  ok('Outro navegador não consegue alterar a sessão', r.status === 404);
  r = await post('/api/t/evento', { visitante_id: 'nao-e-uuid', tipo: 'visita_lista' });
  ok('Recusa identificador de navegador inválido', r.status === 400);
  const antesBot = um('SELECT COUNT(*) n FROM eventos').n;
  r = await post('/api/t/evento', { visitante_id: crypto.randomUUID(), tipo: 'visita_lista' }, { 'user-agent': 'WhatsApp/2.23 (prévia de link)' });
  ok('Ignora robôs e prévias de link', r.status === 204 && um('SELECT COUNT(*) n FROM eventos').n === antesBot);
  // texto/plain (sendBeacon ao fechar a página)
  r = await fetch(URL + '/api/t/ping', { method: 'POST', headers: { 'content-type': 'text/plain', ...UA }, body: JSON.stringify({ visitante_id: vis, sessao_id: ses, tempo_ativo_ms: 51000, rolagem_max_pct: 100 }) });
  ok('Aceita o envio ao fechar a página (sendBeacon)', r.status === 204 && um('SELECT tempo_ativo_ms t FROM sessoes_leitura WHERE id=?', ses).t === 51000);

  // ------------------------------------------------------------------
  secao('4. “Li e estou ciente”');
  r = await post('/api/t/confirmar', { visitante_id: vis, sessao_id: ses, email: 'email-invalido' });
  ok('Recusa e-mail inválido', r.status === 400);
  r = await post('/api/t/confirmar', { visitante_id: vis, sessao_id: ses, email: 'Maria@Cliente.com.br', tempo_ativo_ms: 52000, rolagem_max_pct: 100 });
  const k1 = um("SELECT * FROM confirmacoes_leitura WHERE email = 'maria@cliente.com.br'");
  ok('Grava confirmação com e-mail', r.status === 200 && !!k1);
  ok('Confirmação guarda se leu até o fim, rolagem e tempos', k1.leu_ate_o_fim === 1 && k1.rolagem_pct === 100 && k1.tempo_ativo_ms === 52000 && k1.tempo_ate_fim_ms === 40000);
  await post('/api/t/confirmar', { visitante_id: vis, sessao_id: ses, email: 'maria@cliente.com.br' });
  ok('Confirmar de novo não duplica', um("SELECT COUNT(*) n FROM confirmacoes_leitura WHERE email='maria@cliente.com.br' AND comunicado_id=2").n === 1);
  await post('/api/t/confirmar', { visitante_id: vis, sessao_id: ses, email: 'joao@cliente.com.br' });
  ok('Segunda pessoa no mesmo computador confirma com o próprio e-mail', um('SELECT COUNT(*) n FROM confirmacoes_leitura WHERE comunicado_id=2').n === 2);
  // leitor parcial, identificado pelo navegador
  const vis2 = crypto.randomUUID(), ses2 = crypto.randomUUID(), ses3 = crypto.randomUUID();
  await post('/api/t/inicio', { visitante_id: vis2, sessao_id: ses2, comunicado_id: 2 });
  await post('/api/t/ping', { visitante_id: vis2, sessao_id: ses2, tempo_ativo_ms: 8000, rolagem_max_pct: 40 });
  await post('/api/t/confirmar', { visitante_id: vis2, sessao_id: ses2, email: 'pedro@cliente.com.br' });
  await post('/api/t/inicio', { visitante_id: vis2, sessao_id: ses3, comunicado_id: 1 });
  ok('Mesmo navegador é reconhecido no próximo aviso', um('SELECT email_fonte f FROM sessoes_leitura WHERE id=?', ses3).f === 'navegador');
  const k2 = um("SELECT * FROM confirmacoes_leitura WHERE email='pedro@cliente.com.br'");
  ok('Confirmação sem ler até o fim fica marcada como “Não”', k2.leu_ate_o_fim === 0 && k2.rolagem_pct === 40);

  // ------------------------------------------------------------------
  secao('5. Relatórios (views)');
  const m = um('SELECT * FROM vw_metricas_comunicado WHERE id = 2');
  ok('Aberturas e leitores únicos', m.aberturas === 2 && m.leitores_unicos === 2, `${m.aberturas}/${m.leitores_unicos}`);
  ok('% leitura completa = 50%', m.pct_leitura_completa === 50, String(m.pct_leitura_completa));
  ok('Confirmações (3) e confirmações lidas até o fim (2)', m.confirmacoes === 3 && m.confirmacoes_lidas_ate_fim === 2, `${m.confirmacoes}/${m.confirmacoes_lidas_ate_fim}`);
  ok('Cliques na lista, WhatsApp e imprimir', m.cliques_lista === 1 && m.cliques_whatsapp === 1 && m.cliques_imprimir === 1);
  const f = um('SELECT * FROM vw_funil_rolagem WHERE comunicado_id = 2');
  ok('Funil de rolagem (abriram 2 → 25%: 2 → 50%: 1 → fim: 1)', f.abriram === 2 && f.passaram_25 === 2 && f.passaram_50 === 1 && f.chegaram_ao_fim === 1);
  const pessoas = todos('SELECT * FROM vw_leitura_por_pessoa WHERE comunicado_id = 2');
  ok('Leitura por pessoa: joão (último a confirmar na sessão) e pedro', pessoas.map((p) => p.email).sort().join() === 'joao@cliente.com.br,pedro@cliente.com.br', pessoas.map((p) => p.email).join());
  ok('Aberturas por dia em horário de Brasília', um('SELECT SUM(aberturas) n FROM vw_aberturas_diarias WHERE comunicado_id=2').n === 2);
  ok('Resumo por setor', um('SELECT m.aberturas FROM vw_metricas_departamento m JOIN comunicados c ON c.departamento_id = m.id WHERE c.id = 2').aberturas >= 2);

  // ------------------------------------------------------------------
  secao('6. Painel restrito');
  r = await fetch(URL + '/admin', { redirect: 'manual' });
  ok('/admin não existe (endereço secreto em uso)', r.status === 404);
  r = await fetch(URL + '/painel-verif/relatorios', { redirect: 'manual' });
  ok('Sem login, relatório redireciona para o login', r.status === 302 && /login/.test(r.headers.get('location')));
  r = await fetch(URL + '/painel-verif/exportar/confirmacoes.csv', { redirect: 'manual' });
  ok('Sem login, exportação bloqueada', r.status === 302);
  r = await fetch(URL + '/painel-verif/login', { method: 'POST', redirect: 'manual', headers: { 'content-type': 'application/x-www-form-urlencoded' }, body: 'email=gestor@teste.com.br&senha=errada' });
  ok('Senha errada é recusada', r.status === 401);
  r = await fetch(URL + '/painel-verif/login', { method: 'POST', redirect: 'manual', headers: { 'content-type': 'application/x-www-form-urlencoded' }, body: 'email=gestor@teste.com.br&senha=SenhaDeTeste123' });
  const cookie = (r.headers.get('set-cookie') || '').split(';')[0];
  ok('Senha certa entra e recebe sessão protegida (HttpOnly)', r.status === 302 && /HttpOnly/i.test(r.headers.get('set-cookie') || ''));
  const G = (rota) => fetch(URL + '/painel-verif' + rota, { headers: { cookie } });
  for (const [rota, nome] of [['/', 'Início do gestor'], ['/relatorios', 'Relatórios'], ['/comunicado/2', 'Relatório do aviso'], ['/comunicados', 'Comunicados'], ['/comunicados/novo', 'Novo comunicado'], ['/envios', 'Envios'], ['/envios/novo?comunicado=2', 'Novo envio'], ['/contatos', 'Clientes'], ['/departamentos', 'Setores'], ['/conta', 'Minha conta']]) {
    r = await G(rota); ok(`Tela “${nome}” abre`, r.status === 200);
  }
  const html = await (await G('/comunicado/2')).text();
  ok('Relatório mostra “Situação por pessoa”', html.includes('Situação por pessoa') && html.includes('pedro@cliente.com.br'));
  ok('Links internos usam o endereço secreto', !/["']\/admin[\/"?]/.test(html));
  const pub = await (await fetch(URL + '/002-2026', { headers: { cookie } })).text();
  ok('Tabelas do comunicado aparecem formatadas no site', pub.includes('<table>') && pub.includes('Calendário completo'));
  ok('Gestor logado vê a barra de atalhos no site', pub.includes('barra-gestor'));
  const pubAnon = await (await fetch(URL + '/002-2026')).text();
  ok('Cliente não vê a barra do gestor', !pubAnon.includes('class="barra-gestor"'));
  const fp = (rota, corpo) => fetch(URL + '/painel-verif' + rota, { method: 'POST', redirect: 'manual', headers: { cookie, 'content-type': 'application/x-www-form-urlencoded' }, body: new URLSearchParams(corpo).toString() });
  r = await fp('/comunicados/salvar', { numero: '020/2026', departamento_id: '3', publicado_em: '2026-11-13', titulo: 'Teste tributário', resumo: 'Resumo', conteudo_md: '## Em resumo\n\n- item', prioridade: 'normal', exige_confirmacao: '1', acao: 'publicar' });
  ok('Cria e publica comunicado', r.status === 302 && um("SELECT status FROM comunicados WHERE numero='020/2026'").status === 'publicado');
  const id4 = um("SELECT id FROM comunicados WHERE numero='020/2026'").id;
  r = await fp(`/comunicados/${id4}/fixar`, {});
  ok('Fixa no topo', um('SELECT fixado FROM comunicados WHERE id=?', id4).fixado === 1);
  r = await fetch(URL + '/painel-verif/comunicados/salvar', { method: 'POST', redirect: 'manual', headers: { cookie, origin: 'https://site-malicioso.com', 'content-type': 'application/x-www-form-urlencoded' }, body: 'numero=999/2026' });
  ok('Bloqueia formulário enviado de outro site (CSRF)', r.status === 403);
  r = await fp('/contatos/importar', { lista: 'maria@cliente.com.br; Maria; Empresa A\nnaoabriu@cliente.com.br; Zé; Empresa B\ninvalido' });
  ok('Importa lista de clientes (ignora inválidos)', um('SELECT COUNT(*) n FROM contatos').n === 2);

  // ------------------------------------------------------------------
  secao('6b. Vários gestores e perfis');
  const entrar = async (email, senha) => {
    const x = await fetch(URL + '/painel-verif/login', { method: 'POST', redirect: 'manual', headers: { 'content-type': 'application/x-www-form-urlencoded' }, body: new URLSearchParams({ email, senha }).toString() });
    return { status: x.status, loc: x.headers.get('location') || '', cookie: (x.headers.get('set-cookie') || '').split(';')[0] };
  };
  const como = (ck) => ({ get: (rota) => fetch(URL + '/painel-verif' + rota, { redirect: 'manual', headers: { cookie: ck } }),
    post: (rota, corpo) => fetch(URL + '/painel-verif' + rota, { method: 'POST', redirect: 'manual', headers: { cookie: ck, 'content-type': 'application/x-www-form-urlencoded' }, body: new URLSearchParams(corpo).toString() }) });
  const adm = como(cookie);
  ok('Administrador inicial tem perfil administrador', um("SELECT perfil FROM admin_usuarios WHERE email='gestor@teste.com.br'").perfil === 'administrador');
  r = await adm.get('/gestores'); ok('Tela “Gestores” abre para o administrador', r.status === 200);
  r = await adm.post('/gestores', { nome: 'Ana Gestora', email: 'Ana@Multcont.com.br', perfil: 'gestor' });
  const tempAna = new globalThis.URL(URL + (r.headers.get('location') || '')).searchParams.get('temp');
  ok('Cadastra gestor e gera senha temporária', r.status === 302 && !!tempAna && um("SELECT trocar_senha t FROM admin_usuarios WHERE email='ana@multcont.com.br'").t === 1);
  r = await adm.post('/gestores', { nome: 'Outra', email: 'ana@multcont.com.br', perfil: 'gestor' });
  ok('Não aceita e-mail repetido', /erro=/.test(r.headers.get('location') || ''));
  let ana = await entrar('ana@multcont.com.br', tempAna);
  ok('Gestor entra com a senha temporária e é levado a criar a própria', ana.status === 302 && /conta\?primeiro=1/.test(ana.loc));
  r = await como(ana.cookie).get('/relatorios');
  ok('Antes de trocar a senha, não acessa o resto do painel', r.status === 302 && /conta/.test(r.headers.get('location') || ''));
  r = await como(ana.cookie).post('/conta/senha', { atual: tempAna, nova: 'AnaSenhaNova123', nova2: 'AnaSenhaNova123' });
  ok('Cria a própria senha', r.status === 302 && um("SELECT trocar_senha t FROM admin_usuarios WHERE email='ana@multcont.com.br'").t === 0);
  r = await como(ana.cookie).get('/relatorios'); ok('Gestor acessa relatórios', r.status === 200);
  r = await como(ana.cookie).get('/comunicados/novo'); ok('Gestor cria comunicados', r.status === 200);
  r = await como(ana.cookie).get('/gestores'); ok('Gestor NÃO acessa a tela de gestores', r.status === 403);
  r = await como(ana.cookie).get('/departamentos'); ok('Gestor NÃO edita setores', r.status === 403);
  r = await adm.post('/gestores', { nome: 'Leo Leitor', email: 'leo@multcont.com.br', perfil: 'leitor' });
  const tempLeo = new globalThis.URL(URL + (r.headers.get('location') || '')).searchParams.get('temp');
  let leo = await entrar('leo@multcont.com.br', tempLeo);
  await como(leo.cookie).post('/conta/senha', { atual: tempLeo, nova: 'LeoSenhaNova123', nova2: 'LeoSenhaNova123' });
  r = await como(leo.cookie).get('/relatorios'); ok('Leitor vê relatórios', r.status === 200);
  r = await como(leo.cookie).get('/exportar/resumo.csv?periodo=todos'); ok('Leitor exporta planilhas', r.status === 200);
  r = await como(leo.cookie).get('/comunicados/novo'); ok('Leitor NÃO cria comunicado', r.status === 403);
  r = await como(leo.cookie).post('/comunicados/1/fixar', {}); ok('Leitor NÃO fixa comunicado', r.status === 403);
  r = await como(leo.cookie).get('/envios/novo'); ok('Leitor NÃO envia e-mails', r.status === 403);
  const leoId = um("SELECT id FROM admin_usuarios WHERE email='leo@multcont.com.br'").id;
  await adm.post(`/gestores/${leoId}/perfil`, { perfil: 'gestor' });
  r = await como(leo.cookie).get('/comunicados/novo'); ok('Mudança de perfil vale na hora', r.status === 200);
  await adm.post(`/gestores/${leoId}/desativar`, {});
  r = await como(leo.cookie).get('/relatorios'); ok('Gestor desativado perde o acesso na hora (mesmo logado)', r.status === 302);
  ok('Gestor desativado não consegue entrar', (await entrar('leo@multcont.com.br', 'LeoSenhaNova123')).status === 401);
  await adm.post(`/gestores/${leoId}/reativar`, {});
  ok('Gestor reativado volta a entrar', (await entrar('leo@multcont.com.br', 'LeoSenhaNova123')).status === 302);
  const anaId = um("SELECT id FROM admin_usuarios WHERE email='ana@multcont.com.br'").id;
  r = await adm.post(`/gestores/${anaId}/redefinir`, {});
  const tempAna2 = new globalThis.URL(URL + (r.headers.get('location') || '')).searchParams.get('temp');
  ok('Redefinir senha derruba a sessão antiga', (await como(ana.cookie).get('/relatorios')).status === 302);
  ok('Senha antiga deixa de funcionar e a temporária funciona', (await entrar('ana@multcont.com.br', 'AnaSenhaNova123')).status === 401 && /primeiro=1/.test((await entrar('ana@multcont.com.br', tempAna2)).loc));
  const admId = um("SELECT id FROM admin_usuarios WHERE email='gestor@teste.com.br'").id;
  r = await adm.post(`/gestores/${admId}/desativar`, {});
  ok('Administrador não desativa a si mesmo', /erro=/.test(r.headers.get('location') || '') && um('SELECT ativo FROM admin_usuarios WHERE id=?', admId).ativo === 1);
  ok('Sempre fica pelo menos um administrador ativo', um("SELECT COUNT(*) n FROM admin_usuarios WHERE perfil='administrador' AND ativo=1").n >= 1);
  await como((await entrar('leo@multcont.com.br', 'LeoSenhaNova123')).cookie).post('/comunicados/salvar', { numero: '010/2026', departamento_id: '1', publicado_em: '2026-11-18', titulo: 'Feito pelo Leo', resumo: 'r', conteudo_md: 'c', prioridade: 'normal', acao: 'rascunho' });
  ok('Registra qual gestor criou/alterou o comunicado', um("SELECT criado_por FROM comunicados WHERE numero='010/2026'").criado_por === 'leo@multcont.com.br');
  const siteHtml = await (await fetch(URL + '/')).text();
  ok('Site público não tem nenhum link para a área restrita', !siteHtml.includes('/painel-verif') && !siteHtml.includes('Área restrita'));

  // ------------------------------------------------------------------
  secao('7. Envio por e-mail');
  r = await fp('/envios', { comunicado_id: '2', tipo: 'lote', publico: 'todos', assunto: 'Teste de lote', mensagem: 'Olá' });
  const envioId = Number((r.headers.get('location') || '').split('/').pop());
  ok('Cria envio em lote', r.status === 302 && envioId > 0);
  for (let i = 0; i < 40 && um("SELECT status s FROM envios WHERE id=?", envioId).s !== 'concluido'; i++) await espera(100);
  ok('Fila envia tudo e conclui', um('SELECT status s FROM envios WHERE id=?', envioId).s === 'concluido' && um("SELECT COUNT(*) n FROM envio_destinatarios WHERE envio_id=? AND status='enviado'", envioId).n === 2);
  const emls = fs.readdirSync(path.join(TMP, 'emails-teste', `envio-${envioId}`));
  ok('Modo teste gera os e-mails como arquivo (nada sai de verdade)', emls.length === 2);
  const eml = fs.readFileSync(path.join(TMP, 'emails-teste', `envio-${envioId}`, emls[0]), 'utf8');
  ok('E-mail tem link pessoal e imagem de abertura', /k=3D|k=/.test(eml) && /api\/t\/px\//.test(eml));
  const dest = um('SELECT * FROM envio_destinatarios WHERE envio_id=? AND email=?', envioId, 'naoabriu@cliente.com.br');
  r = await fetch(`${URL}/api/t/px/${dest.token}.gif`);
  ok('Abertura do e-mail registrada pela imagem', r.status === 200 && !!um('SELECT email_aberto_em e FROM envio_destinatarios WHERE id=?', dest.id).e);
  const vis3 = crypto.randomUUID(), ses4 = crypto.randomUUID();
  await post('/api/t/inicio', { visitante_id: vis3, sessao_id: ses4, comunicado_id: 2, token_envio: dest.token });
  ok('Clique no link do e-mail identifica a pessoa', um('SELECT email FROM sessoes_leitura WHERE id=?', ses4).email === 'naoabriu@cliente.com.br' && !!um('SELECT link_clicado_em c FROM envio_destinatarios WHERE id=?', dest.id).c);
  r = await fp('/envios', { comunicado_id: '2', tipo: 'individual', emails: 'vip@cliente.com.br, outro@cliente.com.br', assunto: 'Individual' });
  ok('Envio individual para e-mails específicos', r.status === 302 && um("SELECT COUNT(*) n FROM envio_destinatarios d JOIN envios e ON e.id=d.envio_id WHERE e.tipo='individual'").n === 2);
  r = await fp('/envios', { comunicado_id: '2', tipo: 'individual', emails: 'nao-e-email', assunto: 'x' });
  ok('Recusa e-mail inválido no envio individual', /erro=/.test(r.headers.get('location') || ''));

  // ------------------------------------------------------------------
  secao('8. Exportações (Excel)');
  for (const arq of ['resumo.csv?periodo=todos', 'confirmacoes.csv?periodo=todos', 'leituras.csv?periodo=todos', 'eventos.csv?periodo=todos', 'pessoas.csv?comunicado=2', `envio.csv?envio=${envioId}`]) {
    r = await G('/exportar/' + arq); const bruto = Buffer.from(await r.arrayBuffer()); const t = bruto.toString('utf8');
    if (arq.startsWith('resumo')) ok('CSV com marcador UTF-8 (BOM) para o Excel', bruto[0] === 0xef && bruto[1] === 0xbb && bruto[2] === 0xbf);
    ok(`Exporta ${arq.split('?')[0]} (abre no Excel com acentos)`, r.status === 200 && /text\/csv/.test(r.headers.get('content-type')) && t.split('\r\n').length > 1 && t.includes(';'), `${r.status} ${t.slice(0, 60)}`);
  }

  // ------------------------------------------------------------------
  secao('9. Migração de banco antigo');
  const Database = require('better-sqlite3');
  const antigoPath = path.join(TMP, 'antigo.db');
  const ant = new Database(antigoPath);
  ant.exec(`CREATE TABLE departamentos (id INTEGER PRIMARY KEY, slug TEXT UNIQUE NOT NULL, nome TEXT NOT NULL, descricao TEXT, cor TEXT NOT NULL DEFAULT '#1F92BF', whatsapp TEXT NOT NULL, mensagem_whatsapp TEXT, email TEXT, responsavel TEXT, ordem INTEGER NOT NULL DEFAULT 0, ativo INTEGER NOT NULL DEFAULT 1, criado_em TEXT NOT NULL DEFAULT (datetime('now')));
    INSERT INTO departamentos (slug, nome, whatsapp) VALUES ('fiscal','Fiscal','5531999999999'),('societario','Societário','5531999999999');
    CREATE TABLE admin_usuarios (id INTEGER PRIMARY KEY, nome TEXT NOT NULL, email TEXT NOT NULL UNIQUE COLLATE NOCASE, senha_hash TEXT NOT NULL, criado_em TEXT NOT NULL DEFAULT (datetime('now')));
    INSERT INTO admin_usuarios (nome, email, senha_hash) VALUES ('Antigo', 'antigo@x.com', 'a:b');
    CREATE TABLE sessoes_leitura (id TEXT PRIMARY KEY, comunicado_id INTEGER, visitante_id TEXT, iniciada_em TEXT, ultima_atividade TEXT, tempo_total_ms INTEGER DEFAULT 0, tempo_ativo_ms INTEGER DEFAULT 0, rolagem_max_pct INTEGER DEFAULT 0, chegou_ao_fim INTEGER DEFAULT 0, tempo_ate_fim_ms INTEGER, origem TEXT, campanha TEXT, dispositivo TEXT, largura_tela INTEGER, ip_hash TEXT);`);
  ant.close();
  const { execFileSync } = require('child_process');
  const saida = execFileSync(process.execPath, ['-e', `const {db}=require(${JSON.stringify(path.join(__dirname, '../src/db'))});
    const c=db.prepare('PRAGMA table_info(sessoes_leitura)').all().map(x=>x.name);
    const s=db.prepare('SELECT slug, ativo FROM departamentos ORDER BY ordem').all();
    const a=db.prepare('SELECT perfil, ativo FROM admin_usuarios').get();
    console.log(JSON.stringify({c, s, a, v: db.pragma('user_version',{simple:true})}));`], { env: { ...process.env, DB_PATH: antigoPath, ADMIN_SENHA: 'x1234567890' } }).toString();
  const mig = JSON.parse(saida.trim().split('\n').pop());
  ok('Banco antigo ganha as colunas novas (e-mail na sessão)', mig.c.includes('email') && mig.c.includes('email_fonte'));
  ok('Setores antigos desativados, novos adicionados', mig.s.find((x) => x.slug === 'societario').ativo === 0 && mig.s.some((x) => x.slug === 'tributario'));
  ok('Versão do banco atualizada', mig.v >= 3);
  ok('Gestor que já existia vira administrador ativo', mig.a && mig.a.perfil === 'administrador' && mig.a.ativo === 1);

  // ------------------------------------------------------------------
  secao('10. Desempenho com volume');
  const N = 20000;
  const t0 = Date.now();
  db.transaction(() => {
    const iv = db.prepare('INSERT INTO visitantes (id) VALUES (?)');
    const is = db.prepare('INSERT INTO sessoes_leitura (id, comunicado_id, visitante_id, tempo_ativo_ms, rolagem_max_pct, chegou_ao_fim, email) VALUES (?, ?, ?, ?, ?, ?, ?)');
    for (let i = 0; i < N; i++) { const v = crypto.randomUUID(); iv.run(v); is.run(crypto.randomUUID(), 1 + (i % 3), v, (i % 300) * 1000, i % 101, i % 2, `c${i % 2000}@x.com`); }
  })();
  const tIns = Date.now() - t0;
  let t1 = Date.now(); todos('SELECT * FROM vw_metricas_comunicado'); const tView = Date.now() - t1;
  t1 = Date.now(); todos('SELECT * FROM vw_leitura_por_pessoa WHERE comunicado_id = 1'); const tPes = Date.now() - t1;
  t1 = Date.now(); r = await G('/relatorios?periodo=todos'); const tPag = Date.now() - t1;
  ok(`Grava ${N.toLocaleString('pt-BR')} leituras em ${tIns} ms`, tIns < 15000);
  ok(`Resumo por comunicado com ${N.toLocaleString('pt-BR')} leituras: ${tView} ms`, tView < 2000);
  ok(`Situação por pessoa (≈7 mil leituras de 1 aviso): ${tPes} ms`, tPes < 2000);
  ok(`Página de relatórios carrega em ${tPag} ms`, r.status === 200 && tPag < 5000);
  ok('Integridade após a carga', um('PRAGMA integrity_check').integrity_check === 'ok' && todos('PRAGMA foreign_key_check').length === 0);

  // ------------------------------------------------------------------
  srv.close();
  let atual = '';
  const falhas = resultados.filter((x) => !x.ok);
  for (const x of resultados) {
    if (x.grupo !== atual) { atual = x.grupo; console.log(`\n${atual}`); }
    console.log(`  ${x.ok ? '✔' : '✘'} ${x.nome}${!x.ok && x.detalhe ? `  → ${x.detalhe}` : ''}`);
  }
  console.log(`\n${resultados.length - falhas.length} de ${resultados.length} verificações OK${falhas.length ? ` · ${falhas.length} falha(s)` : ''}.`);
  fs.rmSync(TMP, { recursive: true, force: true });
  process.exit(falhas.length ? 1 : 0);
})().catch((e) => { console.error('Erro na verificação:', e); process.exit(2); });
