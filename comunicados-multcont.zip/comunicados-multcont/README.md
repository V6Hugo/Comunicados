# Comunicados Multcont

Site de avisos aos clientes, separado por setor da contabilidade, que registra **cliques**, **tempo de leitura**, **rolagem até o fim** e **confirmações “Li e estou ciente”** num banco de dados próprio, com painel de relatórios e exportação para Excel.

## Verificar se está tudo funcionando
`npm run verificar` — cria um banco temporário (não mexe no real), sobe o site e roda 133 checagens: estrutura do banco, regras de integridade, rastreamento de cliques/tempo/rolagem, confirmações, relatórios, painel restrito, envios por e-mail, exportações, migração de banco antigo e desempenho com 20 mil leituras. Termina com “133 de 133 verificações OK”.

## Como rodar

Requer **Node.js 20.12 ou mais novo**.

```bash
npm install
cp .env.example .env      # defina PAINEL_CAMINHO, ADMIN_SENHA, SESSAO_SEGREDO e SAL_IP
npm start                 # site: http://localhost:3000   ·   painel: http://localhost:3000<PAINEL_CAMINHO>
```

Na primeira execução o banco `data/comunicados.db` é criado com os 5 setores (Pessoal, Fiscal, Tributário, Contábil e Geral), o usuário do painel definido no `.env` e os 4 comunicados oficiais da Reforma Tributária (001 a 004/2026, com as datas dos documentos; texto em `src/exemplos.js`). Bancos já existentes são atualizados sozinhos: os 3 exemplos fictícios antigos vão para o arquivo (`EX-n`) e os oficiais entram sem apagar nada.

**Ver o painel com dados fictícios:** `npm run simular` cria `data/demo.db` com 400 acessos inventados; depois rode `DB_PATH=data/demo.db npm start`. Nunca rode o simulador no banco real.

**Teste sem servidor:** o arquivo `comunicados-multcont-teste-local.html` (entregue à parte) tem o site e o painel completos, gravando no próprio navegador. A área restrita abre pelo arquivo `Área restrita - Comunicados Multcont.html` (na mesma pasta) — no primeiro acesso você cria o administrador e depois cadastra os outros gestores.

## Identidade visual
- Paleta oficial: `#1f4470` azul-marinho · `#1f92bf` azul médio · `#00a6fb` ciano · `#727273` cinza · `#dedce1` cinza-claro · `#000000` preto (tokens em `public/css/marca.css`). Nenhuma outra cor é usada — até os status do painel usam tons da paleta.
- Logotipo oficial em `public/img/logo-multcont.png` (fundo claro) e `logo-multcont-branco.png` (fundo azul).
- Fontes: **Caros Soft** nos títulos, **Anton** nos números e destaques, **Montserrat** no texto. Montserrat e Anton já vêm no projeto (`public/fonts`, licença OFL). A Caros Soft é licenciada: copie os arquivos `CarosSoft.woff`, `CarosSoftBold.woff` e `CarosSoftExtraBold.woff` (os mesmos do site multcont.com.br) para `public/fonts/` — sem eles os títulos usam Montserrat.

## Envio por e-mail (lote e individual)
Painel › **Envios por e-mail** (ou o botão “Enviar por e-mail” no relatório de cada aviso):
1. Escolha o comunicado.
2. **Em lote:** todos os clientes, só quem **não abriu**, só quem **não leu até o fim**, só quem **não confirmou**, ou marque clientes na lista. **Individual:** digite um ou mais e-mails (ou clique em “Enviar” na linha da pessoa em *Situação por pessoa*).
3. Ajuste assunto e texto de abertura e veja a prévia ao lado. Dá para mandar um teste para o seu e-mail antes.

Cada destinatário recebe um **link próprio** — o relatório do envio mostra, por pessoa: enviado, abriu o e-mail (aproximado), abriu o aviso, rolagem, leu até o fim e confirmou. O botão **Reenviar para quem não abriu** cria um lembrete só para essas pessoas.
- Configure o SMTP no `.env` (veja `.env.example`). **Sem SMTP o painel fica em modo teste**: gera os e-mails como arquivos `.eml` em `data/emails-teste/` (abrem no Outlook) e não envia nada.
- O envio em lote sai numa fila, no ritmo de `ENVIO_POR_MINUTO` (padrão 30/min), e continua sozinho se o servidor reiniciar.
- Para boa entrega, configure SPF/DKIM do domínio remetente no seu provedor de e-mail.

## Área restrita (separada do site, vários gestores)
- **Separada do site:** nenhuma página que o cliente vê tem link para a área restrita. Ela fica no endereço de `PAINEL_CAMINHO` (ex.: `/gestao-7f3k9`) e `/admin` responde "não encontrado". Para um endereço só dela, defina `PAINEL_HOST` (ex.: `gestao.multcont.com.br` apontando para o mesmo servidor): o painel passa a existir só ali.
- **Vários gestores, cada um com login próprio** (menu *Gestores*, só administradores):
  - **Administrador:** tudo, inclusive cadastrar gestores e editar setores.
  - **Gestor:** cria, publica, fixa e arquiva comunicados, envia e-mails, cadastra clientes e vê relatórios.
  - **Leitor:** só vê relatórios e exporta planilhas.
- Ao cadastrar um gestor, o sistema gera uma **senha temporária** (aparece uma vez só); no primeiro acesso a pessoa é obrigada a criar a própria senha.
- **Desativar** ou **redefinir senha** derruba na hora qualquer sessão aberta daquele gestor. Sempre fica pelo menos um administrador ativo, e ninguém desativa a si mesmo.
- Cada comunicado registra **quem criou e quem alterou por último**; cada envio registra quem enviou.
- Segurança: senhas com scrypt, 5 erros bloqueiam por 10 min, sessão de 12 h, proteção contra formulários de outros sites. Sem `ADMIN_SENHA`, a senha do primeiro administrador é gerada e mostrada uma vez no terminal.
- **Barra do gestor:** logado (no mesmo endereço do site), o gestor vê atalhos no topo dos avisos. As visitas dele não entram nos relatórios. O leitor vê só “Relatório”.

## O que o site faz

| Pedido | Como foi atendido |
|---|---|
| 1º Identidade Multcont | Cores do site oficial (#1F92BF, #1F4470, #00A6FB), fonte Mulish, símbolo oficial da marca. Para usar o arquivo de logo oficial, troque o bloco `logo()` em `src/views.js`. |
| Setores | Pessoal, Fiscal, Tributário, Contábil e Geral (edite número de WhatsApp e cores em *Setores e WhatsApp*). Bancos antigos são migrados sozinhos. |
| 2º Interativo, fixados, por setor | Seção **Fixados** no topo (com data opcional para desafixar sozinho), filtros por setor com contagem, busca, selos *Importante/Urgente*. URL com filtro: `/?setor=fiscal`. |
| 3º Cliques | Tabela `eventos`: visita à página inicial, filtro de setor, clique em cada aviso (na lista, nos fixados, em “outros comunicados”), WhatsApp, imprimir, links do texto. |
| 4º Tempo e rolagem | Tabela `sessoes_leitura`: uma linha por abertura com tempo na página, **tempo ativo de leitura**, rolagem máxima e **tempo gasto até chegar ao fim**. Barra de progresso de leitura no topo. |
| 5º “Li e estou ciente” | Tabela `confirmacoes_leitura`: e-mail, data/hora, **se leu até o fim**, rolagem e tempos daquela leitura. Um registro por e-mail por aviso. |
| Quem leu até o fim | Relatório **Situação por pessoa** em cada aviso: *Leu até o fim e confirmou*, *Leu até o fim (não confirmou)*, *Abriu, não chegou ao fim*, *Confirmou sem chegar ao fim* e — com a lista de clientes cadastrada — *Não abriu*. Exporta CSV. |
| 6º WhatsApp por setor | Cada setor tem seu número e mensagem inicial (painel › Setores e WhatsApp). O botão leva o número e o título do comunicado na mensagem. |
| 7º Banco de dados | SQLite com chaves estrangeiras, restrições `CHECK`, índices e 5 *views* de relatório. Detalhes abaixo. |

### Como a pessoa é identificada
1. **Link do e-mail:** envie o aviso com `?e=email-do-cliente` (o painel mostra o link pronto e baixa uma planilha com o link de cada cliente). O e-mail sai da barra de endereço assim que a página abre.
2. **“Li e estou ciente”:** o e-mail digitado passa a valer para aquela leitura.
3. **Mesmo navegador:** quem já confirmou um aviso é reconhecido nos próximos que abrir naquele navegador.

Quem abre sem nenhum desses dados aparece como *Não identificado*, mas com tempo e rolagem registrados. Se o cliente encaminhar o e-mail, as aberturas do encaminhado ficam no nome dele — o “Li e estou ciente” corrige isso para quem confirma.

### Como o tempo é medido
- **Tempo na página**: segundos com a aba visível.
- **Tempo ativo (tempo de leitura)**: segundos com a aba visível **e** alguma interação (rolagem, mouse, toque, teclado) nos últimos 30 s — quem abre e sai para o almoço não infla a média.
- **Chegou ao fim**: o final do texto do aviso apareceu na tela. **Tempo até o fim** = tempo ativo acumulado nesse momento.
- O navegador envia os números a cada 10 s e ao sair da página (`sendBeacon`). O servidor guarda sempre o maior valor, então reenvios não duplicam nada.
- Robôs (prévia de link do WhatsApp, buscadores) não executam o script e ainda são filtrados pelo *user-agent*.

### Privacidade (LGPD)
Sem cookies no site público: o leitor recebe um identificador aleatório no `localStorage`. O IP **nunca** é gravado — só um hash SHA-256 com sal (`SAL_IP`). O e-mail só existe quando a pessoa confirma a leitura, e a página avisa isso.

## Banco de dados

```
departamentos 1───N comunicados 1───N sessoes_leitura N───1 visitantes
                          │                 │
                          ├──N eventos ─────┘ (sessao_id opcional)
                          └──N confirmacoes_leitura (UNIQUE comunicado+email)
admin_usuarios (acesso ao painel, senha com scrypt)
```

| Tabela | Uma linha por… | Colunas principais |
|---|---|---|
| `departamentos` | setor | nome, cor, **whatsapp**, mensagem_whatsapp, e-mail, responsável |
| `comunicados` | aviso | número (003/2026), slug, título, resumo, conteúdo (Markdown), setor, prioridade, **fixado**, fixado_ate, status, publicado_em |
| `visitantes` | navegador anônimo | primeiro/último acesso, dispositivo, e-mail (após confirmar) |
| `sessoes_leitura` | abertura de um aviso | tempo_total_ms, **tempo_ativo_ms**, **rolagem_max_pct**, **chegou_ao_fim**, **tempo_ate_fim_ms**, **email** + email_fonte (link/confirmação/navegador), origem, dispositivo |
| `contatos` | cliente que deve ler | e-mail, nome, empresa (permite saber quem **não abriu**) |
| `envios` | disparo de um aviso | comunicado, tipo (lote/individual), público, assunto, modo (smtp/teste), status |
| `envio_destinatarios` | pessoa de um envio | e-mail, token do link, status (pendente/enviado/erro), enviado_em, email_aberto_em, link_clicado_em |
| `eventos` | clique ou marco | tipo (`clique_card`, `clique_whatsapp`, `rolagem_50`…), alvo, tempo ativo no momento |
| `confirmacoes_leitura` | e-mail × aviso | **email**, **leu_ate_o_fim**, rolagem_pct, tempo_ativo_ms, tempo_ate_fim_ms, confirmado_em |

**Views prontas** (consulte direto no banco, no Power BI/Metabase ou pelo painel):
`vw_metricas_comunicado` · `vw_metricas_departamento` · `vw_aberturas_diarias` · `vw_funil_rolagem` · `vw_confirmacoes_detalhe` · `vw_leitura_por_pessoa`

Exemplo — quem **não** confirmou o comunicado 3, entre os e-mails que já confirmaram outros avisos:
```sql
SELECT DISTINCT email FROM confirmacoes_leitura
WHERE email NOT IN (SELECT email FROM confirmacoes_leitura WHERE comunicado_id = 3);
```

**Medir de onde vieram os acessos:** ao enviar o link, acrescente `?utm_source=email` ou `?utm_source=whatsapp&utm_campaign=13-salario` — aparece na coluna *Origem* do relatório.

Para migrar para PostgreSQL/MySQL no futuro, o `src/schema.sql` usa SQL padrão; troque `datetime('now')` por `now()` e `INTEGER PRIMARY KEY` por `serial`/`AUTO_INCREMENT`.

## Painel do operador (endereço em `PAINEL_CAMINHO`)
- **Relatórios**: indicadores do período (7/30/90 dias ou tudo) e por setor, aberturas por dia, tabela por comunicado e por setor.
- **Relatório de cada aviso**: funil (abriram → 25% → 50% → 75% → fim → confirmaram), origem, dispositivo, lista de quem confirmou e de cada leitura.
- **Exportar CSV** (abre no Excel): resumo, confirmações, leituras, eventos.
- **Novo comunicado** (botão no topo dos relatórios): barra de formatação (título, negrito, listas, link, destaque), 3 modelos prontos, prévia ao lado e botões **Publicar agora** / **Salvar rascunho**. Número sugerido automaticamente. **Duplicar** reaproveita um aviso antigo.
- **Clientes (e-mails)**: cole a lista (e-mail; nome; empresa) direto do Excel.
- **Comunicados**: fixar com um clique, arquivar (sai do site, mantém histórico).
- **Setores e WhatsApp**, **Minha conta** (troca de senha, novos usuários). Login bloqueia por 10 min após 5 senhas erradas.

## Estrutura
```
server.js               rotas públicas + API de rastreamento (/api/t/*)
src/schema.sql          banco de dados (tabelas, índices, views)
src/db.js               conexão, carga inicial, senhas
src/admin.js            painel, relatórios e exportações
src/views.js            HTML das páginas públicas (dados da empresa no topo)
public/js/comunicado.js medição de tempo, rolagem, cliques e confirmação
public/js/lista.js      filtros, busca e cliques da página inicial
scripts/simular-acessos.js  dados fictícios para teste
```

## Tabelas nos comunicados

O editor aceita tabelas no formato Markdown (ficam com cabeçalho azul e rolagem lateral no celular):

```
| Tributo | Alíquota |
|---|---|
| CBS | 0,9% |
```
