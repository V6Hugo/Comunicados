/* Rastreamento de leitura — sem cookies (id anônimo no localStorage). */
(function () {
  'use strict';
  function uuid() {
    if (crypto.randomUUID) return crypto.randomUUID();
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
      var r = (crypto.getRandomValues(new Uint8Array(1))[0] & 15); return (c === 'x' ? r : (r & 3) | 8).toString(16);
    });
  }
  var visitante;
  try { visitante = localStorage.getItem('mc_visitante'); if (!visitante) { visitante = uuid(); localStorage.setItem('mc_visitante', visitante); } }
  catch (e) { visitante = uuid(); }

  var gestor = !!(window.PAGINA && window.PAGINA.gestor); // gestor logado: não entra nos relatórios
  function enviar(rota, dados, beacon) {
    if (gestor && rota !== 'confirmar') return Promise.resolve();
    var corpo = JSON.stringify(Object.assign({ visitante_id: visitante }, dados));
    if (beacon && navigator.sendBeacon && navigator.sendBeacon('/api/t/' + rota, new Blob([corpo], { type: 'text/plain' }))) {
      return Promise.resolve();
    }
    return fetch('/api/t/' + rota, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: corpo, keepalive: true });
  }

  window.Rastreio = {
    visitante: visitante,
    uuid: uuid,
    enviar: enviar,
    evento: function (tipo, extra) { return enviar('evento', Object.assign({ tipo: tipo }, extra || {}), true); }
  };
})();
