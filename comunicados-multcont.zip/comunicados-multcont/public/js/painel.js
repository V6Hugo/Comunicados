/* Painel do operador: editor de comunicado e filtros da tabela "Situação por pessoa". */
(function () {
  'use strict';
  var BASE = document.body.dataset.painel || '/admin';

  // ---------- editor ----------
  var md = document.getElementById('md'), previa = document.getElementById('previa');
  if (md && previa) {
    var t;
    var atualizar = function () {
      fetch(BASE + '/previa', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ md: md.value }) })
        .then(function (r) { return r.text(); }).then(function (h) { previa.innerHTML = h; });
    };
    md.addEventListener('input', function () { clearTimeout(t); t = setTimeout(atualizar, 300); });
    atualizar();

    function envolver(antes, depois, exemplo) {
      var i = md.selectionStart, f = md.selectionEnd, sel = md.value.slice(i, f) || exemplo;
      md.setRangeText(antes + sel + depois, i, f, 'end');
      md.focus(); md.selectionStart = i + antes.length; md.selectionEnd = i + antes.length + sel.length;
      md.dispatchEvent(new Event('input'));
    }
    function linhas(prefixo, exemplo) {
      var i = md.value.lastIndexOf('\n', md.selectionStart - 1) + 1, f = md.selectionEnd;
      var bloco = md.value.slice(i, f) || exemplo;
      var n = 0;
      var novo = bloco.split('\n').map(function (l) { n++; return (typeof prefixo === 'function' ? prefixo(n) : prefixo) + l.replace(/^(#{1,3}\s+|[-*]\s+|\d+[.)]\s+|>\s?)/, ''); }).join('\n');
      md.setRangeText(novo, i, f, 'end'); md.focus(); md.dispatchEvent(new Event('input'));
    }
    var acoes = {
      h2: function () { linhas('## ', 'Título da seção'); },
      b: function () { envolver('**', '**', 'texto em negrito'); },
      ul: function () { linhas('- ', 'item'); },
      ol: function () { linhas(function (n) { return n + '. '; }, 'item'); },
      quote: function () { linhas('> ', 'Atenção: texto em destaque'); },
      link: function () {
        var url = prompt('Endereço do link (https://...)', 'https://');
        if (url && /^https?:\/\//.test(url)) envolver('[', '](' + url + ')', 'texto do link');
      }
    };
    document.querySelectorAll('[data-fmt]').forEach(function (b) { b.addEventListener('click', function () { acoes[b.dataset.fmt](); }); });

    var modelo = document.getElementById('modelo');
    if (modelo) modelo.addEventListener('change', function () {
      var tpl = document.querySelector('template[data-modelo="' + modelo.value + '"]');
      if (!tpl) return;
      if (md.value.trim() && !confirm('Trocar o texto atual pelo modelo?')) { modelo.value = ''; return; }
      md.value = tpl.innerHTML.replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/&amp;/g, '&');
      modelo.value = ''; md.dispatchEvent(new Event('input')); md.focus();
    });

    // aviso ao sair sem salvar
    var sujo = false, form = document.getElementById('form-com');
    if (form) {
      form.addEventListener('input', function () { sujo = true; });
      form.addEventListener('submit', function () { sujo = false; });
      window.addEventListener('beforeunload', function (e) { if (sujo) { e.preventDefault(); e.returnValue = ''; } });
    }
  }

  // ---------- filtros da Situação por pessoa ----------
  var chips = document.querySelectorAll('.chip-p');
  chips.forEach(function (c) {
    c.addEventListener('click', function () {
      var g = c.dataset.grupo;
      chips.forEach(function (x) { x.classList.toggle('ativo', x === c); });
      document.querySelectorAll('#tabela-pessoas tbody tr[data-grupo]').forEach(function (tr) { tr.hidden = !(g === 'todos' || tr.dataset.grupo === g); });
    });
  });
})();

/* ---------- tela de envio por e-mail ---------- */
(function () {
  'use strict';
  var form = document.getElementById('form-envio');
  if (!form) return;
  var BASE = document.body.dataset.painel || '/admin';
  function tipo() { var r = form.querySelector('input[name=tipo]:checked'); return r ? r.value : 'lote'; }
  function publico() { var r = form.querySelector('input[name=publico]:checked'); return r ? r.value : 'todos'; }
  function atualizarTipo() {
    form.querySelectorAll('[data-painel-tipo]').forEach(function (p) { p.hidden = p.dataset.painelTipo !== tipo(); });
    var m = form.querySelector('[data-manual]'); if (m) m.hidden = !(tipo() === 'lote' && publico() === 'manual');
  }
  form.querySelectorAll('input[name=tipo],input[name=publico]').forEach(function (i) { i.addEventListener('change', atualizarTipo); });
  atualizarTipo();

  // seleção manual
  var caixas = form.querySelectorAll('input[name=selecionados]');
  var conta = form.querySelector('[data-conta-sel]');
  function contar() { if (conta) conta.textContent = form.querySelectorAll('input[name=selecionados]:checked').length + ' selecionados'; }
  caixas.forEach(function (c) { c.addEventListener('change', contar); });
  var todos = form.querySelector('[data-todos]');
  if (todos) todos.addEventListener('change', function () { caixas.forEach(function (c) { if (!c.closest('label').hidden) c.checked = todos.checked; }); contar(); });
  var filtro = form.querySelector('[data-filtro-sel]');
  if (filtro) filtro.addEventListener('input', function () { var t = filtro.value.trim().toLowerCase(); form.querySelectorAll('.selecao__lista label').forEach(function (l) { l.hidden = t && l.dataset.busca.indexOf(t) < 0; }); });

  // individual: adicionar cliente da lista
  var add = form.querySelector('[data-add-cliente]'), ta = form.querySelector('textarea[name=emails]');
  if (add) add.addEventListener('change', function () { if (!add.value) return; var v = ta.value.trim(); if ((' ' + v + ' ').indexOf(add.value) < 0) ta.value = (v ? v + '\n' : '') + add.value; add.value = ''; });

  // prévia ao vivo
  var iframe = document.getElementById('previa-email'), msg = form.querySelector('textarea[name=mensagem]'), com = form.querySelector('[name=comunicado_id]'), t;
  if (msg) msg.addEventListener('input', function () { clearTimeout(t); t = setTimeout(function () { iframe.src = BASE + '/envios/previa?comunicado=' + com.value + '&mensagem=' + encodeURIComponent(msg.value); }, 500); });

  // confirmação antes de enviar
  form.addEventListener('submit', function (ev) {
    if (!ev.submitter || !ev.submitter.hasAttribute('data-enviar')) return;
    var n;
    if (tipo() === 'individual') n = ta.value.split(/[\s,;]+/).filter(Boolean).length;
    else if (publico() === 'manual') n = form.querySelectorAll('input[name=selecionados]:checked').length;
    else { var o = form.querySelector('input[name=publico]:checked'); n = o ? Number((o.closest('label').querySelector('.numero') || {}).textContent || 0) : 0; }
    if (!n) { ev.preventDefault(); alert('Nenhum destinatário selecionado.'); return; }
    if (!confirm('Enviar este comunicado para ' + n + (n === 1 ? ' pessoa' : ' pessoas') + '?')) ev.preventDefault();
  });
})();
