/* Página do aviso: mede tempo de leitura, rolagem até o fim, cliques e confirmação. */
(function () {
  'use strict';
  var R = window.Rastreio, P = window.PAGINA;
  var sessao = R.uuid();
  var INATIVO_MS = 30000;   // sem interação por 30s = não está lendo
  var PING_MS = 5000;

  // ---- origem da visita ----
  var qs = new URLSearchParams(location.search);
  var origem = qs.get('utm_source') || qs.get('origem');
  try { origem = origem || sessionStorage.getItem('mc_origem'); sessionStorage.removeItem('mc_origem'); } catch (e) {}
  if (!origem && document.referrer) { try { var h = new URL(document.referrer).hostname; origem = h === location.hostname ? 'site' : h; } catch (e) {} }

  // e-mail do destinatário vindo no link enviado (?e=cliente@empresa.com.br)
  var emailLink = (qs.get('e') || qs.get('email') || '').trim().toLowerCase();
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(emailLink)) emailLink = '';
  var tokenEnvio = qs.get('k') || '';
  if (qs.has('e') || qs.has('email') || qs.has('k')) { // tira e-mail e código da barra de endereço (evita que vá junto se o link for copiado)
    qs.delete('e'); qs.delete('email'); qs.delete('k');
    history.replaceState(null, '', location.pathname + (qs.toString() ? '?' + qs : '') + location.hash);
  }

  var pronto = R.enviar('inicio', {
    sessao_id: sessao, comunicado_id: P.comunicado_id, origem: origem || 'direto',
    campanha: qs.get('utm_campaign'), largura: window.innerWidth, email: emailLink || undefined, token_envio: tokenEnvio || undefined
  });

  // ---- tempo ----
  var est = { total: 0, ativo: 0, rolagem: 0, fim: false, ateFim: null };
  var ultimaInteracao = Date.now(), mudou = false;
  ['scroll', 'mousemove', 'keydown', 'touchstart', 'click', 'wheel'].forEach(function (ev) {
    window.addEventListener(ev, function () { ultimaInteracao = Date.now(); }, { passive: true });
  });
  setInterval(function () {
    if (document.visibilityState !== 'visible') return;
    est.total += 1000;
    if (Date.now() - ultimaInteracao < INATIVO_MS) est.ativo += 1000;
    mudou = true;
  }, 1000);

  // ---- rolagem (do início do texto até o marcador #fim-do-texto) ----
  var corpo = document.getElementById('corpo'), marcador = document.getElementById('fim-do-texto'), barra = document.getElementById('barra');
  function medirRolagem() {
    var topo = corpo.getBoundingClientRect().top + window.scrollY;
    var fim = marcador.getBoundingClientRect().top + window.scrollY;
    var visto = window.scrollY + window.innerHeight - topo;
    var p = Math.max(0, Math.min(100, Math.round((visto / Math.max(1, fim - topo)) * 100)));
    if (barra) barra.style.width = p + '%';
    if (p > est.rolagem) { est.rolagem = p; mudou = true; }
    if (p >= 100 && !est.fim) { est.fim = true; est.ateFim = est.ativo; mudou = true; enviarPing(false); }
  }
  var raf; window.addEventListener('scroll', function () { cancelAnimationFrame(raf); raf = requestAnimationFrame(medirRolagem); }, { passive: true });
  window.addEventListener('resize', medirRolagem);
  setTimeout(medirRolagem, 300);

  // ---- envio periódico ----
  function dados() {
    return { sessao_id: sessao, tempo_total_ms: est.total, tempo_ativo_ms: est.ativo, rolagem_max_pct: est.rolagem, chegou_ao_fim: est.fim, tempo_ate_fim_ms: est.ateFim };
  }
  var iniciado = false;
  pronto.then(function () { iniciado = true; });
  function enviarPing(beacon) {
    if (!mudou) return;
    mudou = false;
    // ao sair da página o envio tem de ser imediato (sem esperar promessa)
    if (iniciado) R.enviar('ping', dados(), beacon);
    else pronto.then(function () { R.enviar('ping', dados(), beacon); });
  }
  setInterval(function () { enviarPing(false); }, PING_MS);
  document.addEventListener('visibilitychange', function () { if (document.visibilityState === 'hidden') { mudou = true; enviarPing(true); } });
  window.addEventListener('pagehide', function () { mudou = true; enviarPing(true); });
  window.addEventListener('beforeunload', function () { mudou = true; enviarPing(true); });
  setTimeout(function () { enviarPing(false); }, 2000); // primeiro registro logo no início

  // ---- cliques ----
  function evento(tipo, alvo) { pronto.then(function () { R.evento(tipo, { sessao_id: sessao, comunicado_id: P.comunicado_id, alvo: alvo }); }); }
  var zap = document.getElementById('btn-whatsapp');
  if (zap) zap.addEventListener('click', function () { evento('clique_whatsapp'); });
  document.getElementById('btn-imprimir').addEventListener('click', function () { evento('clique_imprimir'); window.print(); });
  corpo.querySelectorAll('a[href]').forEach(function (a) {
    if (a.hostname !== location.hostname) { a.target = '_blank'; a.rel = 'noopener'; }
    a.addEventListener('click', function () { evento('clique_link', a.href); });
  });
  document.querySelectorAll('[data-card]').forEach(function (a) {
    a.addEventListener('click', function () {
      R.evento('clique_card', { comunicado_id: Number(a.dataset.comunicado), alvo: a.dataset.card });
      try { sessionStorage.setItem('mc_origem', 'outros-comunicados'); } catch (e) {}
    });
  });

  // ---- "Li e estou ciente" ----
  var form = document.getElementById('form-confirmar');
  if (!form) return;
  if (P.gestor) { // pré-visualização do gestor: o botão fica visível mas não registra
    form.addEventListener('submit', function (ev) { ev.preventDefault(); var e = document.getElementById('erro'); e.textContent = 'Você está no modo gestor: a confirmação não é registrada. Saia do painel para testar como cliente.'; e.hidden = false; });
    return;
  }
  var campo = document.getElementById('email'), btn = document.getElementById('btn-ciente'), erro = document.getElementById('erro'), ok = document.getElementById('ok');
  // O campo começa SEMPRE vazio (ou com o e-mail do link pessoal desta visita), para que
  // cada pessoa que usa o mesmo computador confirme com o próprio e-mail.
  var chave = 'mc_conf_' + P.comunicado_id;
  var anteriores = document.getElementById('anteriores');
  function lerConfirmados() { try { return JSON.parse(localStorage.getItem(chave) || '[]'); } catch (e) { return []; } }
  function mostrarAnteriores() {
    var l = lerConfirmados();
    if (!anteriores || !l.length) return;
    anteriores.textContent = 'Este computador já registrou ' + (l.length === 1 ? 'uma confirmação' : l.length + ' confirmações') + ' deste aviso. Se você é outra pessoa, informe o seu e-mail abaixo.';
    anteriores.hidden = false;
  }
  function mostrarOk(email) {
    form.hidden = true; ok.hidden = false;
    document.getElementById('ok-email').textContent = email ? ' por ' + email : '';
  }
  function novoFormulario() {
    ok.hidden = true; form.hidden = false; erro.hidden = true;
    campo.value = ''; mostrarAnteriores(); campo.focus();
  }
  document.getElementById('btn-outro').addEventListener('click', novoFormulario);
  campo.value = emailLink || '';
  mostrarAnteriores();

  form.addEventListener('submit', function (ev) {
    ev.preventDefault();
    erro.hidden = true;
    var email = campo.value.trim();
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email)) { erro.textContent = 'Informe um e-mail válido.'; erro.hidden = false; campo.focus(); return; }
    btn.disabled = true; btn.textContent = 'Registrando…';
    medirRolagem();
    pronto.then(function () {
      return fetch('/api/t/confirmar', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(Object.assign({ visitante_id: R.visitante, email: email }, dados()))
      });
    }).then(function (r) { return r.json().then(function (j) { if (!r.ok) throw new Error(j.erro || 'Erro'); return j; }); })
      .then(function () {
        try { var l = lerConfirmados(); if (l.indexOf(email) < 0) l.push(email); localStorage.setItem(chave, JSON.stringify(l.slice(-10))); } catch (e) {}
        campo.value = '';
        mostrarOk(email);
      })
      .catch(function (e) { erro.textContent = e.message || 'Não foi possível registrar agora. Tente de novo.'; erro.hidden = false; })
      .then(function () { btn.disabled = false; btn.textContent = 'Li e estou ciente'; });
  });
})();
