/* Página inicial: filtros por setor, busca e cliques nos cards. */
(function () {
  'use strict';
  var R = window.Rastreio;
  R.evento('visita_lista', { alvo: document.referrer ? new URL(document.referrer).hostname : 'direto' });

  var chips = document.querySelectorAll('[data-filtro]');
  var cards = document.querySelectorAll('#lista .card');
  var busca = document.getElementById('busca');
  var vazio = document.getElementById('vazio');
  var filtro = new URLSearchParams(location.search).get('setor') || 'todos';

  function aplicar() {
    var termo = (busca.value || '').trim().toLowerCase();
    var visiveis = 0;
    cards.forEach(function (c) {
      var ok = (filtro === 'todos' || c.dataset.depto === filtro) && (!termo || c.dataset.busca.indexOf(termo) > -1);
      c.hidden = !ok; if (ok) visiveis++;
    });
    chips.forEach(function (ch) { ch.classList.toggle('ativo', ch.dataset.filtro === filtro); });
    vazio.hidden = visiveis > 0;
  }
  chips.forEach(function (ch) {
    ch.addEventListener('click', function () {
      filtro = ch.dataset.filtro;
      var url = new URL(location.href);
      if (filtro === 'todos') url.searchParams.delete('setor'); else url.searchParams.set('setor', filtro);
      history.replaceState(null, '', url);
      aplicar();
      R.evento('filtro_departamento', { alvo: filtro });
    });
  });
  var t; busca.addEventListener('input', function () { clearTimeout(t); t = setTimeout(aplicar, 120); });
  aplicar();

  // clique no card (registra antes de navegar)
  document.querySelectorAll('[data-card]').forEach(function (a) {
    a.addEventListener('click', function () {
      R.evento('clique_card', { comunicado_id: Number(a.dataset.comunicado), alvo: a.dataset.card });
      try { sessionStorage.setItem('mc_origem', 'lista'); } catch (e) {}
    });
  });
})();
